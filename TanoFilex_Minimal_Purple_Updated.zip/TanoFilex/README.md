# TANO FILEX
Native Java Android file manager (min SDK 26, target SDK 34). No third-party libraries beyond AndroidX AppCompat, DrawerLayout and RecyclerView.

## Build and install
1. Install Android Studio (it bundles JDK 17 and downloads Gradle and the Android SDK).
2. File > Open > select this TanoFilex folder. Let Gradle sync (needs internet the first time).
3. Phone: enable Developer options and USB debugging, plug in, press Run.
4. To share an APK: Build > Build Bundle(s)/APK(s) > Build APK(s). The debug APK is in app/build/outputs/apk/debug/ and installs on Android 8+ once "install unknown apps" is allowed.

## Storage permission
Android 11+: first launch opens the "All files access" page; switch it on.
Android 8-10: normal storage permission prompt.

## Known limitations
- See AUDIT.md. Compiled only against hand-written API stubs and logic-tested on a desktop JVM; never built by Gradle or run on an Android device.
- Android 8-10 cannot write to SD cards without the Storage Access Framework; SD cards are read-only there. On Android 11+ with All files access they are writable.
- Other apps' Android/data and Android/obb folders are inaccessible on Android 11+.
- Private Space is a PIN lock, NOT encryption. Uninstalling the app deletes its files.
- Archive support: ZIP only for create, browse and extract. RAR/7z open in another app.
- Image preview has pinch zoom without panning. Video playback depends on device codecs.
- Duplicates ignore files under 10 KB and hidden folders.
- Category lists load all files of a type into memory; very large libraries use more RAM.


## Futuristic dark redesign (v1.1.0)

The 1.1.0 interface refresh updates the actual Android views (not a mockup):
- New midnight/navy palette with electric-cyan and violet accents.
- Rebuilt Home dashboard with storage hero panel, storage ring, compact capacity stats, and quick-access tiles.
- Refreshed category and recent-activity cards.
- Updated top bar, drawer selection treatment, search field, and storage-ring accent.
- Existing file operations, scanner, navigation destinations, and storage logic are retained.

Build verification: this source refresh has not yet been compiled against an Android SDK or tested on a device. Run the repository's GitHub Actions workflow to produce a fresh debug APK, then test before relying on it for important file operations.
