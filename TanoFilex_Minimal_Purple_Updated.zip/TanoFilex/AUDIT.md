# TANO FILEX audit report

## How things were checked (and what that does and does not prove)
| Check | Result | Limits |
|---|---|---|
| Java compile of all 28 source files against a hand-written stub of the Android/AndroidX API | 0 errors | Stubs are my own transcription of the API signatures. This is NOT a real Android build. Resource XML, Manifest and Gradle were only parsed / reviewed by eye. |
| 54 automated tests of the non-UI logic on a desktop JVM (audit/TestMain.java) | 54 passed, 0 failed | Covers FileUtils, ZipUtil, FileWalker, StorageScanner, DuplicateFinder, PrivateVault PIN hashing. Android-specific behaviour (SAF, permissions, real storage, UI) is not exercised. |
| Static check of sidebar items | 16 labels match the spec, indexes align, every item has a handler | Static only; not tapped on a device. |
| Run on a real Android device or emulator | NOT DONE | No Android SDK or device was available. |

## Compilation
No compile errors were found against the stubs. A first-pass compile had been fooled by missing Android classes; after building the stub, the real findings were: none in the original code, plus the new errors introduced and fixed during this audit.

## Fixes made
**Storage scanning / memory**
- One filesystem attribute read per entry (java.nio walkFileTree) instead of 3 stat calls; skips hidden folders, symlinks, other apps' Android/data and Android/obb.
- Scan runs at background thread priority, is cancellable, a new scan supersedes an old one, and any failure now yields a partial result instead of crashing or hanging the UI.
- Memory cap: 150,000 category entries and 20,000 large-file entries (UI shows "list limited"); RGB_565 thumbnails; executors are shut down when a screen closes.
- Lists show "changed: tap Rescan" after any file operation.

**Private Space** (still a PIN lock, NOT encryption, and the UI says so)
- PBKDF2-HMAC-SHA256 raised to 150,000 iterations (old PINs keep working), escalating lock-outs (30 s / 5 min / 30 min), screenshots and recents preview blocked on that screen, safer imported file names, export requires storage access.
- Files are deliberately NOT encrypted: encryption could not be tested here and a bug would destroy user files.

**ZIP**
- Extraction is now two steps: a dry run (zip-slip entries, entry limit 200,000, free space, name conflicts) then the real extraction.
- Overwrite confirmation with Overwrite / Keep both / Skip / Cancel.
- Files are written to .tano_part temp files and moved into place only when complete; cancel or failure leaves no partial files. ZIP creation does the same.

**Data-loss protection**
- Copy and cross-storage move are verified (size, or file/folder counts) before the original is deleted; failed or cancelled copies are removed.
- Rename never overwrites, handles case-only renames, validates names.
- Deleting from Duplicates warns when every copy of a group is selected.

**Permissions / compatibility**
- Storage access is re-checked every time the app returns to the foreground (it can be revoked); denied permission shows the grant screen; Android 6-10 "Don't ask again" now opens app settings.
- Activity state restored after process death; fragment transactions can no longer crash after state save; background tasks no longer touch destroyed screens; out-of-memory in a task is reported instead of crashing.

## Android 8-14 notes (reasoned, not device-tested)
- Min 26 / target 34. API 26+ APIs only (java.nio.file, adaptive icon).
- Android 8-9: READ/WRITE_EXTERNAL_STORAGE. Android 10: requestLegacyExternalStorage. Android 11-14: All files access (MANAGE_EXTERNAL_STORAGE). This permission is restricted on Google Play; it is fine for a sideloaded APK.
- SD cards are read-only for apps on Android 8-10 (writes show a clear message).
- Android 13+: media permissions are not used because All files access covers them.

## Cancellation
Cancel works for copy, move, delete, ZIP create/extract, checksum, folder-size, deep search, duplicate scan and storage scan.

## Still not verified / known risks
- Never built by Gradle or run on a device. Expect to fix small resource or API mismatches on first build.
- Video/PDF/audio preview and SAF import depend on the device.
- Java's ZIP writer on Android may fail beyond 4 GB or 65,535 entries (error is shown, nothing partial is kept).
- Private Space files are plain files in app storage.
