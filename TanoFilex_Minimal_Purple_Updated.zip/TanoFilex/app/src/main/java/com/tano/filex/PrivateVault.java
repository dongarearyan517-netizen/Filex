package com.tano.filex;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Private Space: files live in the app's own internal storage (not visible to other apps or the
 * gallery) and the UI is gated by a PIN. Files are NOT encrypted.
 */
final class PrivateVault {
    private PrivateVault() {}

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "vault");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static boolean hasPin(Context c) { return !Prefs.str(c, "pin_hash", "").isEmpty(); }

    private static final int ITERATIONS = 150000;

    private static byte[] derive(String pin, byte[] salt, int iterations) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, iterations, 256);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    }

    static void setPin(Context c, String pin) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        Prefs.putStr(c, "pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP));
        Prefs.putInt(c, "pin_iter", ITERATIONS);
        Prefs.putStr(c, "pin_hash", Base64.encodeToString(derive(pin, salt, ITERATIONS), Base64.NO_WRAP));
        Prefs.putInt(c, "pin_fail", 0);
        Prefs.putLong(c, "pin_lock", 0);
    }

    static boolean verify(Context c, String pin) {
        try {
            byte[] salt = Base64.decode(Prefs.str(c, "pin_salt", ""), Base64.NO_WRAP);
            byte[] h = Base64.decode(Prefs.str(c, "pin_hash", ""), Base64.NO_WRAP);
            return MessageDigest.isEqual(h, derive(pin, salt, Prefs.getInt(c, "pin_iter", 50000)));
        } catch (Exception e) {
            return false;
        }
    }

    static void reset(Context c) {
        FileUtils.deleteRecursive(dir(c));
        Prefs.putStr(c, "pin_hash", "");
        Prefs.putStr(c, "pin_salt", "");
        Prefs.putInt(c, "pin_fail", 0);
        Prefs.putLong(c, "pin_lock", 0);
    }

    /** Lock-out time after the given number of consecutive failures (every 5th failure triggers a lock-out). */
    static long lockoutMillis(int failures) {
        if (failures >= 15) return 30L * 60_000;
        if (failures >= 10) return 5L * 60_000;
        return 30_000;
    }

    static File exportDir() {
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "TANO FILEX Export");
        d.mkdirs();
        return d;
    }

    static void importUri(Context c, Uri u) throws IOException {
        String name = null;
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = q.getString(i);
            }
        } catch (Exception ignored) { }
        if (name == null || name.trim().isEmpty()) name = "file_" + System.currentTimeMillis();
        name = name.replace('/', '_').replace('\\', '_').replace("\0", "");
        if (name.equals(".") || name.equals("..") || name.trim().isEmpty()) name = "file_" + System.currentTimeMillis();
        if (name.startsWith(".")) name = "_" + name.substring(1);
        File dst = FileUtils.unique(dir(c), name);
        try (InputStream in = c.getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(dst)) {
            if (in == null) throw new IOException("Cannot open file");
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        } catch (IOException e) {
            dst.delete();
            throw e;
        }
    }
}
