package com.tano.filex;

import java.util.HashMap;
import java.util.Map;

enum Category {
    IMAGES("Images", 0xFFA78BFA, "jpg jpeg png gif webp bmp heic heif svg"),
    VIDEOS("Videos", 0xFFC026D3, "mp4 mkv avi mov 3gp webm flv wmv m4v mpeg mpg"),
    AUDIO("Audio", 0xFF8B5CF6, "mp3 wav flac aac m4a ogg opus wma amr mid midi"),
    DOCUMENTS("Documents", 0xFFE879F9, "pdf doc docx xls xlsx ppt pptx txt rtf odt ods odp csv md epub json xml html htm log"),
    APK("APK Files", 0xFF7C3AED, "apk apks xapk"),
    ARCHIVES("Archives", 0xFFDDD6FE, "zip rar 7z tar gz tgz bz2 xz"),
    OTHER("Other", 0xFF4C1D95, "");

    final String label;
    final int color;
    private final String[] exts;
    private static final Map<String, Category> MAP = new HashMap<>();

    static {
        for (Category c : values()) for (String e : c.exts) if (!e.isEmpty()) MAP.put(e, c);
    }

    Category(String label, int color, String exts) {
        this.label = label;
        this.color = color;
        this.exts = exts.split(" ");
    }

    static Category of(String fileName) {
        Category c = MAP.get(FileUtils.ext(fileName));
        return c == null ? OTHER : c;
    }
}
