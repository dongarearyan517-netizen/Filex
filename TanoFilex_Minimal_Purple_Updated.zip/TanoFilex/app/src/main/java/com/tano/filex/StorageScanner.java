package com.tano.filex;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Scans all readable storage once. Per-category totals are counted for internal storage only
 * (they feed the home ring). Per-category file lists and large files cover all volumes.
 * Memory is bounded: at most MAX_ITEMS category entries and MAX_LARGE large-file entries are kept.
 * The scan runs on a low-priority thread, can be cancelled, and never leaves the UI waiting forever.
 */
final class StorageScanner {
    static final int MAX_ITEMS = 150000;
    static final int MAX_LARGE = 20000;

    interface Listener { void onProgress(long files); void onDone(); }

    static final class Result {
        final long[] bytes = new long[Category.values().length];
        final int[] counts = new int[Category.values().length];
        final EnumMap<Category, List<FileItem>> items = new EnumMap<>(Category.class);
        final List<FileItem> large = new ArrayList<>();
        long largeThreshold;
        boolean truncated;
    }

    private static final StorageScanner I = new StorageScanner();
    static StorageScanner get() { return I; }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private volatile Result result;
    private volatile boolean running;
    private volatile boolean dirty;
    private volatile AtomicBoolean currentCancel;

    boolean isRunning() { return running; }
    Result result() { return result; }
    boolean isDirty() { return dirty; }
    void markDirty() { dirty = true; }
    void addListener(Listener l) { listeners.add(l); }
    void removeListener(Listener l) { listeners.remove(l); }

    /** Cancels any running scan and forgets the result. Does not start a new scan. */
    void invalidate() {
        AtomicBoolean c = currentCancel;
        if (c != null) c.set(true);
        running = false;
        result = null;
        dirty = false;
    }

    void rescan(Context ctx) {
        invalidate();
        start(ctx);
    }

    void start(Context ctx) {
        if (running) return;
        running = true;
        dirty = false;
        final Context app = ctx.getApplicationContext();
        final AtomicBoolean cancel = new AtomicBoolean();
        currentCancel = cancel;
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            final Result r = new Result();
            for (Category c : Category.values()) if (c != Category.OTHER) r.items.put(c, new ArrayList<>());
            try {
                r.largeThreshold = Prefs.getInt(app, "largeMb", 100) * 1024L * 1024L;
                List<StorageHelper.Volume> vols = StorageHelper.volumes(app);
                final long[] counter = {0};
                final int[] stored = {0};
                for (int i = 0; i < vols.size() && !cancel.get(); i++) {
                    final boolean primary = i == 0;
                    FileWalker.walk(vols.get(i).root, (path, size, mod) -> {
                        String name = path.substring(path.lastIndexOf('/') + 1);
                        Category c = Category.of(name);
                        int ci = c.ordinal();
                        if (primary) { r.bytes[ci] += size; r.counts[ci]++; }
                        FileItem item = null;
                        if (c != Category.OTHER) {
                            if (stored[0] < MAX_ITEMS) {
                                item = new FileItem(path, false, size, mod, c);
                                r.items.get(c).add(item);
                                stored[0]++;
                            } else {
                                r.truncated = true;
                            }
                        }
                        if (size >= r.largeThreshold && r.large.size() < MAX_LARGE) {
                            r.large.add(item != null ? item : new FileItem(path, false, size, mod, c));
                        }
                        if (++counter[0] % 2000 == 0) {
                            final long cnt = counter[0];
                            main.post(() -> { for (Listener l : listeners) l.onProgress(cnt); });
                        }
                    }, cancel);
                }
            } catch (Throwable t) {
                // keep the partial result so the UI never waits forever
            }
            if (cancel.get()) return; // superseded by a newer scan or invalidated
            result = r;
            running = false;
            main.post(() -> { for (Listener l : listeners) l.onDone(); });
        }, "tano-scan").start();
    }
}
