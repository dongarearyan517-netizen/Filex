package com.tano.filex;

import java.io.File;

final class FileItem {
    final String path;
    final boolean dir;
    long size;
    long mod;
    Category cat;
    int group;       // duplicate group number (0 = none)
    int groupCount;  // number of files in that group
    private String name;

    FileItem(File f) {
        path = f.getPath();
        name = f.getName();
        dir = f.isDirectory();
        size = dir ? 0 : f.length();
        mod = f.lastModified();
        cat = dir ? null : Category.of(name);
    }

    FileItem(String path, boolean dir, long size, long mod, Category cat) {
        this.path = path;
        this.dir = dir;
        this.size = size;
        this.mod = mod;
        this.cat = cat;
    }

    String name() {
        if (name == null) name = path.substring(path.lastIndexOf('/') + 1);
        return name;
    }

    File file() { return new File(path); }
}
