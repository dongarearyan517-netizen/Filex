package com.tano.filex;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Runs a job off the UI thread behind a cancellable progress dialog. */
final class Tasks {
    private Tasks() {}

    interface Job { String run(Ctl ctl) throws Exception; }
    interface Done { void done(String result, Exception error); }

    static final class Ctl {
        final AtomicBoolean cancel = new AtomicBoolean();
        private final Handler h = new Handler(Looper.getMainLooper());
        private TextView tv;
        void status(final String s) {
            final TextView t = tv;
            if (t != null) h.post(() -> t.setText(s));
        }
    }

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();

    static void run(final Activity a, String title, final Job job, final Done done) {
        final Ctl ctl = new Ctl();
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(a, 20);
        box.setPadding(p, p, p, p / 2);
        ProgressBar pb = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        TextView tv = UI.text(a, "Working…", 13, UI.MUTED);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        tv.setPadding(0, UI.dp(a, 10), 0, 0);
        box.addView(pb);
        box.addView(tv);
        ctl.tv = tv;
        final AlertDialog d = new AlertDialog.Builder(a).setTitle(title).setView(box)
                .setCancelable(false).setNegativeButton("Cancel", null).create();
        d.show();
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            ctl.cancel.set(true);
            ((Button) v).setEnabled(false);
        });
        final Handler h = new Handler(Looper.getMainLooper());
        EX.execute(() -> {
            String res = null;
            Exception err = null;
            try {
                res = job.run(ctl);
            } catch (Exception e) {
                err = e;
            } catch (Throwable t) { // e.g. OutOfMemoryError: report instead of crashing
                err = new Exception(t instanceof OutOfMemoryError ? "Not enough memory for this operation." : String.valueOf(t));
            }
            final String fr = res;
            final Exception fe = err;
            h.post(() -> {
                try { d.dismiss(); } catch (Exception ignored) { }
                if (a.isFinishing() || a.isDestroyed()) return;
                try {
                    done.done(fr, fe);
                } catch (RuntimeException ex) {
                    UI.toast(a, "Unexpected error: " + ex);
                }
            });
        });
    }

    static String msg(Exception e) {
        return e.getMessage() == null ? e.toString() : e.getMessage();
    }
}
