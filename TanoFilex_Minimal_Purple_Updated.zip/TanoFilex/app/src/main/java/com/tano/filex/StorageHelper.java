package com.tano.filex;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class StorageHelper {
    private StorageHelper() {}

    static final class Volume {
        final String label;
        final File root;
        Volume(String label, File root) { this.label = label; this.root = root; }
    }

    static File primary() { return Environment.getExternalStorageDirectory(); }

    static List<Volume> volumes(Context c) {
        List<Volume> v = new ArrayList<>();
        File p = primary();
        v.add(new Volume("Internal storage", p));
        File[] dirs = ContextCompat.getExternalFilesDirs(c, null);
        int n = 1;
        for (File d : dirs) {
            if (d == null) continue;
            String s = d.getAbsolutePath();
            int i = s.indexOf("/Android/data");
            if (i <= 0) continue;
            File root = new File(s.substring(0, i));
            if (root.getPath().equals(p.getPath()) || !root.exists()) continue;
            v.add(new Volume(n == 1 ? "SD card / USB" : "SD card / USB " + n, root));
            n++;
        }
        return v;
    }

    /** {total, free} in bytes */
    static long[] stat(File root) {
        try {
            StatFs s = new StatFs(root.getPath());
            return new long[]{s.getTotalBytes(), s.getAvailableBytes()};
        } catch (Exception e) {
            return new long[]{0, 0};
        }
    }
}
