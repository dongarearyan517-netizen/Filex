package com.tano.filex;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class PreviewActivity extends AppCompatActivity {
    private static Set<String> set(String... a) { return new HashSet<>(Arrays.asList(a)); }
    private static final Set<String> IMG = set("jpg", "jpeg", "png", "gif", "webp", "bmp");
    private static final Set<String> VID = set("mp4", "mkv", "3gp", "webm", "avi", "mov", "m4v");
    private static final Set<String> AUD = set("mp3", "wav", "flac", "aac", "m4a", "ogg", "opus", "amr");
    private static final Set<String> TXT = set("txt", "log", "md", "json", "xml", "csv", "html", "htm", "js", "css", "java", "kt",
            "py", "ini", "conf", "properties", "yml", "yaml", "sh", "sql", "srt", "gradle", "c", "cpp", "h");

    static boolean supports(String e) {
        return IMG.contains(e) || VID.contains(e) || AUD.contains(e) || TXT.contains(e) || e.equals("pdf");
    }

    private File file;
    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaPlayer mp;
    private PdfRenderer pdf;
    private ParcelFileDescriptor pfd;
    private int page;
    private Runnable ticker;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String p = getIntent().getStringExtra("path");
        if (p == null) { finish(); return; }
        file = new File(p);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.MIDNIGHT);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = UI.text(this, "←", 24, UI.VIOLET);
        back.setPadding(UI.dp(this, 16), UI.dp(this, 8), UI.dp(this, 16), UI.dp(this, 8));
        UI.ripple(back);
        back.setOnClickListener(x -> finish());
        TextView name = UI.text(this, file.getName(), 15, UI.TEXT);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        TextView with = UI.button(this, "Open with…");
        with.setOnClickListener(x -> FileOpen.external(this, file));
        bar.addView(back);
        bar.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(with);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(this, 52)));
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        String e = FileUtils.ext(file.getName());
        try {
            if (IMG.contains(e)) image(content);
            else if (VID.contains(e)) video(content);
            else if (AUD.contains(e)) audio(content);
            else if (TXT.contains(e)) text(content);
            else if (e.equals("pdf")) pdf(content);
        } catch (Exception ex) {
            UI.toast(this, "Cannot preview this file: " + Tasks.msg(ex));
            FileOpen.external(this, file);
            finish();
        }
    }

    private void image(FrameLayout c) {
        final ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        final ScaleGestureDetector sg = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            float sc = 1f;
            @Override public boolean onScale(ScaleGestureDetector d) {
                sc = Math.max(1f, Math.min(6f, sc * d.getScaleFactor()));
                iv.setScaleX(sc);
                iv.setScaleY(sc);
                return true;
            }
        });
        iv.setOnTouchListener((v, ev) -> { sg.onTouchEvent(ev); return true; });
        new Thread(() -> {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.getPath(), o);
                int s = 1;
                while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                Bitmap bm = BitmapFactory.decodeFile(file.getPath(), o);
                if (bm == null) throw new IOException("Cannot decode image");
                int rot = 0;
                try {
                    int ori = new android.media.ExifInterface(file.getPath()).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                    if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
                } catch (Exception ignored) { }
                if (rot != 0) {
                    Matrix m = new Matrix();
                    m.postRotate(rot);
                    bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
                }
                final Bitmap fb = bm;
                h.post(() -> iv.setImageBitmap(fb));
            } catch (Exception ex) {
                h.post(() -> UI.toast(this, "Cannot decode this image."));
            }
        }).start();
    }

    private void video(FrameLayout c) {
        final VideoView vv = new VideoView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
        lp.gravity = Gravity.CENTER;
        c.addView(vv, lp);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        vv.setVideoPath(file.getPath());
        vv.setOnPreparedListener(m -> vv.start());
        vv.setOnErrorListener((m, w, x) -> {
            UI.toast(this, "This device can't play this video format. Use Open with…");
            return true;
        });
    }

    private void audio(FrameLayout c) throws IOException {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int p = UI.dp(this, 32);
        col.setPadding(p, p, p, p);
        TextView t = UI.text(this, file.getName(), 17, UI.TEXT);
        t.setGravity(Gravity.CENTER);
        final TextView time = UI.text(this, "0:00 / 0:00", 13, UI.MUTED);
        time.setPadding(0, UI.dp(this, 16), 0, UI.dp(this, 8));
        final SeekBar sb = new SeekBar(this);
        final TextView play = UI.button(this, "Pause");
        play.setTextColor(0xFFFFFFFF);
        play.setBackground(UI.round(this, UI.PURPLE, 24));
        play.setPadding(UI.dp(this, 36), UI.dp(this, 12), UI.dp(this, 36), UI.dp(this, 12));
        col.addView(t);
        col.addView(time);
        col.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = UI.dp(this, 24);
        col.addView(play, lp);
        c.addView(col, new FrameLayout.LayoutParams(-1, -1));

        mp = new MediaPlayer();
        mp.setDataSource(file.getPath());
        mp.prepare();
        sb.setMax(mp.getDuration());
        mp.start();
        mp.setOnCompletionListener(m -> play.setText("Play"));
        play.setOnClickListener(x -> {
            if (mp.isPlaying()) { mp.pause(); play.setText("Play"); } else { mp.start(); play.setText("Pause"); }
        });
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { if (fromUser && mp != null) mp.seekTo(v); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        ticker = new Runnable() {
            @Override public void run() {
                if (mp == null) return;
                try {
                    int pos = mp.getCurrentPosition();
                    sb.setProgress(pos);
                    time.setText(fmt(pos) + " / " + fmt(mp.getDuration()));
                } catch (Exception ignored) { }
                h.postDelayed(this, 500);
            }
        };
        h.post(ticker);
    }

    private static String fmt(int ms) {
        int s = ms / 1000;
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private void text(FrameLayout c) {
        final ScrollView sv = new ScrollView(this);
        final TextView tv = UI.text(this, "Loading…", 13, UI.TEXT);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        int p = UI.dp(this, 16);
        tv.setPadding(p, p, p, p);
        sv.addView(tv);
        c.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        new Thread(() -> {
            String out;
            try (InputStream in = new FileInputStream(file)) {
                byte[] buf = new byte[262144];
                int n = 0, r;
                while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
                out = new String(buf, 0, n, StandardCharsets.UTF_8);
                if (file.length() > buf.length) out += "\n\n… preview limited to the first 256 KB. Use Open with… for the full file.";
            } catch (Exception ex) {
                out = "Cannot read file: " + Tasks.msg(ex);
            }
            final String fo = out;
            h.post(() -> tv.setText(fo));
        }).start();
    }

    private void pdf(FrameLayout c) throws IOException {
        pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        pdf = new PdfRenderer(pfd);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final ScrollView sv = new ScrollView(this);
        final ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setBackgroundColor(Color.WHITE);
        sv.addView(iv, new FrameLayout.LayoutParams(-1, -2));
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        final TextView info = UI.text(this, "", 13, UI.SOFT);
        TextView prev = UI.button(this, "◀  Previous");
        TextView next = UI.button(this, "Next  ▶");
        nav.addView(prev);
        nav.addView(info);
        nav.addView(next);
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        c.addView(col, new FrameLayout.LayoutParams(-1, -1));
        page = 0;
        showPage(iv, info, sv);
        prev.setOnClickListener(x -> { if (page > 0) { page--; showPage(iv, info, sv); } });
        next.setOnClickListener(x -> { if (page < pdf.getPageCount() - 1) { page++; showPage(iv, info, sv); } });
    }

    private void showPage(ImageView iv, TextView info, ScrollView sv) {
        PdfRenderer.Page pg = null;
        try {
            pg = pdf.openPage(page);
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 1.5f);
            int hh = Math.max(1, w * pg.getHeight() / Math.max(1, pg.getWidth()));
            if (hh > 6000) { w = w * 6000 / hh; hh = 6000; }
            Bitmap bm = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
            bm.eraseColor(Color.WHITE);
            pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            iv.setImageBitmap(bm);
        } catch (OutOfMemoryError | RuntimeException ex) {
            UI.toast(this, "Cannot render this page: " + ex);
        } finally {
            if (pg != null) pg.close();
        }
        info.setText("  Page " + (page + 1) + " / " + pdf.getPageCount() + "  ");
        sv.scrollTo(0, 0);
    }

    @Override protected void onStop() {
        super.onStop();
        if (mp != null) { try { if (mp.isPlaying()) mp.pause(); } catch (Exception ignored) { } }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (mp != null) { try { mp.release(); } catch (Exception ignored) { } mp = null; }
        if (pdf != null) { try { pdf.close(); } catch (Exception ignored) { } pdf = null; }
        if (pfd != null) { try { pfd.close(); } catch (Exception ignored) { } pfd = null; }
    }
}
