package com.tano.filex;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.List;

/** Minimal midnight-purple home dashboard. Existing file actions and storage scanning remain connected. */
public class HomeFragment extends Fragment {
    private StorageRingView ring;
    private TextView usedT, freeT, totalT, scanStatus;
    private LinearLayout recentBox;

    private final StorageScanner.Listener listener = new StorageScanner.Listener() {
        @Override public void onProgress(long files) {
            if (isAdded() && getView() != null && scanStatus != null)
                scanStatus.setText("Updating storage · " + files + " files checked");
        }
        @Override public void onDone() { refresh(); }
    };

    private LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView label(Context c, String value, float size, int color) {
        TextView t = UI.text(c, value, size, color);
        t.setFontFeatureSettings("kern");
        return t;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        final Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        LinearLayout page = column(c);
        int side = UI.dp(c, 20);
        page.setPadding(side, UI.dp(c, 22), side, UI.dp(c, 28));
        scroll.addView(page);

        TextView eyebrow = label(c, "YOUR SPACE", 10, UI.VIOLET);
        eyebrow.setLetterSpacing(0.18f);
        eyebrow.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        page.addView(eyebrow);

        TextView heading = label(c, "Everything,\nin its place.", 27, UI.TEXT);
        heading.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        heading.setLineSpacing(UI.dp(c, 1), 1f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = UI.dp(c, 7);
        page.addView(heading, hp);

        TextView sub = label(c, "A simpler way to manage your files.", 12, UI.MUTED);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = UI.dp(c, 5);
        sp.bottomMargin = UI.dp(c, 24);
        page.addView(sub, sp);

        // Main storage focus: one calm card, no extra dashboard panels.
        LinearLayout storage = column(c);
        storage.setGravity(Gravity.CENTER_HORIZONTAL);
        storage.setPadding(UI.dp(c, 16), UI.dp(c, 18), UI.dp(c, 16), UI.dp(c, 17));
        storage.setBackground(UI.panel(c));
        TextView storageTitle = label(c, "STORAGE USED", 10, UI.MUTED);
        storageTitle.setLetterSpacing(0.16f);
        storageTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        storage.addView(storageTitle);

        ring = new StorageRingView(c);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(UI.dp(c, 174), UI.dp(c, 174));
        rp.topMargin = UI.dp(c, 9);
        rp.bottomMargin = UI.dp(c, 4);
        storage.addView(ring, rp);

        TextView totalLine = label(c, "-- used  /  -- total", 12, UI.SOFT);
        totalLine.setGravity(Gravity.CENTER);
        totalT = totalLine;
        storage.addView(totalLine);

        View divider = new View(c);
        divider.setBackgroundColor(UI.DIVIDER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, UI.dp(c, 1));
        dp.topMargin = UI.dp(c, 17);
        dp.bottomMargin = UI.dp(c, 13);
        storage.addView(divider, dp);

        LinearLayout stats = row(c);
        usedT = stat(c, stats, "USED");
        freeT = stat(c, stats, "FREE");
        storage.addView(stats);
        page.addView(storage);

        // Compact quick actions: four simple icon buttons in one row.
        LinearLayout quickHead = row(c);
        LinearLayout.LayoutParams qhp = new LinearLayout.LayoutParams(-1, -2);
        qhp.topMargin = UI.dp(c, 27);
        qhp.bottomMargin = UI.dp(c, 12);
        page.addView(quickHead, qhp);
        TextView quickTitle = label(c, "QUICK ACTIONS", 11, UI.TEXT);
        quickTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        quickTitle.setLetterSpacing(0.10f);
        quickHead.addView(quickTitle);

        LinearLayout actions = row(c);
        actions.setGravity(Gravity.CENTER);
        actions.addView(action(c, "▤", "Files", MainActivity.NAV_FILES), actionWeight());
        actions.addView(action(c, "⇩", "Downloads", MainActivity.NAV_DOWNLOADS), actionWeight());
        actions.addView(action(c, "▧", "Images", MainActivity.NAV_IMAGES), actionWeight());
        actions.addView(action(c, "◇", "Archives", MainActivity.NAV_ARCHIVES), actionWeight());
        page.addView(actions);

        // Recent activity stays readable and light; no stacked cards.
        LinearLayout recentHead = row(c);
        LinearLayout.LayoutParams rhp = new LinearLayout.LayoutParams(-1, -2);
        rhp.topMargin = UI.dp(c, 29);
        rhp.bottomMargin = UI.dp(c, 9);
        page.addView(recentHead, rhp);
        TextView recentTitle = label(c, "RECENT FILE ACTIVITY", 11, UI.TEXT);
        recentTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        recentTitle.setLetterSpacing(0.08f);
        recentHead.addView(recentTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView all = UI.button(c, "See all  →");
        all.setOnClickListener(v -> ((MainActivity) requireActivity()).navigate(MainActivity.NAV_RECENT));
        recentHead.addView(all);

        recentBox = column(c);
        page.addView(recentBox);
        scanStatus = label(c, "Storage information updates on this device.", 10, UI.MUTED);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = UI.dp(c, 13);
        page.addView(scanStatus, statusLp);
        return scroll;
    }

    private TextView stat(Context c, LinearLayout parent, String caption) {
        LinearLayout col = column(c);
        col.setGravity(Gravity.CENTER);
        TextView value = label(c, "--", 14, UI.TEXT);
        value.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        TextView name = label(c, caption, 9, UI.MUTED);
        name.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.topMargin = UI.dp(c, 3);
        col.addView(value);
        col.addView(name, nlp);
        parent.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        if ("USED".equals(caption)) usedT = value; else freeT = value;
        return value;
    }

    private LinearLayout.LayoutParams actionWeight() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private View action(Context c, String glyph, String title, int destination) {
        LinearLayout item = column(c);
        item.setGravity(Gravity.CENTER);
        item.setPadding(UI.dp(c, 3), UI.dp(c, 4), UI.dp(c, 3), UI.dp(c, 4));
        TextView icon = label(c, glyph, 23, UI.VIOLET);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(UI.round(c, 0x241A1238, 17));
        item.addView(icon, new LinearLayout.LayoutParams(UI.dp(c, 56), UI.dp(c, 54)));
        TextView name = label(c, title, 10.5f, UI.SOFT);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = UI.dp(c, 7);
        item.addView(name, np);
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(v -> ((MainActivity) requireActivity()).navigate(destination));
        return item;
    }

    @Override public void onStart() {
        super.onStart();
        StorageScanner.get().addListener(listener);
        StorageScanner sc = StorageScanner.get();
        if (sc.result() == null && !sc.isRunning()) sc.start(requireContext());
        refresh();
    }

    @Override public void onStop() {
        super.onStop();
        StorageScanner.get().removeListener(listener);
    }

    private void refresh() {
        if (!isAdded() || getView() == null || ring == null) return;
        Context c = requireContext();
        long[] st = StorageHelper.stat(StorageHelper.primary());
        long total = st[0], free = st[1], used = Math.max(0, total - free);
        float usedFrac = total > 0 ? (float) used / total : 0f;
        String pct = total > 0 ? Math.round(usedFrac * 100) + "%" : "--";
        usedT.setText(FileUtils.size(used));
        freeT.setText(FileUtils.size(free));
        totalT.setText(FileUtils.size(used) + " used  /  " + FileUtils.size(total) + " total");
        // Single violet progress ring keeps the dashboard visually quiet.
        ring.setData(usedFrac, new float[0], new int[0], pct, "USED", "");

        recentBox.removeAllViews();
        List<ActivityLog.Entry> log = ActivityLog.list(c);
        if (log.isEmpty()) {
            TextView empty = label(c, "Your recent file activity will appear here.", 12, UI.MUTED);
            empty.setPadding(UI.dp(c, 2), UI.dp(c, 13), 0, UI.dp(c, 13));
            recentBox.addView(empty);
        }
        for (int i = 0; i < log.size() && i < 3; i++) {
            final ActivityLog.Entry e = log.get(i);
            addRecent(c, e, i == Math.min(log.size(), 3) - 1);
        }
        StorageScanner.Result result = StorageScanner.get().result();
        if (result == null) scanStatus.setText(StorageScanner.get().isRunning()
                ? "Updating storage information…" : "Storage information updates on this device.");
        else scanStatus.setText("Scanned on this device · Some protected app folders may be excluded.");
    }

    private void addRecent(Context c, ActivityLog.Entry entry, boolean last) {
        LinearLayout item = row(c);
        item.setPadding(UI.dp(c, 2), UI.dp(c, 12), UI.dp(c, 2), UI.dp(c, 12));
        TextView icon = label(c, "▤", 19, UI.VIOLET);
        icon.setGravity(Gravity.CENTER);
        item.addView(icon, new LinearLayout.LayoutParams(UI.dp(c, 38), UI.dp(c, 38)));
        LinearLayout mid = column(c);
        mid.setPadding(UI.dp(c, 11), 0, UI.dp(c, 8), 0);
        TextView title = label(c, entry.text, 12.5f, UI.TEXT);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView when = label(c, FileUtils.date(entry.time), 10.5f, UI.MUTED);
        LinearLayout.LayoutParams whenLp = new LinearLayout.LayoutParams(-1, -2);
        whenLp.topMargin = UI.dp(c, 3);
        mid.addView(title);
        mid.addView(when, whenLp);
        item.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = label(c, "›", 24, UI.MUTED);
        item.addView(more);
        item.setOnClickListener(v -> RecentFragment.openEntry((MainActivity) requireActivity(), entry));
        recentBox.addView(item);
        if (!last) {
            View line = new View(c);
            line.setBackgroundColor(UI.DIVIDER);
            recentBox.addView(line, new LinearLayout.LayoutParams(-1, UI.dp(c, 1)));
        }
    }
}
