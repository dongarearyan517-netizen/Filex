package com.tano.filex;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.InputFilter;
import android.text.InputType;
import android.view.WindowManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import java.io.File;
import java.util.Arrays;
import java.util.List;

public class PrivateFragment extends Fragment {
    private static boolean unlocked;
    private static long stoppedAt;
    private LinearLayout root;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

    static final String HOW =
            "How Private Space works\n\n"
            + "• It is a PIN LOCK, not encryption.\n"
            + "• Files you add are moved into TANO FILEX's own private app storage. Other apps, the Gallery and normal file browsing cannot see them, and TANO FILEX asks for your PIN before showing them.\n"
            + "• The PIN is stored only as a salted PBKDF2 hash. Repeated wrong PINs trigger longer and longer lock-outs.\n"
            + "• The files themselves are NOT encrypted. Anyone with root access, or a way to read this app's data (for example a forensic tool on an unlocked or compromised device), could read them.\n"
            + "• Screenshots and the recent-apps preview are blocked while this screen is open.\n"
            + "• Uninstalling TANO FILEX or clearing its data permanently deletes everything in Private Space. Export what you need to keep.\n"
            + "• If you forget the PIN, the only way back in is to reset Private Space, which deletes all private files.";

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        Context c = requireContext();
        ScrollView sv = new ScrollView(c);
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(c, 24);
        root.setPadding(pad, 0, pad, UI.dp(c, 32));
        sv.addView(root);
        return sv;
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        render();
    }

    @Override public void onStop() {
        super.onStop();
        stoppedAt = System.currentTimeMillis();
        requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override public void onStart() {
        super.onStart();
        requireActivity().getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        if (unlocked && stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > 60000) {
            unlocked = false;
            if (root != null) render();
        }
    }

    @Override public void onDestroyView() {
        super.onDestroyView();
        unlocked = false; // leaving the screen locks Private Space
        if (getActivity() != null) getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    private EditText pinField(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(12)});
        e.setTextColor(UI.TEXT);
        e.setHintTextColor(UI.MUTED);
        e.setSingleLine(true);
        return e;
    }

    private TextView primary(Context c, String label) {
        TextView b = UI.button(c, label);
        b.setTextColor(0xFFFFFFFF);
        b.setBackground(UI.round(c, UI.PURPLE, 24));
        b.setPadding(UI.dp(c, 28), UI.dp(c, 13), UI.dp(c, 28), UI.dp(c, 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = UI.dp(c, 16);
        b.setLayoutParams(lp);
        return b;
    }

    private void render() {
        if (!isAdded()) return;
        root.removeAllViews();
        if (!PrivateVault.hasPin(requireContext())) renderSetup();
        else if (!unlocked) renderLock();
        else renderVault();
    }

    private void renderSetup() {
        final Context c = requireContext();
        root.addView(UI.text(c, "Set up Private Space", 22, UI.TEXT));
        TextView d = UI.text(c, HOW, 13, UI.SOFT);
        d.setPadding(0, UI.dp(c, 12), 0, UI.dp(c, 16));
        root.addView(d);
        final EditText p1 = pinField(c, "Choose a PIN (4–12 digits)");
        final EditText p2 = pinField(c, "Repeat PIN");
        root.addView(p1);
        root.addView(p2);
        TextView b = primary(c, "Create PIN");
        b.setOnClickListener(x -> {
            String a = p1.getText().toString(), bb = p2.getText().toString();
            if (a.length() < 4) { UI.toast(c, "The PIN needs at least 4 digits."); return; }
            if (!a.equals(bb)) { UI.toast(c, "The two PINs don't match."); return; }
            try {
                PrivateVault.setPin(c, a);
                unlocked = true;
                render();
            } catch (Exception e) {
                UI.alert(c, "Could not save PIN", Tasks.msg(e));
            }
        });
        root.addView(b);
    }

    private void renderLock() {
        final Context c = requireContext();
        root.addView(UI.text(c, "Private Space is locked", 22, UI.TEXT));
        final TextView msg = UI.text(c, "Enter your PIN to continue.", 13, UI.SOFT);
        msg.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 12));
        root.addView(msg);
        final EditText pin = pinField(c, "PIN");
        root.addView(pin);
        TextView go = primary(c, "Unlock");
        go.setOnClickListener(x -> {
            long wait = Prefs.getLong(c, "pin_lock", 0) - System.currentTimeMillis();
            if (wait > 0) { msg.setText("Too many attempts. Try again in " + (wait / 1000 + 1) + " seconds."); return; }
            if (PrivateVault.verify(c, pin.getText().toString())) {
                Prefs.putInt(c, "pin_fail", 0);
                unlocked = true;
                render();
            } else {
                int f = Prefs.getInt(c, "pin_fail", 0) + 1;
                Prefs.putInt(c, "pin_fail", f);
                if (f % 5 == 0) {
                    long ms = PrivateVault.lockoutMillis(f);
                    Prefs.putLong(c, "pin_lock", System.currentTimeMillis() + ms);
                    msg.setText("Too many attempts. Locked for " + (ms / 1000) + " seconds.");
                } else msg.setText("Wrong PIN.");
                pin.setText("");
            }
        });
        root.addView(go);
        TextView how = UI.button(c, "How protection works");
        how.setOnClickListener(x -> UI.alert(c, "Private Space", HOW));
        root.addView(how);
        TextView reset = UI.button(c, "Forgot PIN? Reset Private Space");
        reset.setTextColor(UI.MUTED);
        reset.setOnClickListener(x -> UI.confirm(c, "Reset Private Space?",
                "This permanently deletes ALL files in Private Space and removes the PIN. It cannot be undone.", "Delete everything", () -> {
                    PrivateVault.reset(c);
                    unlocked = false;
                    render();
                }));
        root.addView(reset);
    }

    private void renderVault() {
        final Context c = requireContext();
        root.addView(UI.text(c, "Private Space", 22, UI.TEXT));
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8));
        TextView imp = UI.button(c, "Import files");
        imp.setOnClickListener(x -> picker.launch(new String[]{"*/*"}));
        TextView lock = UI.button(c, "Lock");
        lock.setOnClickListener(x -> { unlocked = false; render(); });
        TextView chg = UI.button(c, "Change PIN");
        chg.setOnClickListener(x -> changePin());
        TextView how = UI.button(c, "How it works");
        how.setOnClickListener(x -> UI.alert(c, "Private Space", HOW));
        bar.addView(imp);
        bar.addView(lock);
        bar.addView(chg);
        bar.addView(how);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(bar);
        root.addView(hs);

        File[] files = PrivateVault.dir(c).listFiles();
        if (files == null || files.length == 0) {
            TextView t = UI.text(c, "Private Space is empty.\nTap Import files, or select files in All Files and choose Private.", 14, UI.MUTED);
            t.setPadding(0, UI.dp(c, 24), 0, 0);
            root.addView(t);
            return;
        }
        Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (final File f : files) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, UI.dp(c, 12), 0, UI.dp(c, 12));
            UI.ripple(row);
            TextView n = UI.text(c, f.getName(), 15, UI.TEXT);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            row.addView(n);
            row.addView(UI.text(c, FileUtils.size(f.length()) + "  ·  " + FileUtils.date(f.lastModified()), 12, UI.MUTED));
            row.setOnClickListener(x -> fileMenu(f));
            root.addView(row);
        }
    }

    private void fileMenu(final File f) {
        String[] opts = {"Open", "Export a copy to Downloads", "Restore to Downloads (remove from Private)", "Delete permanently"};
        new AlertDialog.Builder(requireContext()).setTitle(f.getName()).setItems(opts, (d, i) -> {
            switch (i) {
                case 0: FileOpen.open(requireActivity(), f, false); break;
                case 1: exportFile(f, false); break;
                case 2: exportFile(f, true); break;
                default:
                    UI.confirm(requireContext(), "Delete permanently?", f.getName() + " will be deleted and cannot be recovered.", "Delete", () -> {
                        FileUtils.deleteRecursive(f);
                        render();
                    });
            }
        }).show();
    }

    private void exportFile(final File f, final boolean move) {
        final Context c = requireContext();
        if (!Perm.has(c)) {
            UI.alert(c, "Storage access needed", "Exporting writes to your Downloads folder, which needs storage access. Grant it from the Home screen or Settings, then try again.");
            return;
        }
        Tasks.run(requireActivity(), move ? "Restoring" : "Exporting", ctl -> {
            File dest = PrivateVault.exportDir();
            if (move) FileUtils.move(f, dest, ctl.cancel, ctl);
            else FileUtils.copyTo(f, dest, ctl.cancel, ctl);
            return (move ? "Restored" : "Exported") + " to\n" + dest.getPath();
        }, (res, err) -> {
            if (!isAdded()) return;
            if (err != null) UI.alert(c, "Failed", Tasks.msg(err));
            else UI.alert(c, "Done", res);
            render();
        });
    }

    private void changePin() {
        final Context c = requireContext();
        UI.input(c, "New PIN (4–12 digits)", "New PIN", "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, a -> {
            if (a.length() < 4 || a.length() > 12) { UI.toast(c, "The PIN needs 4–12 digits."); return; }
            UI.input(c, "Repeat new PIN", "Repeat PIN", "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, b -> {
                if (!a.equals(b)) { UI.toast(c, "The PINs don't match."); return; }
                try { PrivateVault.setPin(c, a); UI.toast(c, "PIN changed"); } catch (Exception e) { UI.alert(c, "Error", Tasks.msg(e)); }
            });
        });
    }

    private void onPicked(final List<Uri> uris) {
        if (uris == null || uris.isEmpty() || !isAdded()) return;
        final Context c = requireContext();
        new AlertDialog.Builder(c).setTitle("Import " + uris.size() + " file(s)")
                .setMessage("Do you also want to delete the originals after importing? (Only works if the source allows deleting.)")
                .setPositiveButton("Import and delete originals", (x, w) -> doImport(uris, true))
                .setNeutralButton("Import, keep originals", (x, w) -> doImport(uris, false))
                .setNegativeButton("Cancel", null).show();
    }

    private void doImport(final List<Uri> uris, final boolean deleteOriginals) {
        final Context c = requireContext();
        Tasks.run(requireActivity(), "Importing", ctl -> {
            int ok = 0, fail = 0, removed = 0;
            for (Uri u : uris) {
                if (ctl.cancel.get()) break;
                try {
                    PrivateVault.importUri(c, u);
                    ok++;
                    if (deleteOriginals) {
                        try { if (DocumentsContract.deleteDocument(c.getContentResolver(), u)) removed++; } catch (Exception ignored) { }
                    }
                } catch (Exception e) {
                    fail++;
                }
            }
            return "Imported " + ok + " file(s)" + (fail > 0 ? ", " + fail + " failed" : "")
                    + (deleteOriginals ? "\nOriginals deleted: " + removed : "");
        }, (res, err) -> {
            if (!isAdded()) return;
            UI.alert(c, err != null ? "Import failed" : "Import finished", err != null ? Tasks.msg(err) : res);
            ActivityLog.add(c, "PRIVATE", "Imported files into Private Space", null);
            render();
        });
    }
}
