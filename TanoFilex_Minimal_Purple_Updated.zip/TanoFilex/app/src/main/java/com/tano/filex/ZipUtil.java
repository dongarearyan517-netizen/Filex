package com.tano.filex;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class ZipUtil {
    private ZipUtil() {}

    static final int OVERWRITE = 0, KEEP_BOTH = 1, SKIP = 2;
    static final int MAX_ENTRIES = 200000;
    private static final long SPACE_MARGIN = 32L * 1024 * 1024;

    // ------------------------------------------------------------------ create

    /**
     * Creates a ZIP. Data is written to a temporary ".tano_part" file and renamed only on success, so a
     * cancelled or failed run never leaves a broken archive. Returns the number of unreadable files skipped.
     */
    static int create(List<File> items, File out, Tasks.Ctl ctl) throws IOException {
        int[] skipped = {0};
        Set<String> used = new HashSet<>();
        File tmp = new File(out.getParentFile(), out.getName() + ".tano_part");
        Set<String> skipCanon = new HashSet<>();
        skipCanon.add(out.getCanonicalPath());
        skipCanon.add(tmp.getCanonicalPath());
        boolean ok = false;
        try {
            try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 65536))) {
                byte[] buf = new byte[65536];
                for (File f : items) {
                    if (ctl.cancel.get()) break;
                    String n = f.getName();
                    String top = n;
                    int k = 1;
                    while (!used.add(top.toLowerCase())) top = n + "_" + (k++);
                    add(z, f, top, skipCanon, buf, ctl, skipped);
                }
            }
            if (ctl.cancel.get()) return skipped[0];
            if (!tmp.renameTo(out)) throw new IOException("Could not save the ZIP as " + out.getName());
            ok = true;
        } finally {
            if (!ok) tmp.delete();
        }
        return skipped[0];
    }

    private static void add(ZipOutputStream z, File f, String name, Set<String> skipCanon, byte[] buf,
                            Tasks.Ctl ctl, int[] skipped) throws IOException {
        if (ctl.cancel.get()) return;
        if (skipCanon.contains(f.getCanonicalPath())) return;
        if (f.isDirectory()) {
            if (Files.isSymbolicLink(f.toPath())) return;
            ZipEntry e = new ZipEntry(name + "/");
            e.setTime(f.lastModified());
            z.putNextEntry(e);
            z.closeEntry();
            File[] ch = f.listFiles();
            if (ch == null) { skipped[0]++; return; }
            for (File c : ch) add(z, c, name + "/" + c.getName(), skipCanon, buf, ctl, skipped);
        } else {
            ctl.status(f.getName());
            InputStream in;
            try { in = new FileInputStream(f); } catch (IOException ex) { skipped[0]++; return; }
            try {
                ZipEntry e = new ZipEntry(name);
                e.setTime(f.lastModified());
                z.putNextEntry(e);
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (ctl.cancel.get()) break;
                    z.write(buf, 0, n);
                }
                z.closeEntry();
            } finally {
                in.close();
            }
        }
    }

    // ------------------------------------------------------------------ open / list

    static ZipFile open(File f) throws IOException {
        try {
            return new ZipFile(f);
        } catch (IllegalArgumentException e) {
            return new ZipFile(f, Charset.forName("Cp437"));
        }
    }

    /** Lists entries as {name, sizeText}; stops after max and appends a note. */
    static List<String[]> list(File zip, int max) throws IOException {
        List<String[]> out = new ArrayList<>();
        try (ZipFile zf = open(zip)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            int total = 0;
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                total++;
                if (out.size() < max) {
                    out.add(new String[]{e.getName(), e.isDirectory() ? "" : FileUtils.size(Math.max(0, e.getSize()))});
                }
            }
            if (total > max) out.add(new String[]{"… and " + (total - max) + " more entries", ""});
        }
        return out;
    }

    // ------------------------------------------------------------------ extract

    static final class Plan {
        int entries;
        int conflicts;
        int unsafe;
        long bytes;
        boolean sizeUnknown;
        final List<String> sample = new ArrayList<>();
    }

    private static boolean inside(String root, String path) {
        return path.equals(root) || path.startsWith(root + File.separator);
    }

    /** Dry run: counts entries, total size, files that already exist and unsafe ("../") entries. Writes nothing. */
    static Plan inspect(File zip, File dest, Tasks.Ctl ctl) throws IOException {
        Plan p = new Plan();
        String root = dest.getCanonicalPath();
        try (ZipFile zf = open(zip)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                if (ctl.cancel.get()) break;
                ZipEntry e = en.nextElement();
                if (++p.entries > MAX_ENTRIES) {
                    throw new IOException("This archive has more than " + MAX_ENTRIES + " entries. Extraction was refused for safety.");
                }
                File out = new File(dest, e.getName());
                if (!inside(root, out.getCanonicalPath())) { p.unsafe++; continue; }
                if (e.isDirectory()) continue;
                long s = e.getSize();
                if (s < 0) p.sizeUnknown = true; else p.bytes += s;
                if (out.exists()) {
                    p.conflicts++;
                    if (p.sample.size() < 3) p.sample.add(e.getName());
                }
            }
        }
        return p;
    }

    /** Free space available at dest (or its closest existing parent). */
    static long freeSpace(File dest) {
        File f = dest;
        while (f != null && !f.exists()) f = f.getParentFile();
        return f == null ? 0 : f.getUsableSpace();
    }

    /**
     * Extracts with zip-slip protection. Each file is written to a temporary ".tano_part" file and moved into
     * place only when complete. Returns {written, skippedExisting, skippedUnsafe}.
     */
    static int[] extract(File zip, File dest, int policy, Tasks.Ctl ctl) throws IOException {
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("Cannot create folder " + dest.getPath());
        if (!dest.isDirectory()) throw new IOException(dest.getPath() + " is not a folder");
        String root = dest.getCanonicalPath();
        int written = 0, skipped = 0, unsafe = 0;
        byte[] buf = new byte[65536];
        try (ZipFile zf = open(zip)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                if (ctl.cancel.get()) break;
                ZipEntry e = en.nextElement();
                File out = new File(dest, e.getName());
                if (!inside(root, out.getCanonicalPath())) { unsafe++; continue; }
                if (e.isDirectory()) {
                    if (out.exists() && !out.isDirectory()) { skipped++; continue; }
                    out.mkdirs();
                    continue;
                }
                File par = out.getParentFile();
                if (par != null && !par.isDirectory()) {
                    if (par.exists() || !par.mkdirs()) { skipped++; continue; }
                }
                File target = out;
                if (out.exists()) {
                    if (out.isDirectory() || policy == SKIP) { skipped++; continue; }
                    if (policy == KEEP_BOTH) target = FileUtils.unique(par, out.getName());
                }
                ctl.status(e.getName());
                File tmp = new File(par, target.getName() + ".tano_part");
                boolean complete = false;
                try (InputStream in = zf.getInputStream(e); OutputStream os = new FileOutputStream(tmp)) {
                    int n;
                    long sinceCheck = 0;
                    boolean cancelled = false;
                    while ((n = in.read(buf)) > 0) {
                        if (ctl.cancel.get()) { cancelled = true; break; }
                        os.write(buf, 0, n);
                        sinceCheck += n;
                        if (sinceCheck > 8L * 1024 * 1024) {
                            sinceCheck = 0;
                            if (tmp.getParentFile().getUsableSpace() < 16L * 1024 * 1024) throw new IOException("Storage is full. Extraction stopped.");
                        }
                    }
                    complete = !cancelled;
                } finally {
                    if (!complete) tmp.delete();
                }
                if (!complete) break;
                if (target.exists() && !target.delete()) { tmp.delete(); skipped++; continue; }
                if (!tmp.renameTo(target)) { tmp.delete(); throw new IOException("Could not write " + target.getName()); }
                if (e.getTime() > 0) target.setLastModified(e.getTime());
                written++;
            }
        }
        return new int[]{written, skipped, unsafe};
    }

    static String humanSpace(long b) { return FileUtils.size(b); }

    static long margin() { return SPACE_MARGIN; }
}
