package com.tano.filex;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class PermissionFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        Context c = requireContext();
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int p = UI.dp(c, 32);
        col.setPadding(p, p, p, p);
        TextView t = UI.text(c, "Storage access needed", 22, UI.TEXT);
        t.setGravity(Gravity.CENTER);
        col.addView(t);
        String why = Build.VERSION.SDK_INT >= 30
                ? "A file manager needs “All files access” to browse, copy, move, rename, delete and ZIP your files. Android will open a settings page: switch it on for TANO FILEX, then come back."
                : "A file manager needs permission to read and write your storage to browse, copy, move, rename, delete and ZIP your files.";
        TextView d = UI.text(c, why + "\n\nTANO FILEX works fully offline and never uploads your files.", 14, UI.SOFT);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, UI.dp(c, 16), 0, UI.dp(c, 24));
        col.addView(d);
        TextView b = UI.button(c, "Grant access");
        b.setTextColor(0xFFFFFFFF);
        b.setBackground(UI.round(c, UI.PURPLE, 24));
        b.setPadding(UI.dp(c, 32), UI.dp(c, 14), UI.dp(c, 32), UI.dp(c, 14));
        b.setOnClickListener(x -> Perm.request(requireActivity(), MainActivity.REQ_STORAGE));
        col.addView(b);
        return col;
    }
}
