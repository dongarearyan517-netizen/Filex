package com.tano.filex;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class FileOpen {
    private FileOpen() {}

    static void open(Activity a, File f, boolean log) {
        if (log) ActivityLog.add(a, "OPEN", "Opened " + f.getName(), f.getPath());
        if (PreviewActivity.supports(FileUtils.ext(f.getName()))) {
            a.startActivity(new Intent(a, PreviewActivity.class).putExtra("path", f.getPath()));
        } else {
            external(a, f);
        }
    }

    static void external(Activity a, File f) {
        try {
            Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, FileUtils.mime(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(i, "Open with"));
        } catch (ActivityNotFoundException e) {
            UI.toast(a, "No app installed can open this file type.");
        } catch (Exception e) {
            UI.toast(a, "Cannot open file: " + Tasks.msg(e));
        }
    }

    static void share(Activity a, List<File> files) {
        ArrayList<Uri> uris = new ArrayList<>();
        File first = null;
        try {
            for (File f : files) {
                if (f.isFile()) {
                    if (first == null) first = f;
                    uris.add(FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f));
                }
            }
        } catch (Exception e) {
            UI.toast(a, "Cannot share: " + Tasks.msg(e));
            return;
        }
        if (uris.isEmpty()) {
            UI.toast(a, "Nothing to share. Folders can't be shared directly; create a ZIP first.");
            return;
        }
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            i.setType(FileUtils.mime(first));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            i.setType("*/*");
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ClipData cd = ClipData.newRawUri("files", uris.get(0));
        for (int k = 1; k < uris.size(); k++) cd.addItem(new ClipData.Item(uris.get(k)));
        i.setClipData(cd);
        a.startActivity(Intent.createChooser(i, "Share"));
    }
}
