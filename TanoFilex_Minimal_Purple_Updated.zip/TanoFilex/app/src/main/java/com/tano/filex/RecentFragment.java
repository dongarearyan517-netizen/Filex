package com.tano.filex;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.io.File;
import java.util.List;

public class RecentFragment extends Fragment {
    private LinearLayout box;

    static void openEntry(MainActivity a, ActivityLog.Entry e) {
        if (e.path == null || e.path.isEmpty()) { UI.toast(a, "No location stored for this entry."); return; }
        File f = new File(e.path);
        if (!f.exists()) { UI.toast(a, "This item no longer exists."); return; }
        if (f.isDirectory()) a.openPath(f, false);
        else if (e.type.equals("OPEN")) FileOpen.open(a, f, false);
        else a.openPath(f.getParentFile() != null ? f.getParentFile() : StorageHelper.primary(), false);
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        Context c = requireContext();
        ScrollView sv = new ScrollView(c);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(c, 20);
        col.setPadding(pad, 0, pad, UI.dp(c, 32));
        sv.addView(col);
        TextView clear = UI.button(c, "Clear history");
        clear.setOnClickListener(x -> UI.confirm(requireContext(), "Clear recent activity?", "This only clears the list. No files are touched.", "Clear", () -> {
            ActivityLog.clear(requireContext());
            fill();
        }));
        col.addView(clear, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        col.addView(box);
        return sv;
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        fill();
    }

    private void fill() {
        Context c = requireContext();
        box.removeAllViews();
        List<ActivityLog.Entry> log = ActivityLog.list(c);
        if (log.isEmpty()) {
            TextView t = UI.text(c, "No recent activity yet.", 14, UI.MUTED);
            t.setPadding(0, UI.dp(c, 16), 0, 0);
            box.addView(t);
            return;
        }
        for (final ActivityLog.Entry e : log) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, UI.dp(c, 12), 0, UI.dp(c, 12));
            UI.ripple(row);
            TextView t = UI.text(c, e.text, 15, UI.TEXT);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            row.addView(t);
            row.addView(UI.text(c, e.type + "  ·  " + FileUtils.date(e.time), 12, UI.MUTED));
            row.setOnClickListener(x -> openEntry((MainActivity) requireActivity(), e));
            box.addView(row);
        }
    }
}
