package com.tano.filex;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import java.io.File;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Finds files with identical content: (1) group by exact size (files >= 10 KB), (2) compare a
 * fingerprint of the first and last 64 KB, (3) confirm with a full SHA-256. Only files whose full
 * SHA-256 matches are reported. File names are never used. Cancellable.
 */
final class DuplicateFinder {
    private DuplicateFinder() {}

    interface Callback {
        void progress(String status);
        void done(List<FileItem> items, int groups, long wasted);
        void error(String message);
    }

    private static volatile List<FileItem> lastItems;
    private static volatile int lastGroups;
    private static volatile long lastWasted;
    static List<FileItem> last() { return lastItems; }
    static int lastGroups() { return lastGroups; }
    static long lastWasted() { return lastWasted; }
    static void clear() { lastItems = null; }

    private static final long MIN_SIZE = 10 * 1024;

    @SuppressWarnings("unchecked")
    static void run(Context ctx, final AtomicBoolean cancel, final Callback cb) {
        final Context app = ctx.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            try {
                final HashMap<Long, Object> bySize = new HashMap<>();
                final long[] seen = {0};
                for (StorageHelper.Volume v : StorageHelper.volumes(app)) {
                    if (cancel.get()) return;
                    FileWalker.walk(v.root, (path, size, mod) -> {
                        if (size < MIN_SIZE) return;
                        Object o = bySize.get(size);
                        if (o == null) bySize.put(size, path);
                        else if (o instanceof String) {
                            List<String> l = new ArrayList<>(2);
                            l.add((String) o);
                            l.add(path);
                            bySize.put(size, l);
                        } else ((List<String>) o).add(path);
                        if (++seen[0] % 2000 == 0) {
                            final String m = "Scanning files… " + seen[0];
                            main.post(() -> cb.progress(m));
                        }
                    }, cancel);
                }
                if (cancel.get()) return;
                List<List<String>> groups = new ArrayList<>();
                List<Long> sizes = new ArrayList<>();
                int checked = 0;
                for (Map.Entry<Long, Object> e : bySize.entrySet()) {
                    if (!(e.getValue() instanceof List)) continue;
                    List<String> same = (List<String>) e.getValue();
                    Map<String, List<String>> quick = new HashMap<>();
                    for (String p : same) {
                        if (cancel.get()) return;
                        String q = quickHash(new File(p), e.getKey());
                        if (q != null) quick.computeIfAbsent(q, k -> new ArrayList<>()).add(p);
                    }
                    for (List<String> qs : quick.values()) {
                        if (qs.size() < 2) continue;
                        Map<String, List<String>> full = new HashMap<>();
                        for (String p : qs) {
                            if (cancel.get()) return;
                            final String m = "Verifying content (SHA-256)… " + (++checked) + " files";
                            main.post(() -> cb.progress(m));
                            String h;
                            try { h = FileUtils.hash(new File(p), "SHA-256", cancel); } catch (Exception ex) { h = null; }
                            if (h != null) full.computeIfAbsent(h, k -> new ArrayList<>()).add(p);
                        }
                        for (List<String> g : full.values()) {
                            if (g.size() >= 2) { groups.add(g); sizes.add(e.getKey()); }
                        }
                    }
                }
                if (cancel.get()) return;
                Integer[] order = new Integer[groups.size()];
                for (int i = 0; i < order.length; i++) order[i] = i;
                final List<Long> sz = sizes;
                final List<List<String>> gr = groups;
                Arrays.sort(order, (a, b) ->
                        Long.compare(sz.get(b) * (gr.get(b).size() - 1), sz.get(a) * (gr.get(a).size() - 1)));
                final List<FileItem> out = new ArrayList<>();
                long wasted = 0;
                int gi = 0;
                for (int idx : order) {
                    gi++;
                    List<String> g = groups.get(idx);
                    long size = sizes.get(idx);
                    wasted += size * (g.size() - 1);
                    List<FileItem> items = new ArrayList<>();
                    for (String p : g) {
                        File f = new File(p);
                        FileItem it = new FileItem(p, false, size, f.lastModified(), Category.of(f.getName()));
                        it.group = gi;
                        it.groupCount = g.size();
                        items.add(it);
                    }
                    Collections.sort(items, (a, b) -> Long.compare(a.mod, b.mod));
                    out.addAll(items);
                }
                lastItems = out;
                lastGroups = gi;
                lastWasted = wasted;
                final int fg = gi;
                final long fw = wasted;
                main.post(() -> cb.done(out, fg, fw));
            } catch (Throwable t) {
                final String m = "Duplicate scan failed: " + t;
                main.post(() -> cb.error(m));
            }
        }, "tano-dups").start();
    }

    private static String quickHash(File f, long size) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] buf = new byte[65536];
            int n = r.read(buf);
            if (n > 0) md.update(buf, 0, n);
            if (size > 131072) {
                r.seek(size - 65536);
                n = r.read(buf);
                if (n > 0) md.update(buf, 0, n);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
