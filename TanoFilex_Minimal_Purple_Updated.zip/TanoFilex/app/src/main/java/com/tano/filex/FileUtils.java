package com.tano.filex;

import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.regex.Pattern;

final class FileUtils {
    private FileUtils() {}

    static String ext(String name) {
        int i = name.lastIndexOf('.');
        return (i <= 0 || i == name.length() - 1) ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    static String size(long b) {
        if (b < 1024) return b + " B";
        double v = b;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        while (v >= 1024 && i < 3) { v /= 1024; i++; }
        return String.format(Locale.US, v >= 100 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    static String date(long t) {
        return new SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(t));
    }

    static String mime(File f) {
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f.getName()));
        return m == null ? "*/*" : m;
    }

    static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int i = name.lastIndexOf('.');
        String base = i > 0 ? name.substring(0, i) : name;
        String ex = i > 0 ? name.substring(i) : "";
        for (int n = 1; ; n++) {
            f = new File(dir, base + " (" + n + ")" + ex);
            if (!f.exists()) return f;
        }
    }

    /** true if child is the same as, or located inside, parent. */
    static boolean isInside(File parent, File child) {
        try {
            String p = parent.getCanonicalPath(), c = child.getCanonicalPath();
            return c.equals(p) || c.startsWith(p + File.separator);
        } catch (IOException e) {
            return true;
        }
    }

    static void copyRecursive(File src, File dst, AtomicBoolean cancel, Tasks.Ctl ctl) throws IOException {
        if (cancel != null && cancel.get()) return;
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("Cannot create " + dst);
            File[] ch = src.listFiles();
            if (ch == null) throw new IOException("Cannot read " + src);
            for (File c : ch) copyRecursive(c, new File(dst, c.getName()), cancel, ctl);
        } else {
            if (ctl != null) ctl.status(src.getName());
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) {
                    if (cancel != null && cancel.get()) break;
                    out.write(b, 0, n);
                }
            }
            dst.setLastModified(src.lastModified());
        }
    }

    static boolean deleteRecursive(File f) {
        try {
            if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) {
                File[] ch = f.listFiles();
                if (ch != null) for (File c : ch) deleteRecursive(c);
            }
        } catch (Exception ignored) { }
        return f.delete();
    }

    /** Checks that a finished copy has the same size (and for folders the same file/folder counts). */
    static void verifyCopy(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            long[] a = new long[3], b = new long[3];
            tree(src, a, null);
            tree(dst, b, null);
            if (a[0] != b[0] || a[1] != b[1] || a[2] != b[2]) throw new IOException("Copy verification failed for " + src.getName());
        } else if (src.length() != dst.length()) {
            throw new IOException("Copy verification failed for " + src.getName() + " (size differs)");
        }
    }

    /** Copies src into dstDir under a non-conflicting name. A failed or cancelled copy leaves nothing behind. */
    static void copyTo(File src, File dstDir, AtomicBoolean cancel, Tasks.Ctl ctl) throws IOException {
        File dst = unique(dstDir, src.getName());
        try {
            copyRecursive(src, dst, cancel, ctl);
            if (cancel != null && cancel.get()) { deleteRecursive(dst); return; }
            verifyCopy(src, dst);
        } catch (IOException e) {
            deleteRecursive(dst);
            throw e;
        }
    }

    /**
     * Moves src into dstDir. Uses an atomic rename when possible; otherwise copies, verifies the copy and
     * only then deletes the original, so a failure never loses data.
     */
    static void move(File src, File dstDir, AtomicBoolean cancel, Tasks.Ctl ctl) throws IOException {
        File dst = unique(dstDir, src.getName());
        if (src.renameTo(dst)) return;
        try {
            copyRecursive(src, dst, cancel, ctl);
            if (cancel != null && cancel.get()) { deleteRecursive(dst); return; }
            verifyCopy(src, dst);
        } catch (IOException e) {
            deleteRecursive(dst);
            throw e;
        }
        if (!deleteRecursive(src)) {
            throw new IOException("Copied to " + dst.getPath() + " but the original could not be fully deleted");
        }
    }

    static boolean validName(String n) {
        if (n == null) return false;
        String t = n.trim();
        if (t.isEmpty() || t.equals(".") || t.equals("..")) return false;
        if (t.indexOf('/') >= 0 || t.indexOf('\0') >= 0) return false;
        return t.getBytes(java.nio.charset.StandardCharsets.UTF_8).length <= 255;
    }

    /** Renames in place. Handles case-only renames on case-insensitive storage and never overwrites. */
    static File rename(File f, String n) throws IOException {
        if (!validName(n)) throw new IOException("That is not a valid file name.");
        File parent = f.getParentFile();
        File t = new File(parent, n);
        if (t.getName().equals(f.getName())) return f;
        boolean caseOnly = t.getName().equalsIgnoreCase(f.getName());
        if (t.exists()) {
            boolean same = false;
            try { same = Files.isSameFile(f.toPath(), t.toPath()); } catch (Exception ignored) { }
            if (!(caseOnly && same)) throw new IOException("\"" + n + "\" already exists.");
        }
        if (caseOnly) {
            File tmp = new File(parent, ".tano_rename_" + System.nanoTime());
            if (!f.renameTo(tmp)) throw new IOException("Rename failed (read-only location?).");
            if (!tmp.renameTo(t)) {
                tmp.renameTo(f);
                throw new IOException("Rename failed.");
            }
            return t;
        }
        if (!f.renameTo(t)) throw new IOException("Rename failed (read-only location?).");
        return t;
    }

    /** acc = {bytes, files, folders} */
    static void tree(File f, long[] acc, AtomicBoolean cancel) {
        if (cancel != null && cancel.get()) return;
        boolean link = false;
        try { link = Files.isSymbolicLink(f.toPath()); } catch (Exception ignored) { }
        if (f.isDirectory() && !link) {
            acc[2]++;
            File[] ch = f.listFiles();
            if (ch != null) for (File x : ch) tree(x, acc, cancel);
        } else {
            acc[0] += f.length();
            acc[1]++;
        }
    }

    static String hash(File f, String algo, AtomicBoolean cancel) throws Exception {
        MessageDigest md = MessageDigest.getInstance(algo);
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) {
                if (cancel != null && cancel.get()) return null;
                md.update(b, 0, n);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (byte x : md.digest()) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    static Predicate<String> matcher(String q) {
        final String lq = q.toLowerCase(Locale.ROOT);
        if (lq.contains("*") || lq.contains("?")) {
            StringBuilder sb = new StringBuilder();
            for (char ch : lq.toCharArray()) {
                if (ch == '*') sb.append(".*");
                else if (ch == '?') sb.append('.');
                else sb.append(Pattern.quote(String.valueOf(ch)));
            }
            final Pattern p = Pattern.compile(sb.toString());
            return s -> p.matcher(s.toLowerCase(Locale.ROOT)).matches();
        }
        return s -> s.toLowerCase(Locale.ROOT).contains(lq);
    }

    static void searchTree(File root, Predicate<String> pm, List<FileItem> out, int max, boolean hidden, AtomicBoolean cancel) {
        ArrayDeque<File> st = new ArrayDeque<>();
        st.push(root);
        while (!st.isEmpty() && out.size() < max && !cancel.get()) {
            File[] fs = st.pop().listFiles();
            if (fs == null) continue;
            for (File f : fs) {
                String n = f.getName();
                if (!hidden && n.startsWith(".")) continue;
                boolean isDir = f.isDirectory();
                if (pm.test(n)) out.add(new FileItem(f));
                if (out.size() >= max) return;
                if (isDir) {
                    try { if (Files.isSymbolicLink(f.toPath())) continue; } catch (Exception ignored) { }
                    st.push(f);
                }
            }
        }
    }
}
