package com.tano.filex;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class ActivityLog {
    private ActivityLog() {}

    static final class Entry {
        String type, text, path;
        long time;
    }

    static synchronized void add(Context c, String type, String text, String path) {
        try {
            JSONArray old = new JSONArray(Prefs.str(c, "log", "[]"));
            JSONArray n = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", type);
            o.put("x", text);
            o.put("p", path == null ? "" : path);
            o.put("ts", System.currentTimeMillis());
            n.put(o);
            for (int i = 0; i < old.length() && i < 199; i++) n.put(old.get(i));
            Prefs.putStr(c, "log", n.toString());
        } catch (Exception ignored) { }
    }

    static synchronized List<Entry> list(Context c) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.str(c, "log", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Entry e = new Entry();
                e.type = o.optString("t");
                e.text = o.optString("x");
                e.path = o.optString("p");
                e.time = o.optLong("ts");
                out.add(e);
            }
        } catch (Exception ignored) { }
        return out;
    }

    static synchronized void clear(Context c) { Prefs.putStr(c, "log", "[]"); }
}
