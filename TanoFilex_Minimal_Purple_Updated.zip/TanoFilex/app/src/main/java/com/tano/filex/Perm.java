package com.tano.filex;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

final class Perm {
    private Perm() {}

    static boolean has(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(c, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(c, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    static void openAppSettings(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName())));
        } catch (Exception e) {
            UI.toast(a, "Open Android Settings > Apps > TANO FILEX > Permissions and allow storage.");
        }
    }

    /**
     * Android 11+: opens the "All files access" page. Android 8-10: shows the system permission prompt;
     * if the user chose "Don't ask again" the prompt can no longer appear, so the app settings page opens instead.
     */
    static void request(Activity a, int code) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName())));
            } catch (Exception e) {
                try {
                    a.startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    openAppSettings(a);
                }
            }
            return;
        }
        boolean asked = Prefs.getBool(a, "perm_asked", false);
        boolean rationale = ActivityCompat.shouldShowRequestPermissionRationale(a, Manifest.permission.READ_EXTERNAL_STORAGE);
        if (asked && !rationale && !has(a)) {
            openAppSettings(a);
            return;
        }
        Prefs.putBool(a, "perm_asked", true);
        ActivityCompat.requestPermissions(a, new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, code);
    }
}
