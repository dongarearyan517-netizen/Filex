package com.tano.filex;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private Prefs() {}
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("tano", Context.MODE_PRIVATE);
    }
    static int getInt(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void putInt(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static long getLong(Context c, String k, long d) { return sp(c).getLong(k, d); }
    static void putLong(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }
    static boolean getBool(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static String str(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putStr(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
}
