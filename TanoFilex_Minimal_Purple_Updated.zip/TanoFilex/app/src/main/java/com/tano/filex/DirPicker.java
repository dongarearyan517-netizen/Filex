package com.tano.filex;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/** Simple in-app folder chooser. */
final class DirPicker {
    private DirPicker() {}

    static void show(Context c, File start, Consumer<File> chosen) {
        File s = (start == null || !start.isDirectory()) ? StorageHelper.primary() : start;
        final File[] cur = {s};
        final List<File> entries = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        final ListView lv = new ListView(c);
        final ArrayAdapter<String> ad = new ArrayAdapter<>(c, android.R.layout.simple_list_item_1, labels);
        lv.setAdapter(ad);
        final AlertDialog d = new AlertDialog.Builder(c).setTitle("Choose folder").setView(lv)
                .setPositiveButton("Use this folder", (x, w) -> chosen.accept(cur[0]))
                .setNegativeButton("Cancel", null).create();
        final Runnable refresh = () -> {
            entries.clear();
            labels.clear();
            File parent = cur[0].getParentFile();
            if (parent != null && parent.canRead()) { entries.add(parent); labels.add("↑  .."); }
            File[] fs = cur[0].listFiles((FileFilter) File::isDirectory);
            if (fs != null) {
                Arrays.sort(fs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
                for (File f : fs) { entries.add(f); labels.add(f.getName() + "/"); }
            }
            ad.notifyDataSetChanged();
            d.setTitle(cur[0].getPath());
        };
        lv.setOnItemClickListener((parentView, v, pos, id) -> { cur[0] = entries.get(pos); refresh.run(); });
        d.show();
        refresh.run();
    }
}
