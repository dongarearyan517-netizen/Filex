package com.tano.filex;

import android.app.Activity;
import android.graphics.Typeface;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

final class ZipActions {
    private ZipActions() {}

    // ------------------------------------------------------------------ create

    static void create(final Activity a, final List<File> items, File defDir, final Runnable after) {
        final File[] dest = {defDir};
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(a, 20);
        box.setPadding(p, UI.dp(a, 8), p, 0);
        final EditText name = new EditText(a);
        name.setSingleLine(true);
        name.setText("Archive_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()));
        name.setTextColor(UI.TEXT);
        name.setSelectAllOnFocus(true);
        final TextView destT = UI.text(a, "Save to: " + defDir.getPath(), 12, UI.MUTED);
        destT.setPadding(0, UI.dp(a, 12), 0, 0);
        TextView change = UI.button(a, "Choose folder");
        change.setOnClickListener(v -> DirPicker.show(a, dest[0], f -> {
            dest[0] = f;
            destT.setText("Save to: " + f.getPath());
        }));
        box.addView(UI.text(a, items.size() + " item(s) will be added. Folders are included with their contents.", 12, UI.SOFT));
        box.addView(name);
        box.addView(destT);
        box.addView(change);
        new AlertDialog.Builder(a).setTitle("Create ZIP").setView(box)
                .setPositiveButton("Create", (x, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.toLowerCase(Locale.ROOT).endsWith(".zip")) n = n.substring(0, n.length() - 4);
                    n = n.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (n.isEmpty() || n.equals(".") || n.equals("..")) n = "Archive";
                    if (!dest[0].isDirectory() || !dest[0].canWrite()) {
                        UI.alert(a, "Can't save here", "TANO FILEX cannot write to " + dest[0].getPath()
                                + ".\nOn Android 8-10, SD cards are read-only for apps. Choose a folder on internal storage.");
                        return;
                    }
                    doCreate(a, items, dest[0], n, after);
                })
                .setNegativeButton("Cancel", null).show();
    }

    private static void doCreate(final Activity a, final List<File> items, File destDir, String base, final Runnable after) {
        final File out = FileUtils.unique(destDir, base + ".zip");
        Tasks.run(a, "Creating ZIP", ctl -> {
            int skipped = ZipUtil.create(items, out, ctl);
            if (ctl.cancel.get()) return "Cancelled. No ZIP was created.";
            return "Created " + out.getName() + " (" + FileUtils.size(out.length()) + ")"
                    + (skipped > 0 ? "\n" + skipped + " file(s) could not be read and were skipped." : "");
        }, (res, err) -> {
            if (err != null) {
                UI.alert(a, "ZIP failed", Tasks.msg(err)
                        + "\n\nNo partial ZIP was kept. Very large archives (over 4 GB or 65,535 files) may exceed what Android's ZIP writer supports.");
                return;
            }
            if (!out.exists()) { UI.toast(a, res); return; }
            ActivityLog.add(a, "ZIP", "Created " + out.getName(), out.getPath());
            if (after != null) after.run();
            new AlertDialog.Builder(a).setTitle("ZIP ready").setMessage(res + "\n\n" + out.getPath())
                    .setPositiveButton("Share", (x, w) -> FileOpen.share(a, Collections.singletonList(out)))
                    .setNegativeButton("Close", null).show();
        });
    }

    // ------------------------------------------------------------------ open / extract

    static void zipMenu(final Activity a, final File zip, final Runnable after) {
        String[] opts = {"Browse contents", "Extract here (new folder)", "Extract to…", "Share ZIP", "Open with another app"};
        new AlertDialog.Builder(a).setTitle(zip.getName()).setItems(opts, (d, i) -> {
            switch (i) {
                case 0: browse(a, zip, after); break;
                case 1: extractHere(a, zip, after); break;
                case 2: DirPicker.show(a, zip.getParentFile(), dir -> extract(a, zip, dir, after)); break;
                case 3: FileOpen.share(a, Collections.singletonList(zip)); break;
                default: FileOpen.external(a, zip);
            }
        }).show();
    }

    static void extractHere(Activity a, File zip, Runnable after) {
        String base = zip.getName();
        if (base.toLowerCase(Locale.ROOT).endsWith(".zip")) base = base.substring(0, base.length() - 4);
        extract(a, zip, FileUtils.unique(zip.getParentFile(), base), after);
    }

    /** Step 1: dry-run check (zip-slip, entry limit, free space, name conflicts). Nothing is written yet. */
    static void extract(final Activity a, final File zip, final File dest, final Runnable after) {
        final ZipUtil.Plan[] plan = new ZipUtil.Plan[1];
        Tasks.run(a, "Checking archive", ctl -> {
            plan[0] = ZipUtil.inspect(zip, dest, ctl);
            return ctl.cancel.get() ? "cancelled" : "ok";
        }, (res, err) -> {
            if (err != null) { UI.alert(a, "Cannot extract", Tasks.msg(err)); return; }
            if ("cancelled".equals(res) || plan[0] == null) return;
            final ZipUtil.Plan p = plan[0];
            long free = ZipUtil.freeSpace(dest);
            if (!p.sizeUnknown && p.bytes + ZipUtil.margin() > free) {
                UI.alert(a, "Not enough free space", "Extracting needs about " + FileUtils.size(p.bytes)
                        + " but only " + FileUtils.size(free) + " is free at the destination.");
                return;
            }
            if (p.conflicts == 0) { doExtract(a, zip, dest, ZipUtil.KEEP_BOTH, p, after); return; }
            StringBuilder ex = new StringBuilder();
            for (String s : p.sample) { if (ex.length() > 0) ex.append(", "); ex.append(s); }
            String[] opts = {"Overwrite existing files", "Keep both (rename new files)", "Skip existing files", "Cancel"};
            new AlertDialog.Builder(a).setTitle(p.conflicts + " file(s) already exist (e.g. " + ex + ")")
                    .setItems(opts, (d, i) -> {
                        if (i == 0) doExtract(a, zip, dest, ZipUtil.OVERWRITE, p, after);
                        else if (i == 1) doExtract(a, zip, dest, ZipUtil.KEEP_BOTH, p, after);
                        else if (i == 2) doExtract(a, zip, dest, ZipUtil.SKIP, p, after);
                    }).show();
        });
    }

    /** Step 2: the real extraction. */
    private static void doExtract(final Activity a, final File zip, final File dest, final int policy,
                                  final ZipUtil.Plan plan, final Runnable after) {
        final int[][] counts = new int[1][];
        Tasks.run(a, "Extracting", ctl -> {
            counts[0] = ZipUtil.extract(zip, dest, policy, ctl);
            int[] c = counts[0];
            StringBuilder sb = new StringBuilder();
            sb.append(ctl.cancel.get() ? "Cancelled after " : "Extracted ").append(c[0]).append(" file(s) to\n").append(dest.getPath());
            if (c[1] > 0) sb.append("\n").append(c[1]).append(" existing item(s) were skipped.");
            if (c[2] > 0) sb.append("\n").append(c[2]).append(" unsafe entr").append(c[2] == 1 ? "y" : "ies").append(" (paths leaving the folder) were blocked.");
            return sb.toString();
        }, (res, err) -> {
            if (err != null) {
                UI.alert(a, "Extract failed", Tasks.msg(err) + "\n\nFiles extracted before the error were kept. Partly written files were removed.");
            } else {
                ActivityLog.add(a, "EXTRACT", "Extracted " + zip.getName(), dest.getPath());
                UI.alert(a, "Done", res);
            }
            if (after != null) after.run();
        });
    }

    static void browse(final Activity a, final File zip, final Runnable after) {
        Tasks.run(a, "Reading ZIP", ctl -> {
            StringBuilder sb = new StringBuilder();
            for (String[] e : ZipUtil.list(zip, 1500)) {
                sb.append(e[0]);
                if (!e[1].isEmpty()) sb.append("   ·   ").append(e[1]);
                sb.append('\n');
            }
            return sb.toString();
        }, (res, err) -> {
            if (err != null) { UI.alert(a, "Cannot read ZIP", Tasks.msg(err)); return; }
            TextView t = UI.text(a, res, 12, UI.TEXT);
            t.setTypeface(Typeface.MONOSPACE);
            t.setTextIsSelectable(true);
            int p = UI.dp(a, 20);
            t.setPadding(p, p / 2, p, p / 2);
            ScrollView sv = new ScrollView(a);
            sv.addView(t);
            new AlertDialog.Builder(a).setTitle(zip.getName()).setView(sv)
                    .setPositiveButton("Extract all here", (x, w) -> extractHere(a, zip, after))
                    .setNegativeButton("Close", null).show();
        });
    }
}
