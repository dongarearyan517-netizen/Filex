package com.tano.filex;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

/** One screen for: folder browsing, category lists, large files, duplicates and the ZIP list. */
public class BrowserFragment extends Fragment implements MainActivity.BackHandler {

    static final class Clip {
        final List<String> paths;
        final boolean move;
        Clip(List<String> p, boolean m) { paths = p; move = m; }
    }
    static Clip clip;

    private static final String[] SORTS = {"Name (A–Z)", "Name (Z–A)", "Size (largest first)", "Size (smallest first)", "Date (newest first)", "Date (oldest first)"};
    private static final String[] FILTERS = {"All", "Folders", "Images", "Videos", "Audio", "Documents", "APK files", "Archives", "Other"};
    private static final Category[] FCATS = {null, null, Category.IMAGES, Category.VIDEOS, Category.AUDIO, Category.DOCUMENTS, Category.APK, Category.ARCHIVES, Category.OTHER};

    private String mode = "path";
    private File dir, startDir;
    private Category cat;
    private boolean autoSelect;

    private List<FileItem> all = new ArrayList<>();
    private List<FileItem> shown = new ArrayList<>();
    private final Set<String> selected = new LinkedHashSet<>();
    private boolean selectMode, searchMode;
    private int sort, filterIdx;
    private String query = "";
    private String loadError;
    private volatile int loadToken;
    private AtomicBoolean dupCancel;

    private FileAdapter adapter;
    private TextView pathView, empty, banner, selInfo, pasteInfo, filterBtn;
    private EditText search;
    private ProgressBar progress;
    private View selBar, pasteBar;
    private TextView infoBtn;
    private ExecutorService io;
    private AtomicBoolean searchCancel;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable filterRun = this::applyFilter;

    private final StorageScanner.Listener scanListener = new StorageScanner.Listener() {
        @Override public void onProgress(long files) {
            if (alive() && empty != null && all.isEmpty() && !mode.equals("path") && !mode.equals("dups")) {
                empty.setVisibility(View.VISIBLE);
                empty.setText("Analysing storage… " + files + " files found");
            }
        }
        @Override public void onDone() { if (alive()) load(); }
    };

    static BrowserFragment path(File dir, boolean autoSelect) {
        BrowserFragment f = new BrowserFragment();
        Bundle b = new Bundle();
        b.putString("mode", "path");
        b.putString("path", dir.getPath());
        b.putBoolean("auto", autoSelect);
        f.setArguments(b);
        return f;
    }

    static BrowserFragment cat(Category c) {
        BrowserFragment f = new BrowserFragment();
        Bundle b = new Bundle();
        b.putString("mode", "cat");
        b.putString("cat", c.name());
        f.setArguments(b);
        return f;
    }

    static BrowserFragment mode(String m) {
        BrowserFragment f = new BrowserFragment();
        Bundle b = new Bundle();
        b.putString("mode", m);
        f.setArguments(b);
        return f;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        return inf.inflate(R.layout.fragment_browser, parent, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle state) {
        super.onViewCreated(v, state);
        final Context ctx = requireContext();
        Bundle a = getArguments() == null ? new Bundle() : getArguments();
        mode = a.getString("mode", "path");
        if (mode.equals("path")) {
            dir = new File(a.getString("path", StorageHelper.primary().getPath()));
            startDir = dir;
            autoSelect = a.getBoolean("auto", false);
        } else if (mode.equals("cat")) {
            cat = Category.valueOf(a.getString("cat", "IMAGES"));
        }
        io = Executors.newSingleThreadExecutor();
        sort = Prefs.getInt(ctx, "sort", 0);
        if (mode.equals("large")) sort = 2;
        if (mode.equals("zips")) sort = 4;

        pathView = v.findViewById(R.id.pathView);
        empty = v.findViewById(R.id.empty);
        banner = v.findViewById(R.id.banner);
        search = v.findViewById(R.id.search);
        progress = v.findViewById(R.id.progress);
        selBar = v.findViewById(R.id.selBar);
        selInfo = v.findViewById(R.id.selInfo);
        pasteBar = v.findViewById(R.id.pasteBar);
        pasteInfo = v.findViewById(R.id.pasteInfo);
        RecyclerView list = v.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(ctx));
        list.setHasFixedSize(true);
        adapter = new FileAdapter(selected, new FileAdapter.Listener() {
            @Override public void onClick(FileItem it) { handleClick(it); }
            @Override public void onLong(FileItem it) {
                selectMode = true;
                selected.add(it.path);
                updateSel();
            }
        });
        list.setAdapter(adapter);

        pathView.setOnClickListener(x -> {
            if (mode.equals("path") && dir.getParentFile() != null && dir.getParentFile().canRead()) enter(dir.getParentFile());
        });

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                query = s.toString().trim();
                if (query.isEmpty() && searchCancel != null) searchCancel.set(true);
                if (searchMode && query.isEmpty()) { searchMode = false; loadDir(); return; }
                main.removeCallbacks(filterRun);
                main.postDelayed(filterRun, 200);
            }
        });
        search.setOnEditorActionListener((tv, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
                if (mode.equals("path") && !query.isEmpty()) deepSearch();
                return true;
            }
            return false;
        });

        buildToolRow(v);
        buildSelectionActions(v);

        v.findViewById(R.id.pasteGo).setOnClickListener(x -> paste());
        v.findViewById(R.id.pasteCancel).setOnClickListener(x -> { clip = null; updatePaste(); });

        switch (mode) {
            case "large":
                banner("Files of " + Prefs.getInt(ctx, "largeMb", 100) + " MB or more across all readable storage (change the size in Settings).");
                break;
            case "dups":
                banner("Files are listed only when their size AND full SHA-256 content hash match. Names are ignored. Check before deleting.");
                break;
            case "zips":
                banner("Tap a ZIP to browse, extract or share it. To create a ZIP, tap “Create ZIP”, select items and press ZIP.");
                break;
            default:
                if (autoSelect) banner("Select the files or folders to compress, then tap ZIP below.");
        }
        if (autoSelect) selectMode = true;
        updateSel();
        updatePaste();
        load();
    }

    private boolean alive() { return isAdded() && getView() != null; }

    private void banner(String s) {
        banner.setText(s);
        banner.setVisibility(View.VISIBLE);
    }

    @Override public void onStart() {
        super.onStart();
        if (!mode.equals("path") && !mode.equals("dups")) StorageScanner.get().addListener(scanListener);
    }

    @Override public void onStop() {
        super.onStop();
        StorageScanner.get().removeListener(scanListener);
    }

    @Override public void onDestroyView() {
        super.onDestroyView();
        loadToken++;
        main.removeCallbacksAndMessages(null);
        if (dupCancel != null) dupCancel.set(true);
        if (searchCancel != null) searchCancel.set(true);
        if (io != null) io.shutdownNow();
    }

    // ---------------------------------------------------------------- toolbar

    private void buildToolRow(View v) {
        final Context ctx = requireContext();
        LinearLayout row = v.findViewById(R.id.toolRow);
        addTool(row, "Sort", this::pickSort);
        filterBtn = addTool(row, "Filter", this::pickFilter);
        if (mode.equals("path")) {
            addTool(row, "New folder", this::newFolder);
            if (StorageHelper.volumes(ctx).size() > 1) addTool(row, "Storage", this::pickVolume);
        }
        addTool(row, "Select all", () -> {
            selectMode = true;
            for (FileItem it : shown) selected.add(it.path);
            updateSel();
        });
        if (mode.equals("zips")) {
            addTool(row, "Create ZIP", () -> ((MainActivity) requireActivity()).openPath(StorageHelper.primary(), true));
        }
        if (mode.equals("cat") || mode.equals("large") || mode.equals("zips")) {
            addTool(row, "Rescan", () -> {
                StorageScanner.get().rescan(requireContext());
                all = new ArrayList<>();
                load();
            });
        }
        if (mode.equals("dups")) {
            addTool(row, "Rescan", () -> { DuplicateFinder.clear(); loadDups(); });
        }
    }

    private TextView addTool(LinearLayout row, String label, Runnable r) {
        TextView t = UI.button(requireContext(), label);
        t.setOnClickListener(x -> r.run());
        row.addView(t);
        return t;
    }

    private void buildSelectionActions(View v) {
        LinearLayout row = v.findViewById(R.id.selActions);
        addTool(row, "Copy", () -> setClip(false));
        addTool(row, "Move", () -> setClip(true));
        addTool(row, "ZIP", this::zipSelected);
        addTool(row, "Rename", this::rename);
        addTool(row, "Delete", this::delete);
        addTool(row, "Share", this::shareSelected);
        infoBtn = addTool(row, "Info", this::info);
        addTool(row, "Private", this::toPrivate);
        addTool(row, "Done", this::clearSelection);
    }

    private void pickSort() {
        new AlertDialog.Builder(requireContext()).setTitle("Sort by")
                .setSingleChoiceItems(SORTS, sort, (d, i) -> {
                    sort = i;
                    Prefs.putInt(requireContext(), "sort", i);
                    d.dismiss();
                    applyFilter();
                }).show();
    }

    private void pickFilter() {
        new AlertDialog.Builder(requireContext()).setTitle("Show only")
                .setSingleChoiceItems(FILTERS, filterIdx, (d, i) -> {
                    filterIdx = i;
                    d.dismiss();
                    applyFilter();
                }).show();
    }

    private void pickVolume() {
        final List<StorageHelper.Volume> vols = StorageHelper.volumes(requireContext());
        String[] names = new String[vols.size()];
        for (int i = 0; i < names.length; i++) names[i] = vols.get(i).label + "\n" + vols.get(i).root.getPath();
        new AlertDialog.Builder(requireContext()).setTitle("Storage").setItems(names, (d, i) -> {
            startDir = vols.get(i).root;
            enter(vols.get(i).root);
        }).show();
    }

    // ---------------------------------------------------------------- loading

    private void setLoading(boolean b) { if (progress != null) progress.setVisibility(b ? View.VISIBLE : View.GONE); }

    private void load() {
        if (!alive()) return;
        if (mode.equals("path")) { loadDir(); return; }
        if (mode.equals("dups")) { loadDups(); return; }
        StorageScanner sc = StorageScanner.get();
        StorageScanner.Result r = sc.result();
        if (r == null) {
            if (!sc.isRunning()) sc.start(requireContext());
            setLoading(true);
            all = new ArrayList<>();
            shown = new ArrayList<>();
            adapter.set(shown, true);
            empty.setVisibility(View.VISIBLE);
            empty.setText("Analysing storage…");
            return;
        }
        setLoading(false);
        if (mode.equals("cat")) {
            all = r.items.get(cat);
        } else if (mode.equals("large")) {
            all = r.large;
        } else {
            List<FileItem> z = new ArrayList<>();
            for (FileItem i : r.items.get(Category.ARCHIVES)) if (FileUtils.ext(i.name()).equals("zip")) z.add(i);
            all = z;
        }
        applyFilter();
    }

    private void loadDir() {
        final int token = ++loadToken;
        loadError = null;
        setLoading(true);
        final File d = dir;
        final boolean hidden = Prefs.getBool(requireContext(), "hidden", false);
        io.execute(() -> {
            File[] fs = d.listFiles();
            final List<FileItem> out = new ArrayList<>();
            String err = null;
            if (fs == null) {
                err = "This folder can't be opened (no access, or it is not a folder).";
            } else {
                for (File f : fs) {
                    if (!hidden && f.getName().startsWith(".")) continue;
                    out.add(new FileItem(f));
                }
            }
            final String fe = err;
            main.post(() -> {
                if (token != loadToken || !alive()) return;
                loadError = fe;
                all = out;
                setLoading(false);
                applyFilter();
            });
        });
    }

    private void loadDups() {
        List<FileItem> last = DuplicateFinder.last();
        if (last != null) {
            all = last;
            setLoading(false);
            applyFilter();
            return;
        }
        setLoading(true);
        all = new ArrayList<>();
        shown = new ArrayList<>();
        adapter.set(shown, true);
        empty.setVisibility(View.VISIBLE);
        empty.setText("Scanning for duplicates…");
        if (dupCancel != null) dupCancel.set(true);
        dupCancel = new AtomicBoolean();
        DuplicateFinder.run(requireContext(), dupCancel, new DuplicateFinder.Callback() {
            @Override public void progress(String status) { if (alive()) empty.setText(status); }
            @Override public void done(List<FileItem> items, int groups, long wasted) {
                if (!alive()) return;
                all = items;
                setLoading(false);
                applyFilter();
            }
            @Override public void error(String message) {
                if (!alive()) return;
                setLoading(false);
                empty.setVisibility(View.VISIBLE);
                empty.setText(message);
            }
        });
    }

    private void deepSearch() {
        final int token = ++loadToken;
        if (searchCancel != null) searchCancel.set(true);
        final AtomicBoolean cancel = new AtomicBoolean();
        searchCancel = cancel;
        setLoading(true);
        final Predicate<String> pm = FileUtils.matcher(query);
        final File root = dir;
        final boolean hidden = Prefs.getBool(requireContext(), "hidden", false);
        io.execute(() -> {
            final List<FileItem> out = new ArrayList<>();
            FileUtils.searchTree(root, pm, out, 5000, hidden, cancel);
            main.post(() -> {
                if (token != loadToken || !alive() || cancel.get()) return;
                searchMode = true;
                all = out;
                setLoading(false);
                applyFilter();
            });
        });
    }

    private Comparator<FileItem> comparator() {
        Comparator<FileItem> c;
        switch (sort) {
            case 1: c = (a, b) -> b.name().compareToIgnoreCase(a.name()); break;
            case 2: c = (a, b) -> Long.compare(b.size, a.size); break;
            case 3: c = (a, b) -> Long.compare(a.size, b.size); break;
            case 4: c = (a, b) -> Long.compare(b.mod, a.mod); break;
            case 5: c = (a, b) -> Long.compare(a.mod, b.mod); break;
            default: c = (a, b) -> a.name().compareToIgnoreCase(b.name());
        }
        if (mode.equals("path")) {
            final Comparator<FileItem> base = c;
            c = (a, b) -> a.dir != b.dir ? (a.dir ? -1 : 1) : base.compare(a, b);
        }
        return c;
    }

    private void applyFilter() {
        if (!alive() || adapter == null) return;
        List<FileItem> out = new ArrayList<>();
        Predicate<String> pm = query.isEmpty() ? null : FileUtils.matcher(query);
        for (FileItem it : all) {
            if (pm != null && !pm.test(it.name())) continue;
            if (filterIdx == 1 && !it.dir) continue;
            if (filterIdx >= 2 && (it.dir || it.cat != FCATS[filterIdx])) continue;
            out.add(it);
        }
        if (!mode.equals("dups")) Collections.sort(out, comparator());
        shown = out;
        adapter.set(shown, !mode.equals("path") || searchMode);
        filterBtn.setText(filterIdx == 0 ? "Filter" : "Filter: " + FILTERS[filterIdx]);

        long total = 0;
        for (FileItem it : out) total += it.size;
        String head;
        if (searchMode) head = "Search results in " + dir.getPath() + " · " + out.size();
        else if (mode.equals("path")) head = dir.getPath() + "  ·  " + out.size() + " items";
        else if (mode.equals("dups")) head = DuplicateFinder.lastGroups() + " groups · " + FileUtils.size(DuplicateFinder.lastWasted()) + " could be freed · " + out.size() + " files";
        else head = (cat != null ? cat.label : mode.equals("large") ? "Large files" : "ZIP archives") + "  ·  " + out.size() + " files  ·  " + FileUtils.size(total);
        if (!mode.equals("path") && !mode.equals("dups") && StorageScanner.get().isDirty()) head += "  ·  changed: tap Rescan";
        if (!mode.equals("path") && !mode.equals("dups") && StorageScanner.get().result() != null && StorageScanner.get().result().truncated) head += "  ·  list limited";
        pathView.setText(head);

        if (out.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            if (loadError != null) empty.setText(loadError);
            else if (!query.isEmpty() || filterIdx != 0) empty.setText("No matching items.");
            else if (mode.equals("dups")) empty.setText("No identical files were found.");
            else empty.setText("Nothing here.");
        } else {
            empty.setVisibility(View.GONE);
        }
    }

    // ---------------------------------------------------------------- navigation / selection

    private void enter(File d) {
        if (!d.canRead()) { UI.toast(requireContext(), "No access to this folder."); return; }
        dir = d;
        searchMode = false;
        clearSelectionSilently();
        search.setText("");
        query = "";
        loadDir();
    }

    private void handleClick(FileItem it) {
        if (selectMode) { toggle(it); return; }
        if (it.dir) { enter(it.file()); return; }
        File f = it.file();
        if (!f.exists()) { UI.toast(requireContext(), "File no longer exists."); return; }
        if (FileUtils.ext(it.name()).equals("zip")) ZipActions.zipMenu(requireActivity(), f, this::afterOp);
        else FileOpen.open(requireActivity(), f, true);
    }

    private void toggle(FileItem it) {
        if (!selected.add(it.path)) selected.remove(it.path);
        if (selected.isEmpty()) { selectMode = false; autoSelect = false; }
        updateSel();
    }

    private void clearSelectionSilently() { selected.clear(); selectMode = false; autoSelect = false; }

    private void clearSelection() { clearSelectionSilently(); updateSel(); }

    private void updateSel() {
        if (adapter == null) return;
        adapter.selectMode = selectMode;
        adapter.notifyDataSetChanged();
        selBar.setVisibility(selectMode ? View.VISIBLE : View.GONE);
        selInfo.setText(selected.size() + " selected");
        infoBtn.setVisibility(selected.size() == 1 ? View.VISIBLE : View.GONE);
    }

    private void updatePaste() {
        if (pasteBar == null) return;
        boolean show = clip != null && mode.equals("path");
        pasteBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (clip != null) pasteInfo.setText((clip.move ? "Move " : "Copy ") + clip.paths.size() + " item(s) here?");
    }

    @Override public boolean onBack() {
        if (selectMode) { clearSelection(); return true; }
        if (searchMode) { search.setText(""); return true; }
        if (mode.equals("path") && dir != null && !dir.equals(startDir)) {
            File p = dir.getParentFile();
            if (p != null && p.canRead()) { enter(p); return true; }
        }
        return false;
    }

    private List<FileItem> selectedItems() {
        List<FileItem> out = new ArrayList<>();
        for (FileItem it : all) if (selected.contains(it.path)) out.add(it);
        return out;
    }

    private List<File> selectedFiles() {
        List<File> out = new ArrayList<>();
        for (FileItem it : selectedItems()) out.add(it.file());
        return out;
    }

    private void afterOp() {
        StorageScanner.get().markDirty();
        if (!alive()) return;
        clearSelectionSilently();
        if (mode.equals("path")) {
            if (searchMode) { searchMode = false; search.setText(""); query = ""; }
            loadDir();
        } else {
            List<FileItem> keep = new ArrayList<>();
            for (FileItem i : all) if (new File(i.path).exists()) keep.add(i);
            all.clear();
            all.addAll(keep);
            applyFilter();
        }
        updateSel();
        updatePaste();
    }

    // ---------------------------------------------------------------- operations

    private void newFolder() {
        UI.input(requireContext(), "New folder", "Folder name", "", n -> {
            if (!FileUtils.validName(n)) { UI.toast(requireContext(), "That is not a valid folder name."); return; }
            File f = new File(dir, n);
            if (f.exists()) { UI.toast(requireContext(), "That name already exists."); return; }
            if (f.mkdirs()) {
                ActivityLog.add(requireContext(), "FOLDER", "Created folder " + n, f.getPath());
                loadDir();
            } else UI.toast(requireContext(), "Could not create the folder here (read-only location?).");
        });
    }

    private void setClip(boolean move) {
        List<FileItem> sel = selectedItems();
        if (sel.isEmpty()) return;
        List<String> paths = new ArrayList<>();
        for (FileItem it : sel) paths.add(it.path);
        clip = new Clip(paths, move);
        clearSelection();
        updatePaste();
        if (!mode.equals("path")) {
            UI.toast(requireContext(), "Now open All Files and the destination folder, then tap Paste here.");
        } else {
            UI.toast(requireContext(), "Open the destination folder and tap Paste here.");
        }
    }

    private void paste() {
        final Clip c = clip;
        if (c == null || !mode.equals("path")) return;
        final File dest = dir;
        final Context ctx = requireContext();
        if (!dest.canWrite()) {
            UI.alert(ctx, "Can't write here", "TANO FILEX cannot write to this folder. On Android 8-10, SD cards are read-only for apps. Choose a folder on internal storage.");
            return;
        }
        Tasks.run(requireActivity(), c.move ? "Moving" : "Copying", ctl -> {
            int ok = 0, fail = 0;
            String lastErr = null;
            for (String p : c.paths) {
                if (ctl.cancel.get()) break;
                File s = new File(p);
                ctl.status(s.getName());
                try {
                    if (!s.exists()) { fail++; continue; }
                    if (s.isDirectory() && FileUtils.isInside(s, dest)) { fail++; continue; }
                    if (c.move && dest.equals(s.getParentFile())) continue;
                    if (c.move) FileUtils.move(s, dest, ctl.cancel, ctl);
                    else FileUtils.copyTo(s, dest, ctl.cancel, ctl);
                    if (ctl.cancel.get()) break;
                    ok++;
                } catch (Exception e) {
                    fail++;
                    lastErr = Tasks.msg(e);
                }
            }
            return (c.move ? "Moved " : "Copied ") + ok + " item(s)" + (fail > 0 ? ", " + fail + " failed" : "")
                    + (ctl.cancel.get() ? " (cancelled)" : "") + (lastErr != null ? "\nLast error: " + lastErr : "");
        }, (res, err) -> {
            if (!alive()) return;
            if (err != null) UI.alert(ctx, "Operation failed", Tasks.msg(err));
            else {
                UI.toast(ctx, res);
                if (res.contains("failed"))
                    UI.alert(ctx, "Some items failed", "A folder can't be pasted into itself, and Android 8-10 does not allow apps to write to SD cards. Check that the destination is writable.");
                ActivityLog.add(ctx, c.move ? "MOVE" : "COPY", res, dest.getPath());
            }
            clip = null;
            afterOp();
        });
    }

    private void delete() {
        final List<FileItem> sel = selectedItems();
        if (sel.isEmpty()) return;
        final Context ctx = requireContext();
        String warn = "The selected files and folders will be permanently deleted. This cannot be undone.";
        if (mode.equals("dups")) {
            Map<Integer, Integer> chosen = new HashMap<>();
            Map<Integer, Integer> total = new HashMap<>();
            for (FileItem it : sel) {
                Integer old = chosen.get(it.group);
                chosen.put(it.group, old == null ? 1 : old + 1);
                total.put(it.group, it.groupCount);
            }
            int wipe = 0;
            for (Map.Entry<Integer, Integer> e : chosen.entrySet()) if (e.getValue() >= total.get(e.getKey())) wipe++;
            if (wipe > 0) warn += "\n\nWARNING: for " + wipe + " group(s) EVERY identical copy is selected. Deleting would remove all copies of those files. Keep at least one copy per group.";
        }
        UI.confirm(ctx, "Delete " + sel.size() + " item(s)?", warn, "Delete", () ->
                Tasks.run(requireActivity(), "Deleting", ctl -> {
                    int ok = 0, fail = 0;
                    for (FileItem it : sel) {
                        if (ctl.cancel.get()) break;
                        ctl.status(it.name());
                        if (FileUtils.deleteRecursive(it.file())) ok++; else fail++;
                    }
                    return "Deleted " + ok + " item(s)" + (fail > 0 ? ", " + fail + " could not be deleted" : "");
                }, (res, err) -> {
                    if (!alive()) return;
                    UI.toast(ctx, err != null ? Tasks.msg(err) : res);
                    ActivityLog.add(ctx, "DELETE", res, mode.equals("path") ? dir.getPath() : null);
                    afterOp();
                }));
    }

    private void rename() {
        final List<FileItem> sel = selectedItems();
        if (sel.isEmpty()) return;
        final Context ctx = requireContext();
        if (sel.size() == 1) {
            final File f = sel.get(0).file();
            UI.input(ctx, "Rename", "New name", f.getName(), n -> {
                try {
                    File t = FileUtils.rename(f, n);
                    ActivityLog.add(ctx, "RENAME", "Renamed " + f.getName() + " → " + t.getName(), t.getPath());
                    afterOp();
                } catch (java.io.IOException e) {
                    UI.toast(ctx, Tasks.msg(e));
                }
            });
        } else {
            batchRename(sel);
        }
    }

    private void batchRename(final List<FileItem> sel) {
        final Context ctx = requireContext();
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(ctx, 20);
        box.setPadding(p, UI.dp(ctx, 8), p, 0);
        final EditText base = new EditText(ctx);
        base.setHint("Base name, e.g. Holiday");
        base.setTextColor(UI.TEXT);
        base.setHintTextColor(UI.MUTED);
        base.setSingleLine(true);
        final EditText start = new EditText(ctx);
        start.setHint("Start number");
        start.setText("1");
        start.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        start.setTextColor(UI.TEXT);
        start.setHintTextColor(UI.MUTED);
        box.addView(UI.text(ctx, sel.size() + " items will become  Base_01.ext, Base_02.ext …  Extensions are kept.", 12, UI.SOFT));
        box.addView(base);
        box.addView(start);
        new AlertDialog.Builder(ctx).setTitle("Batch rename").setView(box)
                .setPositiveButton("Rename", (x, w) -> {
                    String b = base.getText().toString().trim();
                    if (!FileUtils.validName(b)) { UI.toast(ctx, "Enter a valid base name."); return; }
                    int s;
                    try { s = Integer.parseInt(start.getText().toString().trim()); } catch (Exception e) { s = 1; }
                    doBatchRename(sel, b, s);
                }).setNegativeButton("Cancel", null).show();
    }

    private void doBatchRename(List<FileItem> sel, String base, int start) {
        Context ctx = requireContext();
        int width = Math.max(2, String.valueOf(start + sel.size() - 1).length());
        Set<String> selPaths = new LinkedHashSet<>();
        for (FileItem it : sel) selPaths.add(it.path);
        List<File[]> plan = new ArrayList<>();
        for (int i = 0; i < sel.size(); i++) {
            File f = sel.get(i).file();
            String n = f.getName();
            int dot = n.lastIndexOf('.');
            String ext = (!f.isDirectory() && dot > 0) ? n.substring(dot) : "";
            File t = new File(f.getParentFile(), base + "_" + String.format(Locale.US, "%0" + width + "d", start + i) + ext);
            if (t.exists() && !selPaths.contains(t.getPath())) {
                UI.alert(ctx, "Name conflict", t.getName() + " already exists. Choose another base name or start number.");
                return;
            }
            plan.add(new File[]{f, t});
        }
        List<File> temps = new ArrayList<>();
        int ok = 0;
        for (int i = 0; i < plan.size(); i++) {
            File tmp = new File(plan.get(i)[0].getParentFile(), ".tano_tmp_" + i);
            if (plan.get(i)[0].renameTo(tmp)) temps.add(tmp); else temps.add(null);
        }
        for (int i = 0; i < plan.size(); i++) {
            File tmp = temps.get(i);
            if (tmp == null) continue;
            if (tmp.renameTo(plan.get(i)[1])) ok++; else tmp.renameTo(plan.get(i)[0]);
        }
        UI.toast(ctx, "Renamed " + ok + " of " + plan.size() + " item(s)");
        ActivityLog.add(ctx, "RENAME", "Batch renamed " + ok + " item(s) to " + base + "_…", sel.get(0).file().getParent());
        afterOp();
    }

    private void zipSelected() {
        List<File> files = selectedFiles();
        if (files.isEmpty()) return;
        File def = mode.equals("path") ? dir : StorageHelper.primary();
        ZipActions.create(requireActivity(), files, def, this::afterOp);
    }

    private void shareSelected() {
        List<File> files = selectedFiles();
        if (!files.isEmpty()) FileOpen.share(requireActivity(), files);
    }

    private void toPrivate() {
        final Context ctx = requireContext();
        if (!PrivateVault.hasPin(ctx)) {
            UI.alert(ctx, "Private Space not set up", "Open Private Space from the menu and create a PIN first.");
            return;
        }
        final List<File> files = new ArrayList<>();
        int folders = 0;
        for (File f : selectedFiles()) { if (f.isFile()) files.add(f); else folders++; }
        if (files.isEmpty()) {
            UI.alert(ctx, "Files only", "Folders can't be moved into Private Space. Create a ZIP of the folder first.");
            return;
        }
        final String note = folders > 0 ? "\n(" + folders + " folder(s) will be skipped.)" : "";
        UI.confirm(ctx, "Move to Private Space?", files.size() + " file(s) will be moved into Private Space and disappear from normal browsing." + note
                + "\n\nPrivate Space is PIN-protected but not encrypted.", "Move", () ->
                Tasks.run(requireActivity(), "Moving to Private Space", ctl -> {
                    int ok = 0, fail = 0;
                    for (File f : files) {
                        if (ctl.cancel.get()) break;
                        try { FileUtils.move(f, PrivateVault.dir(ctx), ctl.cancel, ctl); ok++; } catch (Exception e) { fail++; }
                    }
                    return "Moved " + ok + " file(s) to Private Space" + (fail > 0 ? ", " + fail + " failed" : "");
                }, (res, err) -> {
                    if (!alive()) return;
                    UI.toast(ctx, err != null ? Tasks.msg(err) : res);
                    ActivityLog.add(ctx, "PRIVATE", res, null);
                    afterOp();
                }));
    }

    // ---------------------------------------------------------------- info / checksum

    private void info() {
        List<FileItem> sel = selectedItems();
        if (sel.size() != 1) return;
        final File f = sel.get(0).file();
        if (f.isDirectory()) {
            Tasks.run(requireActivity(), "Calculating folder size", ctl -> {
                long[] acc = new long[3];
                FileUtils.tree(f, acc, ctl.cancel);
                return acc[0] + "," + acc[1] + "," + Math.max(0, acc[2] - 1);
            }, (res, err) -> { if (alive()) showInfo(f, err == null ? res : null); });
        } else {
            showInfo(f, null);
        }
    }

    private static String dur(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private void showInfo(final File f, String tree) {
        final Context ctx = requireContext();
        StringBuilder sb = new StringBuilder();
        String ext = FileUtils.ext(f.getName());
        sb.append("Path\n").append(f.getPath()).append("\n\n");
        if (f.isDirectory()) {
            sb.append("Type: Folder\n");
            if (tree != null) {
                String[] t = tree.split(",");
                sb.append("Size: ").append(FileUtils.size(Long.parseLong(t[0]))).append("\n");
                sb.append("Contains: ").append(t[1]).append(" files, ").append(t[2]).append(" folders\n");
            }
        } else {
            sb.append("Size: ").append(FileUtils.size(f.length())).append(" (").append(f.length()).append(" bytes)\n");
            sb.append("Extension: ").append(ext.isEmpty() ? "none" : "." + ext).append("\n");
            sb.append("Type: ").append(FileUtils.mime(f)).append("\n");
            sb.append("Category: ").append(Category.of(f.getName()).label).append("\n");
        }
        sb.append("Modified: ").append(FileUtils.date(f.lastModified())).append("\n");
        sb.append("Readable: ").append(f.canRead() ? "yes" : "no").append("   Writable: ").append(f.canWrite() ? "yes" : "no").append("\n");
        if (f.isFile()) {
            Category c = Category.of(f.getName());
            try {
                if (c == Category.IMAGES) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getPath(), o);
                    if (o.outWidth > 0) sb.append("Dimensions: ").append(o.outWidth).append(" × ").append(o.outHeight).append("\n");
                } else if (c == Category.AUDIO || c == Category.VIDEOS) {
                    MediaMetadataRetriever mr = new MediaMetadataRetriever();
                    try {
                        mr.setDataSource(f.getPath());
                        String d = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                        if (d != null) sb.append("Duration: ").append(dur(Long.parseLong(d))).append("\n");
                        String br = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE);
                        if (br != null) sb.append("Bitrate: ").append(Long.parseLong(br) / 1000).append(" kbps\n");
                        String w = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                        String h = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                        if (w != null && h != null) sb.append("Resolution: ").append(w).append(" × ").append(h).append("\n");
                        String ti = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        if (ti != null) sb.append("Title: ").append(ti).append("\n");
                        String ar = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        if (ar != null) sb.append("Artist: ").append(ar).append("\n");
                    } finally {
                        mr.release();
                    }
                }
            } catch (Exception ignored) { }
        }
        AlertDialog.Builder b = new AlertDialog.Builder(ctx).setTitle(f.getName()).setMessage(sb.toString())
                .setNegativeButton("Close", null);
        if (f.isFile()) {
            b.setPositiveButton("SHA-256", (x, w) -> checksum(f, "SHA-256"));
            b.setNeutralButton("MD5", (x, w) -> checksum(f, "MD5"));
        }
        b.show();
    }

    private void checksum(final File f, final String algo) {
        final Context ctx = requireContext();
        Tasks.run(requireActivity(), "Calculating " + algo, ctl -> {
            String h = FileUtils.hash(f, algo, ctl.cancel);
            return h == null ? "Cancelled" : h;
        }, (res, err) -> {
            if (!alive()) return;
            if (err != null) { UI.alert(ctx, "Checksum failed", Tasks.msg(err)); return; }
            new AlertDialog.Builder(ctx).setTitle(algo).setMessage(f.getName() + "\n\n" + res)
                    .setPositiveButton("Copy", (x, w) -> {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(algo, res));
                        UI.toast(ctx, "Copied");
                    }).setNegativeButton("Close", null).show();
        });
    }
}
