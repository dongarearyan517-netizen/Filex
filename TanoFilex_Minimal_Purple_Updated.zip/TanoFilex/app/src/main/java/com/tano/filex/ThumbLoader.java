package com.tano.filex;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ThumbLoader {
    private ThumbLoader() {}

    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 1024 / 12)) {
                @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount() / 1024; }
            };
    private static final ExecutorService EX = Executors.newFixedThreadPool(2);

    static void load(final ImageView iv, final String path, final int px) {
        iv.setTag(path);
        Bitmap hit = CACHE.get(path);
        if (hit != null) { iv.setImageBitmap(hit); return; }
        iv.setImageDrawable(null);
        EX.execute(() -> {
            if (!path.equals(iv.getTag())) return; // view was recycled for another file
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(path, o);
                int s = 1;
                while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                o.inPreferredConfig = Bitmap.Config.RGB_565;
                final Bitmap bm = BitmapFactory.decodeFile(path, o);
                if (bm == null) return;
                CACHE.put(path, bm);
                iv.post(() -> { if (path.equals(iv.getTag())) iv.setImageBitmap(bm); });
            } catch (Throwable ignored) { }
        });
    }
}
