package com.tano.filex;

import android.content.Context;
import android.content.pm.PackageInfo;

final class BuildInfo {
    private BuildInfo() {}
    static String versionName(Context c) {
        try {
            PackageInfo p = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return p.versionName;
        } catch (Exception e) {
            return "unknown";
        }
    }
}
