package com.tano.filex;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Fast recursive walk: one attribute read per entry (instead of three stat calls).
 * Skips hidden folders/files, symlinks, special files and other apps' Android/data + Android/obb.
 */
final class FileWalker {
    private FileWalker() {}

    interface Visitor { void onFile(String path, long size, long modifiedMillis); }

    static void walk(File root, final Visitor v, final AtomicBoolean cancel) {
        try {
            Path start = root.toPath();
            if (Files.isSymbolicLink(start)) start = start.toRealPath();
            final Path rootPath = start;
            final String skipA = rootPath + "/Android/data";
            final String skipB = rootPath + "/Android/obb";
            Files.walkFileTree(rootPath, new SimpleFileVisitor<Path>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) {
                    if (cancel.get()) return FileVisitResult.TERMINATE;
                    if (dir.equals(rootPath)) return FileVisitResult.CONTINUE;
                    Path fn = dir.getFileName();
                    String n = fn == null ? "" : fn.toString();
                    String p = dir.toString();
                    if (n.startsWith(".") || p.equals(skipA) || p.equals(skipB)) return FileVisitResult.SKIP_SUBTREE;
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) {
                    if (cancel.get()) return FileVisitResult.TERMINATE;
                    if (!a.isRegularFile()) return FileVisitResult.CONTINUE;
                    Path fn = f.getFileName();
                    if (fn == null || fn.toString().startsWith(".")) return FileVisitResult.CONTINUE;
                    v.onFile(f.toString(), a.size(), a.lastModifiedTime().toMillis());
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFileFailed(Path f, IOException e) {
                    return cancel.get() ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException | RuntimeException e) {
            // unreadable root or unexpected error: keep whatever was collected so far
        }
    }
}
