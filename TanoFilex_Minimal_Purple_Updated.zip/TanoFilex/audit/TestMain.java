package com.tano.filex;

import android.content.Context;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.*;

public class TestMain {
    static int pass = 0, fail = 0;
    static void check(boolean ok, String what) {
        if (ok) pass++; else { fail++; System.out.println("FAIL: " + what); }
    }
    static void write(File f, byte[] b) throws IOException { f.getParentFile().mkdirs(); Files.write(f.toPath(), b); }
    static byte[] rnd(int n, long seed) { byte[] b = new byte[n]; new Random(seed).nextBytes(b); return b; }

    public static void main(String[] a) throws Exception {
        File root = Files.createTempDirectory("tano").toFile();
        System.setProperty("tano.root", root.getPath());
        File work = new File(root, "work"); work.mkdirs();
        Context ctx = new Context() {};

        // ---------- FileUtils basics
        check(FileUtils.ext("A.TXT").equals("txt"), "ext");
        check(FileUtils.ext(".bashrc").equals(""), "ext hidden");
        check(FileUtils.size(1536).equals("1.5 KB"), "size fmt " + FileUtils.size(1536));
        check(!FileUtils.validName("..") && !FileUtils.validName("a/b") && !FileUtils.validName("") && FileUtils.validName("ok.txt"), "validName");
        check(FileUtils.matcher("*.pdf").test("Report.PDF") && !FileUtils.matcher("*.pdf").test("a.txt") && FileUtils.matcher("rep").test("My Report"), "matcher");
        write(new File(work, "abc.txt"), "abc".getBytes());
        check(FileUtils.hash(new File(work, "abc.txt"), "SHA-256", null).equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"), "sha256");
        check(FileUtils.hash(new File(work, "abc.txt"), "MD5", null).equals("900150983cd24fb0d6963f7d28e17f72"), "md5");

        // ---------- copy / move / verify
        File src = new File(work, "src"); write(new File(src, "a/one.bin"), rnd(300000, 1)); write(new File(src, "two.txt"), "hello".getBytes()); new File(src, "emptydir").mkdirs();
        File dst = new File(work, "dst"); dst.mkdirs();
        Tasks.Ctl ctl = new Tasks.Ctl();
        FileUtils.copyTo(src, dst, ctl.cancel, ctl);
        check(new File(dst, "src/a/one.bin").length() == 300000 && new File(dst, "src/emptydir").isDirectory(), "copy dir");
        FileUtils.copyTo(src, dst, ctl.cancel, ctl);
        check(new File(dst, "src (1)").isDirectory(), "copy conflict gets unique name");
        check(FileUtils.isInside(src, new File(src, "a")) && !FileUtils.isInside(src, dst), "isInside");
        FileUtils.move(new File(dst, "src (1)"), work, ctl.cancel, ctl);
        check(new File(work, "src (1)/two.txt").exists() && !new File(dst, "src (1)").exists(), "move same fs");
        // forced cross-filesystem move (/dev/shm) to exercise copy+verify+delete
        File shm = new File("/dev/shm/tano_test"); shm.mkdirs();
        File mv = new File(work, "tomove"); write(new File(mv, "x/y.bin"), rnd(200000, 2));
        long before = new File(mv, "x/y.bin").length();
        FileUtils.move(mv, shm, ctl.cancel, ctl);
        check(!mv.exists() && new File(shm, "tomove/x/y.bin").length() == before, "move cross-fs (copy+verify+delete)");
        FileUtils.deleteRecursive(shm);
        // cancelled copy leaves nothing
        Tasks.Ctl cc = new Tasks.Ctl(); cc.cancel.set(true);
        File dst2 = new File(work, "dst2"); dst2.mkdirs();
        FileUtils.copyTo(src, dst2, cc.cancel, cc);
        check(dst2.list().length == 0, "cancelled copy leaves nothing");

        // ---------- rename
        write(new File(work, "r/a.txt"), "1".getBytes()); write(new File(work, "r/b.txt"), "2".getBytes());
        try { FileUtils.rename(new File(work, "r/a.txt"), "b.txt"); check(false, "rename onto existing must fail"); } catch (IOException e) { check(true, ""); }
        check(new File(work, "r/a.txt").exists() && new File(work, "r/b.txt").exists(), "rename conflict kept both");
        File ren = FileUtils.rename(new File(work, "r/a.txt"), "A.txt");
        check(ren.exists() && Arrays.asList(new File(work, "r").list()).contains("A.txt") && !Arrays.asList(new File(work, "r").list()).contains("a.txt"), "case-only rename");
        try { FileUtils.rename(ren, "../evil"); check(false, "rename invalid"); } catch (IOException e) { check(true, ""); }

        // ---------- symlink-safe delete
        File outside = new File(work, "outside"); write(new File(outside, "keep.txt"), "keep".getBytes());
        File victim = new File(work, "victim"); victim.mkdirs();
        Files.createSymbolicLink(new File(victim, "link").toPath(), outside.toPath());
        FileUtils.deleteRecursive(victim);
        check(!victim.exists() && new File(outside, "keep.txt").exists(), "delete does not follow symlinks");

        // ---------- ZIP create / inspect / extract
        File zsrc = new File(work, "zsrc"); write(new File(zsrc, "f1.txt"), "first".getBytes()); write(new File(zsrc, "sub/f2.bin"), rnd(70000, 3)); new File(zsrc, "empty").mkdirs();
        File zip = new File(work, "out.zip");
        int skipped = ZipUtil.create(Arrays.asList(zsrc), zip, new Tasks.Ctl());
        check(zip.exists() && skipped == 0 && !new File(work, "out.zip.tano_part").exists(), "zip created, no part file");
        List<String> names = new ArrayList<>(); try (ZipFile zf = new ZipFile(zip)) { for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) names.add(en.nextElement().getName()); }
        check(names.contains("zsrc/f1.txt") && names.contains("zsrc/sub/f2.bin") && names.contains("zsrc/empty/"), "zip entries " + names);
        File ex1 = new File(work, "ex1");
        ZipUtil.Plan plan = ZipUtil.inspect(zip, ex1, new Tasks.Ctl());
        check(plan.entries == 5 && plan.conflicts == 0 && plan.unsafe == 0, "inspect fresh " + plan.entries);
        int[] r = ZipUtil.extract(zip, ex1, ZipUtil.KEEP_BOTH, new Tasks.Ctl());
        check(r[0] == 2 && new File(ex1, "zsrc/f1.txt").exists() && new File(ex1, "zsrc/empty").isDirectory(), "extract fresh");
        check(Arrays.equals(Files.readAllBytes(new File(ex1, "zsrc/sub/f2.bin").toPath()), Files.readAllBytes(new File(zsrc, "sub/f2.bin").toPath())), "extracted bytes identical");
        write(new File(ex1, "zsrc/f1.txt"), "LOCAL EDIT".getBytes());
        ZipUtil.Plan p2 = ZipUtil.inspect(zip, ex1, new Tasks.Ctl());
        check(p2.conflicts == 2, "conflicts detected " + p2.conflicts);
        ZipUtil.extract(zip, ex1, ZipUtil.SKIP, new Tasks.Ctl());
        check(new String(Files.readAllBytes(new File(ex1, "zsrc/f1.txt").toPath())).equals("LOCAL EDIT"), "SKIP keeps local file");
        ZipUtil.extract(zip, ex1, ZipUtil.KEEP_BOTH, new Tasks.Ctl());
        check(new String(Files.readAllBytes(new File(ex1, "zsrc/f1.txt").toPath())).equals("LOCAL EDIT") && new File(ex1, "zsrc/f1 (1).txt").exists(), "KEEP_BOTH renames new");
        ZipUtil.extract(zip, ex1, ZipUtil.OVERWRITE, new Tasks.Ctl());
        check(new String(Files.readAllBytes(new File(ex1, "zsrc/f1.txt").toPath())).equals("first"), "OVERWRITE replaces");
        boolean leftovers = false; for (String n : walkNames(ex1)) if (n.endsWith(".tano_part")) leftovers = true;
        check(!leftovers, "no .tano_part leftovers");
        // zip-slip
        File evil = new File(work, "evil.zip");
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(evil))) {
            for (String n : new String[]{"../evil.txt", "good/ok.txt", "/abs/abs.txt", "a/../../evil2.txt"}) { z.putNextEntry(new ZipEntry(n)); z.write("x".getBytes()); z.closeEntry(); }
        }
        File ex2 = new File(work, "ex2/inner");
        ZipUtil.Plan p3 = ZipUtil.inspect(evil, ex2, new Tasks.Ctl());
        check(p3.unsafe == 2, "unsafe entries flagged " + p3.unsafe);
        int[] r3 = ZipUtil.extract(evil, ex2, ZipUtil.KEEP_BOTH, new Tasks.Ctl());
        check(r3[2] == 2 && !new File(work, "ex2/evil.txt").exists() && !new File(work, "evil2.txt").exists() && !new File(work, "ex2/evil2.txt").exists(), "zip-slip blocked");
        check(new File(ex2, "good/ok.txt").exists(), "safe entry extracted");
        // cancel
        Tasks.Ctl c3 = new Tasks.Ctl(); c3.cancel.set(true);
        File ex3 = new File(work, "ex3");
        int[] r4 = ZipUtil.extract(zip, ex3, ZipUtil.KEEP_BOTH, c3);
        check(r4[0] == 0, "cancelled extract writes nothing");
        File zc = new File(work, "cancel.zip");
        ZipUtil.create(Arrays.asList(zsrc), zc, c3);
        check(!zc.exists() && !new File(work, "cancel.zip.tano_part").exists(), "cancelled create leaves no file");
        // failure cleanup: output dir missing
        try { ZipUtil.create(Arrays.asList(zsrc), new File(work, "nodir/x.zip"), new Tasks.Ctl()); check(false, "create into missing dir must throw"); } catch (IOException e) { check(true, ""); }
        // corrupt zip
        File bad = new File(work, "bad.zip"); write(bad, "not a zip".getBytes());
        try { ZipUtil.inspect(bad, new File(work, "exb"), new Tasks.Ctl()); check(false, "corrupt zip must throw"); } catch (IOException e) { check(true, ""); }
        check(ZipUtil.freeSpace(new File(work, "does/not/exist")) > 0, "freeSpace of missing dir uses parent");

        // ---------- FileWalker
        File w = new File(root, "walk"); write(new File(w, "a.txt"), "1".getBytes()); write(new File(w, "d/b.jpg"), "22".getBytes());
        write(new File(w, ".hid/c.txt"), "3".getBytes()); write(new File(w, ".dot.txt"), "4".getBytes()); write(new File(w, "Android/data/app/x.bin"), "5".getBytes()); write(new File(w, "Android/obb/y.bin"), "6".getBytes());
        write(new File(w, "Android/media/z.mp3"), "7".getBytes());
        Files.createSymbolicLink(new File(w, "lnk").toPath(), new File(w, "d").toPath());
        Set<String> seen = new TreeSet<>();
        FileWalker.walk(w, (path, size, mod) -> seen.add(path.substring(w.getPath().length())), new AtomicBoolean());
        check(seen.equals(new TreeSet<>(Arrays.asList("/a.txt", "/d/b.jpg", "/Android/media/z.mp3"))), "walker result " + seen);
        check(FileUtils.isInside(w, new File(w, "d")), "sanity");

        // ---------- search
        List<FileItem> found = new ArrayList<>();
        FileUtils.searchTree(w, FileUtils.matcher("*.jpg"), found, 100, false, new AtomicBoolean());
        check(found.size() == 1 && found.get(0).name().equals("b.jpg"), "searchTree " + found.size());

        // ---------- StorageScanner on the fake external storage
        File ext = root;
        write(new File(ext, "pics/p1.jpg"), rnd(2000, 4)); write(new File(ext, "pics/p2.png"), rnd(3000, 5));
        write(new File(ext, "movies/big.mp4"), rnd(2_500_000, 6)); write(new File(ext, "docs/r.pdf"), rnd(1000, 7)); write(new File(ext, "misc/data.xyz"), rnd(500, 8));
        Prefs.putInt(ctx, "largeMb", 1);
        CountDownLatch done = new CountDownLatch(1);
        StorageScanner sc = StorageScanner.get();
        sc.addListener(new StorageScanner.Listener() { public void onProgress(long f) {} public void onDone() { done.countDown(); } });
        sc.start(ctx);
        check(done.await(30, TimeUnit.SECONDS), "scan finished");
        StorageScanner.Result res = sc.result();
        check(res != null && !sc.isRunning(), "scan result set, not running");
        check(res.items.get(Category.IMAGES).size() >= 2, "images found " + res.items.get(Category.IMAGES).size());
        check(res.items.get(Category.VIDEOS).size() == 1 && res.bytes[Category.VIDEOS.ordinal()] == 2_500_000, "video bytes");
        check(res.large.size() == 1 && res.large.get(0).name().equals("big.mp4"), "large list " + res.large.size());
        check(res.items.get(Category.DOCUMENTS).size() >= 1, "docs (pdf/txt) found");
        // cancel + rescan while running
        sc.rescan(ctx); sc.rescan(ctx);
        long t0 = System.currentTimeMillis(); while (sc.isRunning() && System.currentTimeMillis() - t0 < 30000) Thread.sleep(20);
        check(sc.result() != null, "rescan twice still finishes with a result");

        // ---------- DuplicateFinder
        File d = new File(root, "dups"); byte[] same = rnd(20000, 9);
        write(new File(d, "A.bin"), same); write(new File(d, "B_copy.bin"), same); write(new File(d, "sub/C.bin"), same);
        write(new File(d, "diff.bin"), rnd(20000, 10)); // same size, different content: must NOT match
        write(new File(d, "tiny1.txt"), "same".getBytes()); write(new File(d, "tiny2.txt"), "same".getBytes()); // < 10 KB: ignored
        write(new File(d, "renamedtwin.dat"), rnd(30000, 11)); write(new File(d, "x/other_name.zzz"), Files.readAllBytes(new File(d, "renamedtwin.dat").toPath()));
        CountDownLatch dd = new CountDownLatch(1); List<FileItem>[] out = new List[1]; String[] err = new String[1];
        DuplicateFinder.run(ctx, new AtomicBoolean(), new DuplicateFinder.Callback() {
            public void progress(String s) {} public void error(String m) { err[0] = m; dd.countDown(); }
            public void done(List<FileItem> items, int groups, long wasted) { out[0] = items; dd.countDown(); } });
        check(dd.await(60, TimeUnit.SECONDS) && err[0] == null, "dup scan finished " + err[0]);
        Map<Integer, List<String>> groups = new TreeMap<>(); for (FileItem it : out[0]) groups.computeIfAbsent(it.group, k -> new ArrayList<>()).add(it.name());
        boolean g3 = false, g2 = false; for (List<String> g : groups.values()) { if (new HashSet<>(g).equals(new HashSet<>(Arrays.asList("A.bin", "B_copy.bin", "C.bin")))) g3 = true; if (new HashSet<>(g).equals(new HashSet<>(Arrays.asList("renamedtwin.dat", "other_name.zzz")))) g2 = true; }
        check(g3 && g2 && groups.size() >= 2, "dup groups " + groups);
        boolean badDiff = false; for (FileItem it : out[0]) if (it.name().equals("diff.bin") || it.name().startsWith("tiny")) badDiff = true;
        check(!badDiff, "different-content same-size and tiny files not reported as duplicates");
        // cancelled dup scan must never call back
        AtomicBoolean cx = new AtomicBoolean(true); boolean[] called = {false};
        DuplicateFinder.run(ctx, cx, new DuplicateFinder.Callback() { public void progress(String s) {} public void error(String m) { called[0] = true; } public void done(List<FileItem> i, int g, long w2) { called[0] = true; } });
        Thread.sleep(500); check(!called[0], "cancelled dup scan is silent");

        // ---------- PrivateVault PIN
        PrivateVault.setPin(ctx, "4821");
        check(PrivateVault.hasPin(ctx) && PrivateVault.verify(ctx, "4821") && !PrivateVault.verify(ctx, "4822") && !PrivateVault.verify(ctx, ""), "pin verify");
        check(!Prefs.str(ctx, "pin_hash", "").contains("4821"), "pin not stored in clear");
        check(PrivateVault.lockoutMillis(5) == 30000 && PrivateVault.lockoutMillis(10) == 300000 && PrivateVault.lockoutMillis(15) == 1800000, "lockout schedule");
        File vault = PrivateVault.dir(ctx); write(new File(vault, "s.txt"), "secret".getBytes());
        PrivateVault.reset(ctx);
        check(!PrivateVault.hasPin(ctx) && (!vault.exists() || vault.list().length == 0), "reset wipes vault and pin");

        System.out.println("PASSED " + pass + ", FAILED " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }

    static List<String> walkNames(File d) throws IOException {
        List<String> out = new ArrayList<>();
        try (java.util.stream.Stream<Path> s = Files.walk(d.toPath())) { s.forEach(p -> out.add(p.toString())); }
        return out;
    }
}
