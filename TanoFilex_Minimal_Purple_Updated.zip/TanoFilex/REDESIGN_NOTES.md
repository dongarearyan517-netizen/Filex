# TANO FileX — Minimal Midnight Purple UI update

This update refines the actual Android Java UI while retaining the existing file-management/navigation actions.

## Home screen changes
- Reduced dashboard clutter: removed the multi-row storage-category panel and extra status badge.
- Replaced the large multi-card layout with a single storage-focused card and a compact four-action row.
- Kept recent file activity as a simple, divider-separated list.
- Reduced the storage ring to one violet progress arc.
- Uses a near-black / midnight-purple palette with restrained violet accents.

## Files changed
- `app/src/main/java/com/tano/filex/HomeFragment.java`
- `app/src/main/java/com/tano/filex/UI.java`
- `app/src/main/java/com/tano/filex/StorageRingView.java`
- `app/src/main/java/com/tano/filex/MainActivity.java`
- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/themes.xml`
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/drawable/bg_topbar.xml`

The source has not been compiled in an Android SDK in this environment. Build with the existing GitHub Actions workflow and test on-device before relying on it.
