package com.tano.filex;

import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    interface BackHandler { boolean onBack(); }

    static final int REQ_STORAGE = 7;
    static final int NAV_HOME = 0, NAV_FILES = 1, NAV_IMAGES = 2, NAV_VIDEOS = 3, NAV_AUDIO = 4, NAV_DOCS = 5,
            NAV_DOWNLOADS = 6, NAV_APK = 7, NAV_ARCHIVES = 8, NAV_LARGE = 9, NAV_DUPS = 10, NAV_PRIVATE = 11,
            NAV_ZIP = 12, NAV_RECENT = 13, NAV_SETTINGS = 14, NAV_ABOUT = 15;
    private static final String[] NAV = {"Home", "All Files", "Images", "Videos", "Audio", "Documents", "Downloads",
            "APK Files", "Archives", "Large Files", "Duplicate Candidates", "Private Space", "ZIP Manager",
            "Recent Activity", "Settings", "About TANO FILEX"};

    private DrawerLayout drawer;
    private TextView title;
    private TextView[] navViews;
    private int current = NAV_HOME;
    private boolean permissionShown;

    static int navFor(Category c) {
        switch (c) {
            case IMAGES: return NAV_IMAGES;
            case VIDEOS: return NAV_VIDEOS;
            case AUDIO: return NAV_AUDIO;
            case DOCUMENTS: return NAV_DOCS;
            case APK: return NAV_APK;
            case ARCHIVES: return NAV_ARCHIVES;
            default: return NAV_FILES;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawer = findViewById(R.id.drawer);
        title = findViewById(R.id.title);
        drawer.setScrimColor(0xB3000000);

        LinearLayout list = findViewById(R.id.navList);
        navViews = new TextView[NAV.length];
        for (int i = 0; i < NAV.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(NAV[i]);
            t.setTextSize(15.5f);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding(UI.dp(this, 28), 0, UI.dp(this, 16), 0);
            UI.ripple(t);
            t.setOnClickListener(v -> {
                drawer.closeDrawer(GravityCompat.START);
                navigate(idx);
            });
            list.addView(t, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, UI.dp(this, 48)));
            navViews[i] = t;
        }
        findViewById(R.id.menuButton).setOnClickListener(v -> drawer.openDrawer(GravityCompat.START));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) { drawer.closeDrawer(GravityCompat.START); return; }
                Fragment f = getSupportFragmentManager().findFragmentById(R.id.content);
                if (f instanceof BackHandler && ((BackHandler) f).onBack()) return;
                if (current != NAV_HOME) { navigate(NAV_HOME); return; }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
            }
        });

        if (savedInstanceState == null) {
            navigate(NAV_HOME);
        } else {
            current = savedInstanceState.getInt("cur", NAV_HOME);
            updateNav(current);
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("cur", current);
    }

    /** Re-checks storage access every time the app comes to the foreground (it can be revoked in Settings). */
    @Override protected void onResume() {
        super.onResume();
        if (needsStorage(current)) {
            if (Perm.has(this)) {
                if (permissionShown) navigate(current);
            } else if (!permissionShown) {
                showPermission();
            }
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_STORAGE && !Perm.has(this)) {
            UI.toast(this, "Storage permission was denied. TANO FILEX can't browse files without it. Tap Grant access to try again.");
        }
    }

    private boolean needsStorage(int i) {
        return (i >= NAV_HOME && i <= NAV_DUPS) || i == NAV_ZIP;
    }

    private void showPermission() {
        permissionShown = true;
        show(new PermissionFragment());
    }

    public void navigate(int i) {
        if (i < 0 || i >= NAV.length) return;
        if (i == NAV_ABOUT) { showAbout(); return; }
        current = i;
        updateNav(i);
        if (needsStorage(i) && !Perm.has(this)) { showPermission(); return; }
        permissionShown = false;
        show(make(i));
    }

    void openPath(File dir, boolean autoSelect) {
        if (!Perm.has(this)) { navigate(NAV_FILES); return; }
        current = NAV_FILES;
        permissionShown = false;
        show(BrowserFragment.path(dir, autoSelect));
        updateNav(NAV_FILES);
    }

    private Fragment make(int i) {
        switch (i) {
            case NAV_HOME: return new HomeFragment();
            case NAV_FILES: return BrowserFragment.path(StorageHelper.primary(), false);
            case NAV_IMAGES: return BrowserFragment.cat(Category.IMAGES);
            case NAV_VIDEOS: return BrowserFragment.cat(Category.VIDEOS);
            case NAV_AUDIO: return BrowserFragment.cat(Category.AUDIO);
            case NAV_DOCS: return BrowserFragment.cat(Category.DOCUMENTS);
            case NAV_DOWNLOADS: {
                File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!d.exists()) d.mkdirs();
                return BrowserFragment.path(d.isDirectory() ? d : StorageHelper.primary(), false);
            }
            case NAV_APK: return BrowserFragment.cat(Category.APK);
            case NAV_ARCHIVES: return BrowserFragment.cat(Category.ARCHIVES);
            case NAV_LARGE: return BrowserFragment.mode("large");
            case NAV_DUPS: return BrowserFragment.mode("dups");
            case NAV_PRIVATE: return new PrivateFragment();
            case NAV_ZIP: return BrowserFragment.mode("zips");
            case NAV_RECENT: return new RecentFragment();
            default: return new SettingsFragment();
        }
    }

    private void show(Fragment f) {
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.content, f).commitAllowingStateLoss();
    }

    private void updateNav(int sel) {
        title.setText(sel == NAV_HOME ? "TANO FILEX" : NAV[sel]);
        for (int i = 0; i < navViews.length; i++) {
            UI.ripple(navViews[i]);
            navViews[i].setTextColor(i == sel ? UI.VIOLET : UI.TEXT);
            if (i == sel) navViews[i].setBackgroundColor(0x1A7C3AED);
        }
    }

    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("TANO FILEX")
                .setMessage("Advanced file manager by TANO.\nVersion " + BuildInfo.versionName(this)
                        + "\n\nWorks offline. No ads, no tracking, no root needed. Your files never leave your device unless you share them.")
                .setPositiveButton("OK", null).show();
    }
}
