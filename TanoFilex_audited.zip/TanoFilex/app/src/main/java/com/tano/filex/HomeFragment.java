package com.tano.filex;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private StorageRingView ring;
    private TextView usedT, freeT, totalT, scanStatus;
    private LinearLayout catBox, recentBox;

    private final StorageScanner.Listener listener = new StorageScanner.Listener() {
        @Override public void onProgress(long files) {
            if (isAdded() && getView() != null && scanStatus != null) scanStatus.setText("Analysing storage… " + files + " files");
        }
        @Override public void onDone() { refresh(); }
    };

    private TextView statValue(Context c, LinearLayout parent, String label) {
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        TextView v = UI.text(c, "--", 17, UI.TEXT);
        v.setGravity(Gravity.CENTER);
        TextView l = UI.text(c, label, 11, UI.MUTED);
        l.setGravity(Gravity.CENTER);
        l.setLetterSpacing(0.15f);
        col.addView(v);
        col.addView(l);
        parent.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return v;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        final Context c = requireContext();
        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(c, 24);
        col.setPadding(pad, UI.dp(c, 8), pad, UI.dp(c, 32));
        sv.addView(col);

        ring = new StorageRingView(c);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(UI.dp(c, 280), UI.dp(c, 280));
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(ring, rp);

        LinearLayout stats = new LinearLayout(c);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 24));
        usedT = statValue(c, stats, "USED");
        freeT = statValue(c, stats, "AVAILABLE");
        totalT = statValue(c, stats, "TOTAL");
        col.addView(stats);

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView h1 = UI.text(c, "Categories", 15, UI.VIOLET);
        head.addView(h1, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView rescan = UI.button(c, "Rescan");
        rescan.setOnClickListener(x -> {
            StorageScanner.get().rescan(requireContext());
            refresh();
        });
        head.addView(rescan);
        col.addView(head);

        scanStatus = UI.text(c, "", 12, UI.MUTED);
        scanStatus.setPadding(0, 0, 0, UI.dp(c, 6));
        col.addView(scanStatus);
        catBox = new LinearLayout(c);
        catBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(catBox);

        LinearLayout head2 = new LinearLayout(c);
        head2.setGravity(Gravity.CENTER_VERTICAL);
        head2.setPadding(0, UI.dp(c, 24), 0, 0);
        head2.addView(UI.text(c, "Recent activity", 15, UI.VIOLET), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView all = UI.button(c, "View all");
        all.setOnClickListener(x -> ((MainActivity) requireActivity()).navigate(MainActivity.NAV_RECENT));
        head2.addView(all);
        col.addView(head2);
        recentBox = new LinearLayout(c);
        recentBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(recentBox);
        return sv;
    }

    @Override public void onStart() {
        super.onStart();
        StorageScanner.get().addListener(listener);
        StorageScanner sc = StorageScanner.get();
        if (sc.result() == null && !sc.isRunning()) sc.start(requireContext());
        refresh();
    }

    @Override public void onStop() {
        super.onStop();
        StorageScanner.get().removeListener(listener);
    }

    private void refresh() {
        if (!isAdded() || getView() == null) return;
        Context c = requireContext();
        long[] st = StorageHelper.stat(StorageHelper.primary());
        long total = st[0], free = st[1], used = Math.max(0, total - free);
        float usedFrac = total > 0 ? (float) used / total : 0f;
        String pct = total > 0 ? Math.round(usedFrac * 100) + "%" : "--";
        usedT.setText(FileUtils.size(used));
        freeT.setText(FileUtils.size(free));
        totalT.setText(FileUtils.size(total));

        StorageScanner.Result r = StorageScanner.get().result();
        float[] fr = new float[0];
        int[] cols = new int[0];
        if (r != null && total > 0) {
            List<Float> f = new ArrayList<>();
            List<Integer> k = new ArrayList<>();
            float sum = 0;
            for (Category cat : Category.values()) {
                if (cat == Category.OTHER) continue;
                float v = (float) r.bytes[cat.ordinal()] / total;
                if (v > 0) { f.add(v); k.add(cat.color); sum += v; }
            }
            float scale = sum > usedFrac && sum > 0 ? usedFrac / sum : 1f;
            float rest = usedFrac - sum * scale;
            for (int i = 0; i < f.size(); i++) f.set(i, f.get(i) * scale);
            if (rest > 0.001f) { f.add(rest); k.add(Category.OTHER.color); }
            fr = new float[f.size()];
            cols = new int[f.size()];
            for (int i = 0; i < fr.length; i++) { fr[i] = f.get(i); cols[i] = k.get(i); }
        }
        ring.setData(usedFrac, fr, cols, pct, "USED", FileUtils.size(used) + " of " + FileUtils.size(total));

        catBox.removeAllViews();
        if (r == null) {
            scanStatus.setText(StorageScanner.get().isRunning() ? "Analysing storage…" : "");
        } else {
            scanStatus.setText("Sizes shown for internal storage (hidden folders and other apps' data are not counted).");
            Category[] show = {Category.IMAGES, Category.VIDEOS, Category.AUDIO, Category.DOCUMENTS, Category.APK, Category.ARCHIVES};
            for (final Category cat : show) {
                int i = cat.ordinal();
                addRow(c, catBox, cat.color, cat.label, r.counts[i] + " files", FileUtils.size(r.bytes[i]),
                        x -> ((MainActivity) requireActivity()).navigate(MainActivity.navFor(cat)));
            }
        }

        recentBox.removeAllViews();
        List<ActivityLog.Entry> log = ActivityLog.list(c);
        if (log.isEmpty()) {
            TextView t = UI.text(c, "No activity yet. Files you open, copy, move, rename, delete or zip will appear here.", 13, UI.MUTED);
            t.setPadding(0, UI.dp(c, 8), 0, 0);
            recentBox.addView(t);
        }
        for (int i = 0; i < log.size() && i < 3; i++) {
            final ActivityLog.Entry e = log.get(i);
            addRow(c, recentBox, UI.VIOLET, e.text, FileUtils.date(e.time), "", x -> RecentFragment.openEntry((MainActivity) requireActivity(), e));
        }
    }

    private void addRow(Context c, LinearLayout box, int dot, String title, String sub, String right, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UI.dp(c, 11), 0, UI.dp(c, 11));
        UI.ripple(row);
        row.setOnClickListener(click);
        View d = new View(c);
        d.setBackground(UI.round(c, dot, 5));
        row.addView(d, new LinearLayout.LayoutParams(UI.dp(c, 10), UI.dp(c, 10)));
        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(UI.dp(c, 14), 0, UI.dp(c, 8), 0);
        TextView t = UI.text(c, title, 15, UI.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView s = UI.text(c, sub, 12, UI.MUTED);
        mid.addView(t);
        mid.addView(s);
        row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(UI.text(c, right, 14, UI.SOFT));
        box.addView(row);
    }
}
