package com.tano.filex;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class FileAdapter extends RecyclerView.Adapter<FileAdapter.VH> {
    interface Listener {
        void onClick(FileItem it);
        void onLong(FileItem it);
    }

    private List<FileItem> items = new ArrayList<>();
    private final Set<String> selected;
    private final Listener listener;
    boolean selectMode;
    private boolean flat;

    FileAdapter(Set<String> selected, Listener l) {
        this.selected = selected;
        this.listener = l;
    }

    void set(List<FileItem> list, boolean flat) {
        this.items = list;
        this.flat = flat;
        notifyDataSetChanged();
    }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView thumb;
        final TextView badge, name, sub, check;
        VH(View v) {
            super(v);
            thumb = v.findViewById(R.id.thumb);
            badge = v.findViewById(R.id.badge);
            name = v.findViewById(R.id.name);
            sub = v.findViewById(R.id.sub);
            check = v.findViewById(R.id.check);
            thumb.setClipToOutline(true);
        }
    }

    @Override public VH onCreateViewHolder(ViewGroup p, int t) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_file, p, false);
        final VH h = new VH(v);
        v.setOnClickListener(x -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onClick(items.get(pos));
        });
        v.setOnLongClickListener(x -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onLong(items.get(pos));
            return true;
        });
        return h;
    }

    @Override public void onBindViewHolder(VH h, int pos) {
        FileItem it = items.get(pos);
        Context c = h.itemView.getContext();
        h.name.setText(it.name());
        String sub = (it.dir ? "Folder" : FileUtils.size(it.size)) + "  ·  " + FileUtils.date(it.mod);
        if (it.group > 0) sub = "Group " + it.group + " · " + it.groupCount + " identical copies  ·  " + sub;
        if (flat) {
            int i = it.path.lastIndexOf('/');
            int j = i > 0 ? it.path.lastIndexOf('/', i - 1) : -1;
            sub += "  ·  " + (i > 0 ? it.path.substring(j + 1, i) : "");
        }
        h.sub.setText(sub);

        if (it.dir) {
            h.badge.setText("");
            h.thumb.setTag(null);
            h.thumb.setBackground(UI.round(c, 0xFF1A1230, 10));
            h.thumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            h.thumb.setPadding(UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8));
            h.thumb.setImageResource(R.drawable.ic_folder);
        } else if (it.cat == Category.IMAGES) {
            h.badge.setText("");
            h.thumb.setBackground(UI.round(c, 0xFF1A1230, 10));
            h.thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            h.thumb.setPadding(0, 0, 0, 0);
            ThumbLoader.load(h.thumb, it.path, UI.dp(c, 44));
        } else {
            h.thumb.setTag(null);
            h.thumb.setImageDrawable(null);
            h.thumb.setPadding(0, 0, 0, 0);
            Category cat = it.cat == null ? Category.OTHER : it.cat;
            h.thumb.setBackground(UI.round(c, (cat.color & 0x00FFFFFF) | 0x33000000, 10));
            String e = FileUtils.ext(it.name()).toUpperCase(Locale.ROOT);
            if (e.length() > 4) e = e.substring(0, 4);
            h.badge.setText(e.isEmpty() ? "FILE" : e);
            h.badge.setTextColor(cat.color == 0xFF4C1D95 ? 0xFFA78BFA : cat.color);
        }

        boolean sel = selected.contains(it.path);
        h.itemView.setBackground(sel ? UI.round(c, 0x443B2858, 14) : UI.round(c, 0x00151020, 14));
        if (h.itemView.getTag() == null) {
            h.itemView.setTag(Boolean.TRUE);
            UI.animateIn(h.itemView, pos % 7);
        }
        h.check.setVisibility(selectMode ? View.VISIBLE : View.GONE);
        h.check.setText(sel ? "●" : "○");
        h.check.setTextColor(sel ? UI.VIOLET : UI.MUTED);
    }

    @Override public int getItemCount() { return items.size(); }
}
