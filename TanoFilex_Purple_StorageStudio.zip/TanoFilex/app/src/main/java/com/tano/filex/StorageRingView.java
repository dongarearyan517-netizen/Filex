package com.tano.filex;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

/** Circular storage analyser: one arc segment per category with a soft purple glow. */
public class StorageRingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private float used;
    private float[] fr = new float[0];
    private int[] cols = new int[0];
    private String t1 = "--", t2 = "USED", t3 = "";
    private float prog = 1f;
    private float stroke;

    public StorageRingView(Context c) { super(c); init(); }
    public StorageRingView(Context c, AttributeSet a) { super(c, a); init(); }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }

    private void init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        stroke = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 18, getResources().getDisplayMetrics());
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(0xFF291A3C);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);
        big.setColor(0xFFF5F3FF);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTextSize(sp(46));
        big.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        small.setColor(0xFF8B84A8);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(sp(12));
        small.setLetterSpacing(0.2f);
    }

    /** fractions are shares of TOTAL storage; usedFrac is used/total. */
    public void setData(float usedFrac, float[] fractions, int[] colors, String center, String sub, String bottom) {
        used = Math.max(0f, Math.min(1f, usedFrac));
        fr = fractions;
        cols = colors;
        t1 = center;
        t2 = sub;
        t3 = bottom;
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(800);
        va.addUpdateListener(a -> { prog = (float) a.getAnimatedValue(); invalidate(); });
        va.start();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float pad = stroke * 1.6f;
        oval.set(pad, pad, w - pad, h - pad);
        c.drawArc(oval, 0, 360, false, track);
        float start = -90f;
        if (fr.length == 0) {
            arc.setStrokeCap(Paint.Cap.ROUND);
            arc.setColor(0xFFB36BFF);
            arc.setShadowLayer(stroke, 0, 0, 0x99B36BFF);
            float sweep = 360f * used * prog;
            if (sweep > 0.5f) c.drawArc(oval, start, sweep, false, arc);
        } else {
            arc.setStrokeCap(Paint.Cap.BUTT);
            for (int i = 0; i < fr.length; i++) {
                float sweep = 360f * fr[i] * prog;
                arc.setColor(cols[i]);
                arc.setShadowLayer(stroke * 0.9f, 0, 0, (cols[i] & 0x00FFFFFF) | 0x88000000);
                float draw = sweep - 1.5f;
                if (draw > 0.2f) c.drawArc(oval, start, draw, false, arc);
                start += sweep;
            }
        }
        // Fit the percentage inside the ring on narrow screens and with large font settings.
        float baseTextSize = sp(46);
        big.setTextSize(baseTextSize);
        float innerTextWidth = Math.max(sp(24), oval.width() - stroke * 2.4f);
        float measuredTextWidth = big.measureText(t1 == null ? "" : t1);
        if (measuredTextWidth > innerTextWidth && measuredTextWidth > 0f) {
            big.setTextSize(baseTextSize * (innerTextWidth / measuredTextWidth));
        }

        float cy = h / 2f;
        c.drawText(t1, w / 2f, cy + big.getTextSize() * 0.25f, big);
        c.drawText(t2, w / 2f, cy + big.getTextSize() * 0.25f + small.getTextSize() * 1.7f, small);
        c.drawText(t3, w / 2f, cy + big.getTextSize() * 0.25f + small.getTextSize() * 3.4f, small);
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, w);
    }
}
