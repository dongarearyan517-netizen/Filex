package com.tano.filex;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import java.util.function.Consumer;

final class UI {
    private UI() {}
    static final int TEXT = 0xFFF7F3FF, SOFT = 0xFFD2C6E8, MUTED = 0xFF9185A8, VIOLET = 0xFFC18AFF,
            PURPLE = 0xFF8750E8, CYAN = 0xFFC18AFF, SURFACE = 0xFF151020, MIDNIGHT = 0xFF090711, DIVIDER = 0xFF2B203B;

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static void ripple(View v) {
        TypedValue tv = new TypedValue();
        v.getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        v.setBackgroundResource(tv.resourceId);
        v.setClickable(true);
    }

    static TextView button(Context c, String s) {
        TextView t = text(c, s, 13.5f, VIOLET);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        t.setSingleLine(true);
        ripple(t);
        return t;
    }

    static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable panel(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] {0xFF211832, 0xFF171122, 0xFF100C19});
        g.setCornerRadius(dp(c, 22));
        g.setStroke(dp(c, 1), 0xFF3A2A50);
        return g;
    }

    static void animateIn(View v, int index) {
        if (v == null) return;
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 12));
        v.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(index, 8) * 45L)
                .setDuration(360).setInterpolator(new DecelerateInterpolator()).start();
    }

    static void press(View v) {
        if (v == null) return;
        v.animate().cancel();
        v.setScaleX(0.97f); v.setScaleY(0.97f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(180)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    static void toast(Context c, String s) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); }

    static void alert(Context c, String title, String msg) {
        new AlertDialog.Builder(c).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }

    static void confirm(Context c, String title, String msg, String yes, Runnable r) {
        new AlertDialog.Builder(c).setTitle(title).setMessage(msg)
                .setPositiveButton(yes, (d, w) -> r.run()).setNegativeButton("Cancel", null).show();
    }

    static void input(Context c, String title, String hint, String init, Consumer<String> ok) {
        input(c, title, hint, init, android.text.InputType.TYPE_CLASS_TEXT, ok);
    }

    static void input(Context c, String title, String hint, String init, int inputType, Consumer<String> ok) {
        final EditText e = new EditText(c);
        e.setInputType(inputType);
        e.setText(init);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        FrameLayout f = new FrameLayout(c);
        int p = dp(c, 20);
        f.setPadding(p, dp(c, 8), p, 0);
        f.addView(e);
        AlertDialog d = new AlertDialog.Builder(c).setTitle(title).setView(f)
                .setPositiveButton("OK", (x, w) -> ok.accept(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null).create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
        e.requestFocus();
    }
}
