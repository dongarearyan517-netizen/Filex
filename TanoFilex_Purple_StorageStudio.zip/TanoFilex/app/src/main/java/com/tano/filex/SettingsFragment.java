package com.tano.filex;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {
    private static final int[] MB = {10, 50, 100, 250, 500, 1024};
    private static final String[] MB_LABELS = {"10 MB", "50 MB", "100 MB", "250 MB", "500 MB", "1 GB"};
    private static final String[] SORTS = {"Name (A–Z)", "Name (Z–A)", "Size (largest first)", "Size (smallest first)", "Date (newest first)", "Date (oldest first)"};
    private TextView permValue, largeValue, sortValue;

    private LinearLayout row(Context c, LinearLayout col, String title, String sub) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(UI.dp(c, 14), UI.dp(c, 13), UI.dp(c, 14), UI.dp(c, 13));
        r.setBackground(UI.panel(c));
        UI.ripple(r);
        r.addView(UI.text(c, title, 16, UI.TEXT));
        TextView s = UI.text(c, sub, 12.5f, UI.MUTED);
        r.addView(s);
        col.addView(r);
        return r;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        final Context c = requireContext();
        ScrollView sv = new ScrollView(c);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(c, 24);
        col.setPadding(pad, UI.dp(c, 16), pad, UI.dp(c, 32));
        sv.addView(col);

        LinearLayout perm = row(c, col, "Storage access", "");
        permValue = (TextView) perm.getChildAt(1);
        perm.setOnClickListener(x -> {
            if (Perm.has(requireContext())) UI.toast(requireContext(), "Storage access is already granted.");
            else Perm.request(requireActivity(), MainActivity.REQ_STORAGE);
        });

        LinearLayout hidden = new LinearLayout(c);
        hidden.setGravity(android.view.Gravity.CENTER_VERTICAL);
        hidden.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8));
        LinearLayout hl = new LinearLayout(c);
        hl.setOrientation(LinearLayout.VERTICAL);
        hl.addView(UI.text(c, "Show hidden files", 16, UI.TEXT));
        hl.addView(UI.text(c, "Files and folders starting with a dot", 12.5f, UI.MUTED));
        hidden.addView(hl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        SwitchCompat sw = new SwitchCompat(c);
        sw.setChecked(Prefs.getBool(c, "hidden", false));
        sw.setOnCheckedChangeListener((b, on) -> Prefs.putBool(requireContext(), "hidden", on));
        hidden.addView(sw);
        col.addView(hidden);

        LinearLayout large = row(c, col, "Large file size", "");
        largeValue = (TextView) large.getChildAt(1);
        large.setOnClickListener(x -> {
            int cur = Prefs.getInt(requireContext(), "largeMb", 100);
            int sel = 2;
            for (int i = 0; i < MB.length; i++) if (MB[i] == cur) sel = i;
            new AlertDialog.Builder(requireContext()).setTitle("Large files are at least")
                    .setSingleChoiceItems(MB_LABELS, sel, (d, i) -> {
                        Prefs.putInt(requireContext(), "largeMb", MB[i]);
                        StorageScanner.get().invalidate();
                        d.dismiss();
                        refresh();
                    }).show();
        });

        LinearLayout sort = row(c, col, "Default sort order", "");
        sortValue = (TextView) sort.getChildAt(1);
        sort.setOnClickListener(x -> new AlertDialog.Builder(requireContext()).setTitle("Default sort")
                .setSingleChoiceItems(SORTS, Prefs.getInt(requireContext(), "sort", 0), (d, i) -> {
                    Prefs.putInt(requireContext(), "sort", i);
                    d.dismiss();
                    refresh();
                }).show());

        LinearLayout clear = row(c, col, "Clear recent activity", "Removes the history list only");
        clear.setOnClickListener(x -> UI.confirm(requireContext(), "Clear recent activity?", "No files are touched.", "Clear", () -> {
            ActivityLog.clear(requireContext());
            UI.toast(requireContext(), "History cleared");
        }));

        TextView ver = UI.text(c, "TANO FILEX " + BuildInfo.versionName(c) + "  ·  by TANO", 12, UI.MUTED);
        ver.setPadding(0, UI.dp(c, 24), 0, 0);
        col.addView(ver);
        for (int i = 0; i < col.getChildCount(); i++) UI.animateIn(col.getChildAt(i), i);
        return sv;
    }

    @Override public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        Context c = requireContext();
        permValue.setText(Perm.has(c) ? "Granted" : "Not granted. Tap to grant");
        int mb = Prefs.getInt(c, "largeMb", 100);
        largeValue.setText(mb >= 1024 ? "1 GB" : mb + " MB");
        sortValue.setText(SORTS[Math.max(0, Math.min(SORTS.length - 1, Prefs.getInt(c, "sort", 0)))]);
    }
}
