package com.tano.filex;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.PopupWindow;
import android.graphics.drawable.ColorDrawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.List;

/** Reimagined purple dashboard: compact storage hero, clear browse entry points and quiet activity feed. */
public class HomeFragment extends Fragment {
    private StorageRingView ring;
    private TextView freeT, totalT, scanStatus;
    private LinearLayout recentBox, breakdownBox;
    private TextView bubbleMenu;

    private final StorageScanner.Listener listener = new StorageScanner.Listener() {
        @Override public void onProgress(long files) {
            if (isAdded() && scanStatus != null) scanStatus.setText("Refreshing · " + files + " files checked");
        }
        @Override public void onDone() { refresh(); }
    };

    private LinearLayout col(Context c) {
        LinearLayout v = new LinearLayout(c); v.setOrientation(LinearLayout.VERTICAL); return v;
    }
    private LinearLayout row(Context c) {
        LinearLayout v = new LinearLayout(c); v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private TextView txt(Context c, String s, float size, int color) {
        TextView t = UI.text(c, s, size, color); t.setFontFeatureSettings("kern"); return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout page = col(c);
        int side = UI.dp(c, 20);
        page.setPadding(side, UI.dp(c, 18), side, UI.dp(c, 30));
        scroll.addView(page);

        // Editorial-style heading: spacious, restrained and clearly different from the old stacked dashboard.
        LinearLayout top = row(c);
        TextView eyebrow = txt(c, "TANO  /  FILEX", 10, UI.VIOLET);
        eyebrow.setLetterSpacing(.20f);
        eyebrow.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        top.addView(eyebrow, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView local = txt(c, "●  ON DEVICE", 9, UI.MUTED);
        local.setLetterSpacing(.12f); top.addView(local);
        page.addView(top);

        TextView heading = txt(c, "Your space,\nbeautifully sorted.", 26, UI.TEXT);
        heading.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        heading.setLineSpacing(UI.dp(c, 1), 1f);
        LinearLayout.LayoutParams headingLp = lp(-1, -2);
        headingLp.topMargin = UI.dp(c, 15); page.addView(heading, headingLp);
        TextView sub = txt(c, "Everything you keep. One place to find it.", 12, UI.MUTED);
        LinearLayout.LayoutParams subLp = lp(-1, -2); subLp.topMargin = UI.dp(c, 5); subLp.bottomMargin = UI.dp(c, 20);
        page.addView(sub, subLp);

        // Large, centered storage visual with a quiet information rail beneath it.
        LinearLayout hero = col(c);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(UI.dp(c, 14), UI.dp(c, 18), UI.dp(c, 14), UI.dp(c, 16));
        hero.setBackground(UI.panel(c));
        ring = new StorageRingView(c);
        LinearLayout.LayoutParams ringLp = lp(UI.dp(c, 218), UI.dp(c, 218));
        ringLp.gravity = Gravity.CENTER_HORIZONTAL;
        hero.addView(ring, ringLp);

        LinearLayout storageStats = row(c);
        storageStats.setGravity(Gravity.CENTER);
        LinearLayout usedCol = col(c); usedCol.setGravity(Gravity.CENTER);
        TextView usedLabel = txt(c, "USED", 9, UI.MUTED); usedLabel.setLetterSpacing(.16f); usedCol.addView(usedLabel);
        totalT = txt(c, "--", 15, UI.TEXT); totalT.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams totalLp = lp(-2, -2); totalLp.topMargin = UI.dp(c, 4); usedCol.addView(totalT, totalLp);
        LinearLayout freeCol = col(c); freeCol.setGravity(Gravity.CENTER);
        TextView freeLabel = txt(c, "AVAILABLE", 9, UI.MUTED); freeLabel.setLetterSpacing(.16f); freeCol.addView(freeLabel);
        freeT = txt(c, "--", 15, UI.SOFT); LinearLayout.LayoutParams freeLp = lp(-2, -2); freeLp.topMargin = UI.dp(c, 4); freeCol.addView(freeT, freeLp);
        storageStats.addView(usedCol, new LinearLayout.LayoutParams(0, -2, 1f));
        View divider = new View(c); divider.setBackgroundColor(UI.DIVIDER); storageStats.addView(divider, lp(UI.dp(c, 1), UI.dp(c, 34)));
        storageStats.addView(freeCol, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams statsLp = lp(-1, -2); statsLp.topMargin = UI.dp(c, 12); hero.addView(storageStats, statsLp);
        page.addView(hero);

        // Category breakdown uses the same category colors as file browsing.
        TextView breakdownTitle = txt(c, "STORAGE BREAKDOWN", 10, UI.MUTED);
        breakdownTitle.setLetterSpacing(.16f);
        LinearLayout.LayoutParams breakdownTitleLp = lp(-1, -2); breakdownTitleLp.topMargin = UI.dp(c, 19); breakdownTitleLp.bottomMargin = UI.dp(c, 8);
        page.addView(breakdownTitle, breakdownTitleLp);
        breakdownBox = col(c); page.addView(breakdownBox);

        // A floating bubble opens secondary destinations without filling the dashboard with tiles.
        LinearLayout bubbleRow = row(c); bubbleRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams bubbleRowLp = lp(-1, -2); bubbleRowLp.topMargin = UI.dp(c, 12); page.addView(bubbleRow, bubbleRowLp);
        bubbleMenu = txt(c, "•••", 17, UI.VIOLET); bubbleMenu.setGravity(Gravity.CENTER);
        GradientDrawable bubbleBg = new GradientDrawable(); bubbleBg.setShape(GradientDrawable.OVAL); bubbleBg.setColor(0xFF241735); bubbleBg.setStroke(UI.dp(c, 1), 0xFF65418B);
        bubbleMenu.setBackground(bubbleBg); bubbleMenu.setElevation(UI.dp(c, 5));
        bubbleRow.addView(bubbleMenu, lp(UI.dp(c, 48), UI.dp(c, 48)));
        bubbleMenu.setOnClickListener(v -> showBubbleMenu(bubbleMenu));

        // Single clear primary action; secondary functions live in the floating bubble.
        LinearLayout browse = row(c);
        browse.setPadding(UI.dp(c, 16), UI.dp(c, 15), UI.dp(c, 14), UI.dp(c, 15));
        GradientDrawable browseBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF382252, 0xFF21162F});
        browseBg.setCornerRadius(UI.dp(c, 18)); browseBg.setStroke(UI.dp(c, 1), 0xFF60417F);
        browse.setBackground(browseBg); browse.setClickable(true); browse.setFocusable(true);
        LinearLayout.LayoutParams browseLp = lp(-1, -2); browseLp.topMargin = UI.dp(c, 16); page.addView(browse, browseLp);
        LinearLayout browseText = col(c);
        TextView browseTitle = txt(c, "Browse all files", 14, UI.TEXT);
        browseTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); browseText.addView(browseTitle);
        TextView browseSub = txt(c, "Your folders, in one place", 10, UI.SOFT);
        LinearLayout.LayoutParams browseSubLp = lp(-1, -2); browseSubLp.topMargin = UI.dp(c, 3); browseText.addView(browseSub, browseSubLp);
        browse.addView(browseText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView arrow = txt(c, "↗", 23, UI.VIOLET); browse.addView(arrow);
        browse.setOnClickListener(v -> { UI.press(browse); ((MainActivity) requireActivity()).navigate(MainActivity.NAV_FILES); });

        LinearLayout recentHead = row(c);
        LinearLayout.LayoutParams recentHeadLp = lp(-1, -2); recentHeadLp.topMargin = UI.dp(c, 25); recentHeadLp.bottomMargin = UI.dp(c, 6);
        page.addView(recentHead, recentHeadLp);
        TextView recentTitle = txt(c, "RECENTLY TOUCHED", 10, UI.MUTED);
        recentTitle.setLetterSpacing(.16f); recentTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        recentHead.addView(recentTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView seeAll = UI.button(c, "View all  →");
        seeAll.setOnClickListener(v -> ((MainActivity) requireActivity()).navigate(MainActivity.NAV_RECENT));
        recentHead.addView(seeAll);
        recentBox = col(c); page.addView(recentBox);
        scanStatus = txt(c, "Storage details stay on this device.", 9, UI.MUTED);
        LinearLayout.LayoutParams statusLp = lp(-1, -2); statusLp.topMargin = UI.dp(c, 8); page.addView(scanStatus, statusLp);

        for (int i = 0; i < page.getChildCount(); i++) UI.animateIn(page.getChildAt(i), i);
        return scroll;
    }

    private View dot(Context c, int color) {
        GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color);
        View v = new View(c); v.setBackground(d); return v;
    }

    private View shortcut(Context c, String glyph, String name, int dest) {
        LinearLayout item = col(c); item.setGravity(Gravity.CENTER); item.setPadding(UI.dp(c, 4), UI.dp(c, 10), UI.dp(c, 4), UI.dp(c, 9));
        TextView icon = txt(c, glyph, 20, UI.VIOLET); icon.setGravity(Gravity.CENTER);
        icon.setBackground(UI.round(c, 0x302C1C42, 15)); item.addView(icon, lp(UI.dp(c, 48), UI.dp(c, 45)));
        TextView label = txt(c, name, 10, UI.SOFT); label.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelLp = lp(-1, -2); labelLp.topMargin = UI.dp(c, 6); item.addView(label, labelLp);
        item.setClickable(true); item.setFocusable(true);
        item.setOnClickListener(v -> { UI.press(item); ((MainActivity) requireActivity()).navigate(dest); });
        return item;
    }

    @Override public void onStart() {
        super.onStart(); StorageScanner.get().addListener(listener);
        StorageScanner sc = StorageScanner.get(); if (sc.result() == null && !sc.isRunning()) sc.start(requireContext());
        refresh();
    }
    @Override public void onStop() { super.onStop(); StorageScanner.get().removeListener(listener); }

    private void refresh() {
        if (!isAdded() || getView() == null || ring == null) return;
        Context c = requireContext(); long[] st = StorageHelper.stat(StorageHelper.primary());
        long total = st[0], free = st[1], used = Math.max(0, total - free);
        float frac = total > 0 ? (float) used / total : 0f;
        String pct = total > 0 ? Math.round(frac * 100) + "%" : "--";
        totalT.setText(FileUtils.size(used)); freeT.setText(FileUtils.size(free));
        StorageScanner.Result result = StorageScanner.get().result();
        float[] shares = new float[Category.values().length + 1]; int[] colors = new int[Category.values().length + 1];
        long classified = 0;
        for (Category category : Category.values()) {
            long bytes = result == null ? 0 : result.bytes[category.ordinal()];
            classified += bytes;
            shares[category.ordinal()] = total > 0 ? (float) bytes / (float) total : 0f;
            colors[category.ordinal()] = category.color;
        }
        long appAndSystem = Math.max(0L, used - classified);
        shares[Category.values().length] = total > 0 ? (float) appAndSystem / (float) total : 0f;
        colors[Category.values().length] = 0xFF665477;
        ring.setData(frac, shares, colors, pct, "USED", "STORAGE");
        breakdownBox.removeAllViews();
        if (result == null) {
            TextView waiting = txt(c, "Scanning files to calculate category sizes…", 11, UI.MUTED);
            waiting.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8)); breakdownBox.addView(waiting);
        } else {
            for (Category category : Category.values()) {
                long bytes = result.bytes[category.ordinal()];
                if (bytes <= 0) continue;
                addBreakdownRow(c, category.label, category.color, bytes, result.counts[category.ordinal()], category);
            }
            if (appAndSystem > 0) addBreakdownRow(c, "Apps & system", 0xFF665477, appAndSystem, -1, null);
        }
        recentBox.removeAllViews(); List<ActivityLog.Entry> log = ActivityLog.list(c);
        if (log.isEmpty()) {
            TextView empty = txt(c, "Your recent file activity will appear here.", 11, UI.MUTED);
            empty.setPadding(UI.dp(c, 1), UI.dp(c, 12), 0, UI.dp(c, 12)); recentBox.addView(empty);
        }
        for (int i = 0; i < log.size() && i < 3; i++) addRecent(c, log.get(i), i == Math.min(log.size(), 3) - 1);
        if (result == null) scanStatus.setText(StorageScanner.get().isRunning() ? "Refreshing storage information…" : "Storage details stay on this device.");
        else scanStatus.setText("Updated on this device · Protected app folders may be excluded.");
    }

    private void addBreakdownRow(Context c, String label, int tint, long bytes, int count, Category category) {
        LinearLayout row = row(c); row.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8));
        View color = dot(c, tint); row.addView(color, lp(UI.dp(c, 9), UI.dp(c, 9)));
        TextView name = txt(c, label, 11, UI.SOFT);
        LinearLayout.LayoutParams nameLp = lp(0, -2); nameLp.leftMargin = UI.dp(c, 9); row.addView(name, nameLp);
        TextView size = txt(c, FileUtils.size(bytes) + (count >= 0 ? "  ·  " + count + " files" : ""), 10, UI.MUTED);
        size.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(size, new LinearLayout.LayoutParams(0, -2, 1f));
        if (category != null) {
            row.setClickable(true); row.setOnClickListener(v -> ((MainActivity) requireActivity()).navigate(MainActivity.navFor(category)));
        }
        breakdownBox.addView(row);
        View rule = new View(c); rule.setBackgroundColor(UI.DIVIDER); breakdownBox.addView(rule, lp(-1, UI.dp(c, 1)));
    }

    private void showBubbleMenu(View anchor) {
        Context c = requireContext();
        LinearLayout menu = col(c); menu.setPadding(UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF1A1228); bg.setCornerRadius(UI.dp(c, 20)); bg.setStroke(UI.dp(c, 1), 0xFF69448F); menu.setBackground(bg);
        PopupWindow popup = new PopupWindow(menu, UI.dp(c, 210), -2, true);
        popup.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT)); popup.setOutsideTouchable(true); popup.setElevation(UI.dp(c, 12));
        String[] labels = {"Images", "Videos", "Audio", "Documents", "Downloads", "Archives", "Large files", "Duplicate finder", "Private Space", "ZIP Manager", "Settings"};
        int[] destinations = {MainActivity.NAV_IMAGES, MainActivity.NAV_VIDEOS, MainActivity.NAV_AUDIO, MainActivity.NAV_DOCS, MainActivity.NAV_DOWNLOADS, MainActivity.NAV_ARCHIVES, MainActivity.NAV_LARGE, MainActivity.NAV_DUPS, MainActivity.NAV_PRIVATE, MainActivity.NAV_ZIP, MainActivity.NAV_SETTINGS};
        for (int i = 0; i < labels.length; i++) {
            final int dest = destinations[i];
            TextView item = txt(c, labels[i] + "   ›", 13, UI.SOFT); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(UI.dp(c, 14), 0, UI.dp(c, 12), 0);
            item.setBackground(UI.round(c, 0x001A1228, 12)); item.setClickable(true); item.setFocusable(true);
            menu.addView(item, lp(-1, UI.dp(c, 43)));
            item.setOnClickListener(v -> { popup.dismiss(); ((MainActivity) requireActivity()).navigate(dest); });
        }
        popup.showAsDropDown(anchor, -UI.dp(c, 162), -UI.dp(c, 8), Gravity.END);
    }

    private void addRecent(Context c, ActivityLog.Entry entry, boolean last) {
        LinearLayout item = row(c); item.setPadding(0, UI.dp(c, 10), 0, UI.dp(c, 10));
        TextView icon = txt(c, "•", 22, UI.VIOLET); icon.setGravity(Gravity.CENTER);
        item.addView(icon, lp(UI.dp(c, 25), UI.dp(c, 34)));
        LinearLayout mid = col(c); mid.setPadding(UI.dp(c, 8), 0, UI.dp(c, 8), 0);
        TextView title = txt(c, entry.text, 12, UI.TEXT); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView when = txt(c, FileUtils.date(entry.time), 10, UI.MUTED);
        LinearLayout.LayoutParams whenLp = lp(-1, -2); whenLp.topMargin = UI.dp(c, 3); mid.addView(title); mid.addView(when, whenLp);
        item.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = txt(c, "›", 21, UI.MUTED); item.addView(more);
        item.setOnClickListener(v -> RecentFragment.openEntry((MainActivity) requireActivity(), entry));
        recentBox.addView(item);
        if (!last) { View divider = new View(c); divider.setBackgroundColor(UI.DIVIDER); recentBox.addView(divider, lp(-1, UI.dp(c, 1))); }
        UI.animateIn(item, recentBox.getChildCount());
    }
}
