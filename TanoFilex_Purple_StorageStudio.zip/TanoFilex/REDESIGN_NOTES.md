# TANO FileX — Purple Storage Studio update

This update keeps the midnight-black / cool-purple visual identity and changes the dashboard layout and category entry experience.

## UI changes
- Enlarged the storage ring to 218dp and centered it in a dedicated storage hero.
- Ring segments now use real per-category byte totals from `StorageScanner.Result.bytes`.
- Added a matching category breakdown with size and file-count labels; tapping a category row opens that category.
- Added an Apps & system remainder estimate for used space not classified by the file scan. This is an estimate, not a direct Android system measurement.
- Moved secondary destinations into a compact circular bubble menu, reducing shortcut clutter on the dashboard.
- Category browser screens now use category-specific accent colors, tinted header surfaces, glyphs and search hints.
- Kept file operations and existing navigation destinations intact.

## Important measurement note
The storage ring's overall used percentage comes from Android storage statistics. Category segments come from files the scanner can read. Protected app folders and inaccessible locations may not be classified, so the Apps & system segment represents the difference and should not be interpreted as an exact system-only measurement.

## Verification
Source and archive structure were checked. An Android SDK / Gradle build and physical-device test were not available in this environment; run the GitHub Actions workflow before installing this build.
