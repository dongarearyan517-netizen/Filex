package com.tano.vibe.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import androidx.core.app.NotificationManagerCompat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Watches active media sessions (Spotify, YouTube, YouTube Music, any MediaSession app). */
public final class MediaWatcher {
    public interface Listener { void onMedia(MediaInfo info); }

    private final Context ctx;
    private final Listener listener;
    private final ComponentName comp;
    private final Map<MediaController, MediaController.Callback> cbs = new HashMap<>();
    private MediaSessionManager msm;
    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener = list -> { attach(list); refresh(); };

    public MediaWatcher(Context c, Listener l) {
        ctx = c.getApplicationContext();
        listener = l;
        comp = new ComponentName(ctx, MediaListenerService.class);
    }

    public static boolean hasAccess(Context c) {
        return NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.getPackageName());
    }

    public void start() {
        stop();
        if (!hasAccess(ctx)) { refresh(); return; }
        try {
            msm = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
            msm.addOnActiveSessionsChangedListener(sessionsListener, comp);
            attach(msm.getActiveSessions(comp));
        } catch (SecurityException e) { msm = null; }
        refresh();
    }

    public void stop() {
        if (msm != null) { try { msm.removeOnActiveSessionsChangedListener(sessionsListener); } catch (Exception ignored) {} }
        for (Map.Entry<MediaController, MediaController.Callback> e : cbs.entrySet()) {
            try { e.getKey().unregisterCallback(e.getValue()); } catch (Exception ignored) {}
        }
        cbs.clear();
        msm = null;
    }

    private void attach(List<MediaController> list) {
        for (Map.Entry<MediaController, MediaController.Callback> e : cbs.entrySet()) {
            try { e.getKey().unregisterCallback(e.getValue()); } catch (Exception ignored) {}
        }
        cbs.clear();
        if (list == null) return;
        for (MediaController mc : list) {
            MediaController.Callback cb = new MediaController.Callback() {
                @Override public void onPlaybackStateChanged(PlaybackState s) { refresh(); }
                @Override public void onMetadataChanged(MediaMetadata m) { refresh(); }
            };
            mc.registerCallback(cb);
            cbs.put(mc, cb);
        }
    }

    /** Re-reads sessions and notifies the listener. */
    public void refresh() {
        MediaInfo info = new MediaInfo();
        info.accessGranted = hasAccess(ctx);
        if (info.accessGranted && msm != null) {
            try {
                List<MediaController> list = msm.getActiveSessions(comp);
                MediaController pick = null;
                List<MediaController> candidates = new ArrayList<>();
                for (MediaController mc : list) if (!ctx.getPackageName().equals(mc.getPackageName())) candidates.add(mc);
                for (MediaController mc : candidates) if (isPlaying(mc)) { pick = mc; break; }
                if (pick == null && !candidates.isEmpty()) pick = candidates.get(0);
                if (pick != null) {
                    info.hasSession = true;
                    info.playing = isPlaying(pick);
                    info.packageName = pick.getPackageName();
                    info.sourceName = sourceName(info.packageName);
                    info.uid = uidOf(info.packageName);
                    MediaMetadata md = pick.getMetadata();
                    if (md != null) {
                        CharSequence t = md.getText(MediaMetadata.METADATA_KEY_TITLE);
                        CharSequence a = md.getText(MediaMetadata.METADATA_KEY_ARTIST);
                        if (a == null) a = md.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                        info.title = t == null ? "" : t.toString();
                        info.artist = a == null ? "" : a.toString();
                    }
                }
            } catch (SecurityException ignored) { info.accessGranted = false; }
        }
        listener.onMedia(info);
    }

    private static boolean isPlaying(MediaController mc) {
        PlaybackState s = mc.getPlaybackState();
        return s != null && (s.getState() == PlaybackState.STATE_PLAYING || s.getState() == PlaybackState.STATE_BUFFERING);
    }

    private String sourceName(String pkg) {
        switch (pkg) {
            case "com.spotify.music": return "Spotify";
            case "com.google.android.youtube": return "YouTube";
            case "com.google.android.apps.youtube.music": return "YouTube Music";
            default:
                try {
                    PackageManager pm = ctx.getPackageManager();
                    return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
                } catch (Exception e) {
                    String s = pkg.substring(pkg.lastIndexOf('.') + 1);
                    return s.isEmpty() ? pkg : Character.toUpperCase(s.charAt(0)) + s.substring(1);
                }
        }
    }

    private int uidOf(String pkg) {
        try { ApplicationInfo ai = ctx.getPackageManager().getApplicationInfo(pkg, 0); return ai.uid; }
        catch (Exception e) { return -1; }
    }
}
