package com.tano.vibe.audio;

import java.util.ArrayList;
import java.util.List;

/** Outcome of the decision engine. {@code analysed == false} means a fallback, NOT an analysis. */
public final class VolumeDecision {
    public boolean analysed;
    public double fraction;           // 0..1, before conversion to device steps
    public boolean clampedByMax;
    public final List<String> reasons = new ArrayList<>();
    public AnalysisResult analysis;   // null for fallback
    public String fallbackReason = "";
    // filled when applied to a device:
    public int targetStep, maxStep, recommendedPct;
}
