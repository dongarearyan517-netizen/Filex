package com.tano.vibe.media;

import android.service.notification.NotificationListenerService;

/**
 * Intentionally empty. Android only lets an app read other apps' MediaSessions
 * (MediaSessionManager.getActiveSessions) if it holds an enabled notification listener.
 * TANO VIBE never reads or stores notification content.
 */
public class MediaListenerService extends NotificationListenerService { }
