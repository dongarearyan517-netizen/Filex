package com.tano.vibe.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/** Pixel typography (bundled, OFL-licensed): Pixelify Sans for text, Silkscreen for labels. */
public final class Fonts {
    private static Typeface pixel, label;
    private Fonts() {}

    public static Typeface pixel(Context c) {
        if (pixel == null) pixel = load(c, "fonts/PixelifySans-Medium.ttf");
        return pixel;
    }
    public static Typeface label(Context c) {
        if (label == null) label = load(c, "fonts/Silkscreen-Regular.ttf");
        return label;
    }
    private static Typeface load(Context c, String path) {
        try { return Typeface.createFromAsset(c.getAssets(), path); }
        catch (Exception e) { return Typeface.MONOSPACE; }
    }

    /** Walks the view tree and applies fonts according to android:tag ("pixel" / "label"). */
    public static void apply(View v) {
        if (v instanceof TextView) {
            Object t = v.getTag();
            if ("label".equals(t)) ((TextView) v).setTypeface(label(v.getContext()));
            else if ("pixel".equals(t)) ((TextView) v).setTypeface(pixel(v.getContext()));
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i));
        }
    }
}
