package com.tano.vibe.audio;

/** Every tunable of the volume-decision algorithm lives here. */
public final class DecisionConfig {
    /** Programme loudness that sounds right at {@link #referenceVolume}. -14 LUFS is the common streaming level. */
    public double referenceLufs = -14.0;
    /** Volume fraction (0..1) the user finds right for a track at the reference loudness. */
    public double referenceVolume = 0.50;
    /** Assumed dB span of the whole 0..100 % volume range (Android's curve is roughly logarithmic). */
    public double dbSpan = 36.0;
    /** Largest correction from loudness alone, dB. */
    public double maxOffsetDb = 15.0;
    /** Max boost for wide dynamic range tracks (quiet passages), dB. */
    public double dynamicBoostMaxDb = 3.0;
    /** Max cuts for bass-heavy / bright tracks, dB (only when protection is on). */
    public double bassCutMaxDb = 2.5, trebleCutMaxDb = 2.0;
    /** Small +/- nudge from musical intensity. Intentionally small: energy is NOT loudness. */
    public double intensityMaxDb = 1.0;
    public boolean protection = true;
    public double minVolume = 0.08;
    /** User-configured ceiling, 0..1. */
    public double maxVolume = 0.60;
}
