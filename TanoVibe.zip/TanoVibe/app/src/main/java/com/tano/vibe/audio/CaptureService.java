package com.tano.vibe.audio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.annotation.Nullable;
import com.tano.vibe.R;
import com.tano.vibe.data.Prefs;
import com.tano.vibe.volume.VibeBus;
import com.tano.vibe.volume.VibeRunner;

/**
 * Foreground service (type mediaProjection, required by Android 10+/14) that lives only for
 * the few seconds of one analysis: captures other apps' playback via AudioPlaybackCapture,
 * analyses the PCM, decides the volume, then stops itself.
 *
 * Honest limits: apps may opt out of capture (allowAudioPlaybackCapture=false), DRM / protected
 * streams are excluded, and Android < 10 has no API at all. In those cases the capture is
 * silent or throws and we report that instead of inventing numbers.
 */
public class CaptureService extends Service {
    public static final String EXTRA_CODE = "code", EXTRA_DATA = "data", EXTRA_UID = "uid";
    private static final String CHANNEL = "tano_vibe_capture";
    private static final int SAMPLE_RATE = 44100, SECONDS = 8;
    private volatile boolean cancelled;
    private Thread worker;

    @Nullable @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || worker != null) return START_NOT_STICKY;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Analysis", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle("TANO VIBE")
                .setContentText("Analysing the playing audio…").setOngoing(true).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(1, n);
        } catch (Exception e) {
            VibeRunner.fallback(this, "Android would not start the capture service: " + e.getClass().getSimpleName(), null);
            stopSelf();
            return START_NOT_STICKY;
        }
        final int code = intent.getIntExtra(EXTRA_CODE, 0);
        final Intent data = intent.getParcelableExtra(EXTRA_DATA);
        final int uid = intent.getIntExtra(EXTRA_UID, -1);
        worker = new Thread(() -> capture(code, data, uid), "vibe-capture");
        worker.start();
        return START_NOT_STICKY;
    }

    private void capture(int code, Intent data, int uid) {
        MediaProjection mp = null;
        AudioRecord rec = null;
        final Handler main = new Handler(Looper.getMainLooper());
        String failure = null;
        AudioAnalyzer an = new AudioAnalyzer(SAMPLE_RATE, 2);
        try {
            if (Build.VERSION.SDK_INT < 29) throw new IllegalStateException("Android 10 or newer is required.");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mp = mpm.getMediaProjection(code, data);
            if (mp == null) throw new IllegalStateException("Capture permission was not granted.");
            // Android 14 requires a callback to be registered before capture starts.
            mp.registerCallback(new MediaProjection.Callback() { @Override public void onStop() { cancelled = true; } }, main);

            AudioPlaybackCaptureConfiguration.Builder cb = new AudioPlaybackCaptureConfiguration.Builder(mp)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN);
            if (uid > 0) cb.addMatchingUid(uid); // only the media app being analysed
            AudioFormat fmt = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build();
            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord.Builder().setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min * 4, 32768)).setAudioPlaybackCaptureConfig(cb.build()).build();
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Audio capture could not be initialised.");
            rec.startRecording();

            short[] buf = new short[4096];
            long total = 0, goal = (long) SAMPLE_RATE * 2 * SECONDS;
            long deadline = System.currentTimeMillis() + (SECONDS + 4) * 1000L;
            while (total < goal && !cancelled && System.currentTimeMillis() < deadline) {
                int n = rec.read(buf, 0, buf.length);
                if (n < 0) throw new IllegalStateException("Audio capture failed (error " + n + ").");
                if (n == 0) continue;
                an.feed(buf, n);
                total += n;
                VibeBus.get().progress(Math.min(1f, total / (float) goal));
                VibeBus.get().bands(an.latestBands());
            }
        } catch (SecurityException e) {
            failure = "Android denied audio capture (permission or app policy).";
        } catch (Exception e) {
            failure = e.getMessage() == null ? "Audio capture failed." : e.getMessage();
        } finally {
            if (rec != null) { try { rec.stop(); } catch (Exception ignored) {} rec.release(); }
            if (mp != null) { try { mp.stop(); } catch (Exception ignored) {} }
        }

        final Runnable finish = () -> { stopForeground(true); stopSelf(); };
        if (failure != null || cancelled) {
            VibeRunner.fallback(this, failure != null ? failure : "Capture was stopped.", finish);
            return;
        }
        AnalysisResult r = an.finish();
        if (!r.valid) {
            // Typical for apps that block playback capture, or when nothing is actually playing.
            VibeRunner.fallback(this, r.invalidReason + " The media app may block audio capture, or nothing was playing.", finish);
            return;
        }
        VibeRunner.apply(this, DecisionEngine.decide(r, new Prefs(this).toConfig()), finish);
    }

    @Override public void onDestroy() { cancelled = true; super.onDestroy(); }
}
