package com.tano.vibe.audio;

/** Measurements taken from REAL captured PCM audio. Never constructed from guesses. */
public final class AnalysisResult {
    public boolean valid;
    /** Why the analysis is invalid (silence, too short, ...). */
    public String invalidReason = "";
    public double durationSec;
    /** Integrated loudness, ITU-R BS.1770 style (K-weighted, gated), in LUFS. */
    public double integratedLufs;
    /** Unweighted RMS over the whole window, dBFS. */
    public double rmsDb;
    /** Sample peak, dBFS. */
    public double peakDb;
    /** Peak minus RMS (crest factor), dB. */
    public double crestDb;
    /** Loudness range (p95 - p10 of gated 400 ms blocks), LU. A dynamic-range estimate. */
    public double loudnessRangeLu;
    /** Share of spectral amplitude: bass &lt;250 Hz, mid 250-4k, treble &gt;4k. Sums to 1. */
    public double bassShare, midShare, trebleShare;
    public double centroidHz;
    /** 0..1 musical-energy estimate (spectral flux + brightness). Level independent on purpose. */
    public double intensity;
    /** Average spectrum, 0..1 per log-spaced band, for display. */
    public float[] bands = new float[AudioAnalyzer.BANDS];
}
