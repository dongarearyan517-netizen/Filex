package com.tano.vibe.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.tano.vibe.audio.DecisionConfig;

/** Local-only user preferences (SharedPreferences). */
public final class Prefs {
    private final SharedPreferences sp;
    public Prefs(Context c) { sp = c.getApplicationContext().getSharedPreferences("tano_vibe", Context.MODE_PRIVATE); }

    /** Conservative default ceiling: 60 %. */
    public int maxVolumePct() { return sp.getInt("max_pct", 60); }
    public void setMaxVolumePct(int v) { sp.edit().putInt("max_pct", v).apply(); }
    public int referenceVolumePct() { return sp.getInt("ref_pct", 45); }
    public void setReferenceVolumePct(int v) { sp.edit().putInt("ref_pct", v).apply(); }
    /** Apply the recommended volume right after analysis (otherwise only recommend). */
    public boolean autoApply() { return sp.getBoolean("auto_apply", true); }
    public void setAutoApply(boolean b) { sp.edit().putBoolean("auto_apply", b).apply(); }
    /** Stop a running adjustment if the user changes volume themselves. */
    public boolean manualOverride() { return sp.getBoolean("manual_override", true); }
    public void setManualOverride(boolean b) { sp.edit().putBoolean("manual_override", b).apply(); }
    /** When analysis is impossible, move to the reference volume (clearly labelled "not analysed"). */
    public boolean fallbackEnabled() { return sp.getBoolean("fallback", true); }
    public void setFallbackEnabled(boolean b) { sp.edit().putBoolean("fallback", b).apply(); }
    public boolean protection() { return sp.getBoolean("protection", true); }
    public void setProtection(boolean b) { sp.edit().putBoolean("protection", b).apply(); }
    public int previousVolumePct() { return sp.getInt("prev_pct", -1); }
    public void setPreviousVolumePct(int v) { sp.edit().putInt("prev_pct", v).apply(); }
    public int lastRecommendedPct() { return sp.getInt("rec_pct", -1); }
    public void setLastRecommendedPct(int v) { sp.edit().putInt("rec_pct", v).apply(); }

    public DecisionConfig toConfig() {
        DecisionConfig c = new DecisionConfig();
        c.maxVolume = maxVolumePct() / 100.0;
        c.referenceVolume = Math.min(referenceVolumePct(), maxVolumePct()) / 100.0;
        c.protection = protection();
        return c;
    }
}
