package com.tano.vibe.volume;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.tano.vibe.audio.DecisionEngine;
import com.tano.vibe.audio.VolumeDecision;
import com.tano.vibe.data.Prefs;

/** Converts a decision into device steps and (optionally) applies it with a smooth ramp. */
public final class VibeRunner {
    private VibeRunner() {}

    /** Analysis was impossible: report why, then use the fallback (if enabled). */
    public static void fallback(Context ctx, String reason, Runnable done) {
        Context app = ctx.getApplicationContext();
        Prefs p = new Prefs(app);
        VibeBus.get().failure(reason);
        if (!p.fallbackEnabled()) {
            VibeBus.get().setBusy(false);
            if (done != null) done.run();
            return;
        }
        apply(app, DecisionEngine.fallback(p.toConfig(), reason), done);
    }

    /** Safe to call from any thread. */
    public static void apply(final Context ctx, final VolumeDecision d, final Runnable done) {
        new Handler(Looper.getMainLooper()).post(() -> run(ctx.getApplicationContext(), d, done));
    }

    private static void run(Context app, VolumeDecision d, final Runnable done) {
        Prefs p = new Prefs(app);
        final VolumeController vc = VolumeController.get(app);
        d.maxStep = vc.max();
        d.targetStep = vc.fractionToStep(d.fraction, vc.userMaxStep(p.maxVolumePct()));
        d.recommendedPct = vc.pct(d.targetStep);
        p.setLastRecommendedPct(d.recommendedPct);
        final VibeBus bus = VibeBus.get();
        if (vc.isFixed() || !p.autoApply()) {
            bus.decision(d, false);
            bus.setBusy(false);
            if (done != null) done.run();
            return;
        }
        p.setPreviousVolumePct(vc.pct(vc.current()));
        bus.decision(d, true);
        vc.rampTo(d.targetStep, p.manualOverride(), (step, interrupted) -> {
            bus.rampDone(step, interrupted);
            bus.setBusy(false);
            if (done != null) done.run();
        });
    }

    /** User tapped "apply recommended" while auto-adjust is off. */
    public static void applyNow(Context ctx, VolumeDecision d) {
        Context app = ctx.getApplicationContext();
        Prefs p = new Prefs(app);
        VolumeController vc = VolumeController.get(app);
        VibeBus bus = VibeBus.get();
        p.setPreviousVolumePct(vc.pct(vc.current()));
        bus.setBusy(true);
        vc.rampTo(d.targetStep, p.manualOverride(), (s, i) -> { bus.rampDone(s, i); bus.setBusy(false); });
    }
}
