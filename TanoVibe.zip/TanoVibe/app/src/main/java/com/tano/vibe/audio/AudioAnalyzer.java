package com.tano.vibe.audio;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Streaming analyser for 16-bit interleaved PCM. Android-free so it can be unit tested.
 *
 * Loudness: K-weighting (BS.1770 shelf + high-pass) -> 100 ms sub-blocks -> 400 ms blocks
 * (75 % overlap) -> absolute gate (-70 LUFS) and relative gate (-10 LU) -> integrated LUFS.
 * Spectrum: Hann-windowed 2048-pt FFT, 50 % overlap, averaged amplitude spectrum.
 */
public final class AudioAnalyzer {
    public static final int BANDS = 24;
    private static final int FFT_SIZE = 2048, HOP = 1024;

    private static final class Biquad {
        double b0, b1, b2, a1, a2, x1, x2, y1, y2;
        double process(double x) {
            double y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = x; y2 = y1; y1 = y;
            return y;
        }
        /** BS.1770 stage 1: high shelf (+4 dB, ~1.68 kHz). */
        static Biquad shelf(double fs) {
            double f0 = 1681.974450955533, g = 3.999843853973347, q = 0.7071752369554196;
            double k = Math.tan(Math.PI * f0 / fs);
            double vh = Math.pow(10, g / 20.0), vb = Math.pow(vh, 0.4996667741545416);
            double a0 = 1 + k / q + k * k;
            Biquad b = new Biquad();
            b.b0 = (vh + vb * k / q + k * k) / a0;
            b.b1 = 2 * (k * k - vh) / a0;
            b.b2 = (vh - vb * k / q + k * k) / a0;
            b.a1 = 2 * (k * k - 1) / a0;
            b.a2 = (1 - k / q + k * k) / a0;
            return b;
        }
        /** BS.1770 stage 2: high-pass (~38 Hz). */
        static Biquad highpass(double fs) {
            double f0 = 38.13547087602444, q = 0.5003270373238773;
            double k = Math.tan(Math.PI * f0 / fs);
            double a0 = 1 + k / q + k * k;
            Biquad b = new Biquad();
            b.b0 = 1; b.b1 = -2; b.b2 = 1;
            b.a1 = 2 * (k * k - 1) / a0;
            b.a2 = (1 - k / q + k * k) / a0;
            return b;
        }
    }

    private final int sampleRate, channels, subLen;
    private final Biquad[] shelf, hp;
    private final double[] subSum;
    private int subCount;
    private final double[] ring = new double[4];
    private int ringPos, ringFilled;
    private final ArrayList<Double> blockZ = new ArrayList<>();

    private double peak, sumSq;
    private long frames;

    private final double[] window = new double[FFT_SIZE];
    private final double[] fftBuf = new double[FFT_SIZE], re = new double[FFT_SIZE], im = new double[FFT_SIZE];
    private int fftPos;
    private final double[] magSum = new double[FFT_SIZE / 2];
    private final int[] bandLo = new int[BANDS], bandHi = new int[BANDS];
    private final double[] bandMagSum = new double[BANDS];
    private long specFrames;
    private double[] prevNorm;
    private double fluxSum;
    private long fluxCount;
    private volatile float[] liveBands = new float[BANDS];

    public AudioAnalyzer(int sampleRate, int channels) {
        this.sampleRate = sampleRate;
        this.channels = Math.max(1, channels);
        this.subLen = sampleRate / 10;
        shelf = new Biquad[this.channels];
        hp = new Biquad[this.channels];
        for (int c = 0; c < this.channels; c++) { shelf[c] = Biquad.shelf(sampleRate); hp[c] = Biquad.highpass(sampleRate); }
        subSum = new double[this.channels];
        for (int i = 0; i < FFT_SIZE; i++) window[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (FFT_SIZE - 1));
        // log-spaced bands 40 Hz .. min(16 kHz, 0.45 fs)
        double fMin = 40, fMax = Math.min(16000, sampleRate * 0.45), binHz = (double) sampleRate / FFT_SIZE;
        for (int b = 0; b < BANDS; b++) {
            double f0 = fMin * Math.pow(fMax / fMin, (double) b / BANDS);
            double f1 = fMin * Math.pow(fMax / fMin, (double) (b + 1) / BANDS);
            bandLo[b] = Math.max(1, (int) Math.round(f0 / binHz));
            bandHi[b] = Math.max(bandLo[b] + 1, (int) Math.round(f1 / binHz));
            if (b > 0 && bandLo[b] < bandHi[b - 1]) bandLo[b] = bandHi[b - 1];
            if (bandHi[b] <= bandLo[b]) bandHi[b] = bandLo[b] + 1;
        }
    }

    /** Feed interleaved samples ({@code len} = number of shorts). */
    public void feed(short[] buf, int len) {
        for (int i = 0; i + channels <= len; i += channels) {
            double mono = 0;
            for (int c = 0; c < channels; c++) {
                double x = buf[i + c] / 32768.0, ax = Math.abs(x);
                if (ax > peak) peak = ax;
                sumSq += x * x;
                mono += x;
                double y = hp[c].process(shelf[c].process(x));
                subSum[c] += y * y;
            }
            frames++;
            if (++subCount == subLen) endSubBlock();
            fftBuf[fftPos++] = mono / channels;
            if (fftPos == FFT_SIZE) {
                processFrame();
                System.arraycopy(fftBuf, HOP, fftBuf, 0, FFT_SIZE - HOP);
                fftPos = FFT_SIZE - HOP;
            }
        }
    }

    private void endSubBlock() {
        double z = 0;
        for (int c = 0; c < channels; c++) { z += subSum[c] / subLen; subSum[c] = 0; }
        subCount = 0;
        ring[ringPos] = z;
        ringPos = (ringPos + 1) & 3;
        if (++ringFilled >= 4) blockZ.add((ring[0] + ring[1] + ring[2] + ring[3]) / 4.0);
    }

    private void processFrame() {
        for (int n = 0; n < FFT_SIZE; n++) { re[n] = fftBuf[n] * window[n]; im[n] = 0; }
        fft(re, im);
        double[] bandMag = new double[BANDS];
        for (int k = 1; k < FFT_SIZE / 2; k++) magSum[k] += Math.sqrt(re[k] * re[k] + im[k] * im[k]);
        double total = 0;
        float[] live = new float[BANDS];
        for (int b = 0; b < BANDS; b++) {
            double e = 0;
            for (int k = bandLo[b]; k < bandHi[b] && k < FFT_SIZE / 2; k++) e += re[k] * re[k] + im[k] * im[k];
            bandMag[b] = Math.sqrt(e);
            bandMagSum[b] += bandMag[b];
            total += bandMag[b];
            live[b] = toLevel(bandMag[b]);
        }
        liveBands = live;
        specFrames++;
        // level-independent spectral flux (normalise each frame to sum 1)
        if (total > 1e-9) {
            double[] norm = new double[BANDS];
            for (int b = 0; b < BANDS; b++) norm[b] = bandMag[b] / total;
            if (prevNorm != null) {
                double f = 0;
                for (int b = 0; b < BANDS; b++) f += Math.max(0, norm[b] - prevNorm[b]);
                fluxSum += f; fluxCount++;
            }
            prevNorm = norm;
        }
    }

    /** Absolute display level: -80 dBFS -> 0, -20 dBFS -> 1 (FFT scaled so a full-scale sine ~ 0 dBFS). */
    private static float toLevel(double mag) {
        double db = 20 * Math.log10(mag / (FFT_SIZE / 4.0) + 1e-9);
        return (float) Math.max(0, Math.min(1, (db + 80) / 60.0));
    }

    /** Latest spectrum frame, for live visualisation (thread-safe snapshot). */
    public float[] latestBands() { return liveBands.clone(); }

    public AnalysisResult finish() {
        AnalysisResult r = new AnalysisResult();
        r.durationSec = (double) frames / sampleRate;
        if (r.durationSec < 2.0 || blockZ.size() < 5) { r.invalidReason = "Not enough audio was captured."; return r; }
        r.peakDb = 20 * Math.log10(Math.max(peak, 1e-9));
        if (peak < 1e-3) { r.invalidReason = "The captured audio was digital silence."; return r; }
        r.rmsDb = 10 * Math.log10(Math.max(sumSq / (frames * (double) channels), 1e-12));
        r.crestDb = r.peakDb - r.rmsDb;

        double absGate = Math.pow(10, (-70 + 0.691) / 10.0);
        double s1 = 0; int n1 = 0;
        for (double z : blockZ) if (z > absGate) { s1 += z; n1++; }
        if (n1 == 0) { r.invalidReason = "The captured audio was below the measurable level."; return r; }
        double mean1 = s1 / n1, relGate = mean1 * Math.pow(10, -1.0);
        double s2 = 0; int n2 = 0;
        for (double z : blockZ) if (z > absGate && z > relGate) { s2 += z; n2++; }
        r.integratedLufs = -0.691 + 10 * Math.log10(n2 > 0 ? s2 / n2 : mean1);

        double lraGate = mean1 * Math.pow(10, -2.0);
        ArrayList<Double> vals = new ArrayList<>();
        for (double z : blockZ) if (z > absGate && z > lraGate) vals.add(-0.691 + 10 * Math.log10(z));
        if (vals.size() >= 5) {
            double[] v = new double[vals.size()];
            for (int i = 0; i < v.length; i++) v[i] = vals.get(i);
            Arrays.sort(v);
            r.loudnessRangeLu = v[(int) Math.round(0.95 * (v.length - 1))] - v[(int) Math.round(0.10 * (v.length - 1))];
        }

        double bass = 0, mid = 0, treb = 0, cw = 0, binHz = (double) sampleRate / FFT_SIZE;
        for (int k = 1; k < FFT_SIZE / 2; k++) {
            double f = k * binHz, m = magSum[k];
            if (f < 20) continue;
            if (f < 250) bass += m; else if (f < 4000) mid += m; else treb += m;
            cw += f * m;
        }
        double tot = bass + mid + treb;
        if (tot > 0) { r.bassShare = bass / tot; r.midShare = mid / tot; r.trebleShare = treb / tot; r.centroidHz = cw / tot; }

        double flux = fluxCount > 0 ? fluxSum / fluxCount : 0;
        double fluxN = Math.max(0, Math.min(1, flux / 0.25));
        double centN = Math.max(0, Math.min(1, (r.centroidHz - 500) / 3500.0));
        r.intensity = 0.65 * fluxN + 0.35 * centN;

        for (int b = 0; b < BANDS; b++) r.bands[b] = specFrames > 0 ? toLevel(bandMagSum[b] / specFrames) : 0;
        r.valid = true;
        return r;
    }

    /** In-place radix-2 FFT. */
    private static void fft(double[] re, double[] im) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) { double t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double cr = 1, ci = 0;
                for (int k = 0; k < len / 2; k++) {
                    int a = i + k, b = i + k + len / 2;
                    double tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                    re[b] = re[a] - tr; im[b] = im[a] - ti;
                    re[a] += tr; im[a] += ti;
                    double ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
                }
            }
        }
    }
}
