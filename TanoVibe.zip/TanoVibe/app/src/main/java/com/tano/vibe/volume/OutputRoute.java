package com.tano.vibe.volume;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;

/** Describes the real current audio output, read from AudioManager (nothing simulated). */
public final class OutputRoute {
    public enum Kind { BLUETOOTH, WIRED, USB, SPEAKER, OTHER }
    public final Kind kind;
    public final String name;
    private OutputRoute(Kind k, String n) { kind = k; name = n; }

    public String kindLabel() {
        switch (kind) {
            case BLUETOOTH: return "BLUETOOTH";
            case WIRED: return "WIRED";
            case USB: return "USB AUDIO";
            case SPEAKER: return "PHONE SPEAKER";
            default: return "OUTPUT";
        }
    }

    public static OutputRoute read(Context c) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        OutputRoute best = null;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            Kind k = kindOf(d.getType());
            String n = d.getProductName() == null ? "" : d.getProductName().toString();
            if (k == Kind.OTHER) continue;
            if (best == null || k.ordinal() < best.kind.ordinal()) best = new OutputRoute(k, n);
        }
        return best != null ? best : new OutputRoute(Kind.OTHER, "Unknown");
    }

    private static Kind kindOf(int t) {
        if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return Kind.BLUETOOTH;
        if (Build.VERSION.SDK_INT >= 31 && (t == AudioDeviceInfo.TYPE_BLE_HEADSET || t == AudioDeviceInfo.TYPE_BLE_SPEAKER)) return Kind.BLUETOOTH;
        if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_LINE_ANALOG) return Kind.WIRED;
        if (t == AudioDeviceInfo.TYPE_USB_DEVICE || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_USB_ACCESSORY) return Kind.USB;
        if (t == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) return Kind.SPEAKER;
        return Kind.OTHER;
    }
}
