package com.tano.vibe.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Large central button: glowing disc + 60-segment progress ring (echoes the segmented donut in TANO FileX). */
public class SetVibeButton extends View {
    private static final int TICKS = 60;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float progress, glow = 0.5f;
    private String main = "SET MY\nVIBE", sub = "";
    private ValueAnimator pulse;

    public SetVibeButton(Context c, AttributeSet a) { super(c, a); setClickable(true); setFocusable(true); }

    public void setState(String mainText, String subText, float prog) {
        main = mainText; sub = subText; progress = Math.max(0, Math.min(1, prog));
        setContentDescription((mainText + " " + subText).replace('\n', ' '));
        invalidate();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        pulse = ValueAnimator.ofFloat(0.35f, 0.8f);
        pulse.setDuration(2200); pulse.setRepeatMode(ValueAnimator.REVERSE); pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.addUpdateListener(a -> { glow = (float) a.getAnimatedValue(); invalidate(); });
        pulse.start();
    }
    @Override protected void onDetachedFromWindow() { if (pulse != null) pulse.cancel(); super.onDetachedFromWindow(); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (isEnabled()) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL)
                animate().scaleX(1f).scaleY(1f).setDuration(140).start();
        }
        return super.onTouchEvent(e);
    }
    @Override public boolean performClick() { return super.performClick(); }

    @Override protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density, cx = getWidth() / 2f, cy = getHeight() / 2f;
        float R = Math.min(getWidth(), getHeight()) / 2f - 4 * d;
        // soft glow
        p.setStyle(Paint.Style.FILL);
        int ga = (int) (glow * 120);
        p.setShader(new RadialGradient(cx, cy, R * 1.05f, new int[]{0x00000000, (ga << 24) | 0x7B3FE4, 0x00000000}, new float[]{0.62f, 0.85f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R * 1.05f, p);
        p.setShader(null);
        // segmented ring
        int lit = Math.round(progress * TICKS);
        for (int i = 0; i < TICKS; i++) {
            c.save();
            c.rotate(i * (360f / TICKS), cx, cy);
            p.setColor(i < lit ? (i % 2 == 0 ? 0xFFD86CFF : 0xFFC9A8FF) : 0xFF2A1E4A);
            rect.set(cx - 1.6f * d, cy - R, cx + 1.6f * d, cy - R + 11 * d);
            c.drawRoundRect(rect, d, d, p);
            c.restore();
        }
        // inner disc
        float r = R - 24 * d;
        p.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFF8B5CFF, 0xFF3B1E8A, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f * d); p.setColor(0xAAC9A8FF);
        c.drawCircle(cx, cy, r, p);
        // text
        p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Fonts.pixel(getContext()));
        String[] lines = main.split("\n");
        float ts = 26 * d; p.setTextSize(ts);
        float total = lines.length * ts * 1.05f + (sub.isEmpty() ? 0 : 16 * d);
        float y = cy - total / 2f + ts * 0.85f;
        for (String l : lines) { c.drawText(l, cx, y, p); y += ts * 1.05f; }
        if (!sub.isEmpty()) {
            p.setTypeface(Fonts.label(getContext())); p.setTextSize(11 * d); p.setColor(0xFFE5D4FF);
            c.drawText(sub, cx, y + 2 * d, p);
        }
    }
}
