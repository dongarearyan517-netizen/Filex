package com.tano.vibe.volume;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;

/** Wraps AudioManager STREAM_MUSIC with smooth, cancellable, one-step-at-a-time ramps. */
public final class VolumeController {
    public interface Callback { void onDone(int finalStep, boolean interruptedByUser); }

    private static VolumeController instance;
    public static synchronized VolumeController get(Context c) {
        if (instance == null) instance = new VolumeController(c.getApplicationContext());
        return instance;
    }

    private static final long TICK_MS = 130;
    private final AudioManager am;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Runnable ramp;
    private int expected;

    private VolumeController(Context c) { am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE); }

    public int max() { return Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)); }
    public int current() { return am.getStreamVolume(AudioManager.STREAM_MUSIC); }
    public int pct(int step) { return Math.round(step * 100f / max()); }
    public boolean isFixed() { return am.isVolumeFixed(); }

    public int userMaxStep(int maxPct) { return Math.max(1, (int) Math.floor(maxPct / 100.0 * max())); }
    public int fractionToStep(double fraction, int userMaxStep) {
        int s = (int) Math.round(fraction * max());
        return Math.max(1, Math.min(s, userMaxStep));
    }

    /** Immediate set (manual slider). Flag 0 = no system UI; Android's own limits still apply. */
    public void setImmediate(int step) {
        cancel();
        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(step, max())), 0); }
        catch (SecurityException ignored) { /* e.g. restricted by Do Not Disturb policy on some devices */ }
    }

    public void cancel() { if (ramp != null) { h.removeCallbacks(ramp); ramp = null; } }

    /** Gradually move to {@code target}. If detectManual and the user changes volume meanwhile, stop. */
    public void rampTo(final int target, final boolean detectManual, final Callback cb) {
        cancel();
        expected = current();
        ramp = new Runnable() {
            @Override public void run() {
                int cur = current();
                if (detectManual && cur != expected) { ramp = null; if (cb != null) cb.onDone(cur, true); return; }
                if (cur == target) { ramp = null; if (cb != null) cb.onDone(cur, false); return; }
                int next = cur + (target > cur ? 1 : -1);
                try { am.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0); }
                catch (SecurityException e) { ramp = null; if (cb != null) cb.onDone(cur, false); return; }
                expected = next;
                if (current() != next) {
                    // Device refused (fixed volume / policy): stop instead of looping forever.
                    ramp = null; if (cb != null) cb.onDone(current(), false); return;
                }
                h.postDelayed(this, TICK_MS);
            }
        };
        h.post(ramp);
    }
}
