package com.tano.vibe.media;

/** Snapshot of the active media session (real data from MediaSessionManager). */
public final class MediaInfo {
    public boolean accessGranted;
    public boolean hasSession;
    public boolean playing;
    public String title = "", artist = "", packageName = "", sourceName = "";
    public int uid = -1;
}
