package com.tano.vibe;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import com.tano.vibe.data.Prefs;
import com.tano.vibe.media.MediaWatcher;
import com.tano.vibe.ui.Fonts;
import com.tano.vibe.volume.OutputRoute;

/** Settings built in code so every row is bound to a real preference or a real system status. */
public class SettingsActivity extends AppCompatActivity {
    private Prefs prefs;
    private LinearLayout root;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(getColor(R.color.bg));
        sv.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() { super.onResume(); build(); }

    private void build() {
        root.removeAllViews();
        TextView back = text("‹ BACK", 11, R.color.lavender, true);
        back.setOnClickListener(v -> finish());
        root.addView(back);
        TextView t = text("Settings", 30, R.color.text, false);
        t.setPadding(0, dp(12), 0, dp(4));
        root.addView(t);

        // --- Volume ---
        LinearLayout c = card("VOLUME");
        slider(c, "MAXIMUM VOLUME", prefs.maxVolumePct(), 10, 100, v -> {
            prefs.setMaxVolumePct(v);
            if (prefs.referenceVolumePct() > v) prefs.setReferenceVolumePct(v);
        });
        slider(c, "REFERENCE VOLUME (YOUR USUAL LEVEL)", prefs.referenceVolumePct(), 10, 100, prefs::setReferenceVolumePct);
        toggle(c, "Automatic volume adjustment", "Apply the recommendation after analysis. Off = recommend only.", prefs.autoApply(), prefs::setAutoApply);
        toggle(c, "Manual override", "If you touch volume while it adjusts, stop and keep your level.", prefs.manualOverride(), prefs::setManualOverride);
        toggle(c, "Ear protection", "Trim volume slightly for very bass-heavy or harsh tracks.", prefs.protection(), prefs::setProtection);
        toggle(c, "Fallback when audio can't be analysed", "Moves to your reference volume and labels it NOT ANALYSED.", prefs.fallbackEnabled(), prefs::setFallbackEnabled);

        // --- Status ---
        c = card("STATUS");
        boolean notif = MediaWatcher.hasAccess(this);
        status(c, "Notification access", notif ? "Granted" : "Not granted", notif,
                notif ? null : "OPEN", v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        boolean rec = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        status(c, "Audio-capture permission", rec ? "Granted (microphone is never used)" : "Asked when you press SET MY VIBE", rec, null, null);
        boolean api = Build.VERSION.SDK_INT >= 29;
        status(c, "Playback capture (Android)", api ? "Supported by this Android version" : "Needs Android 10+ — fallback only", api, null, null);
        status(c, "Supported media detection", notif ? "Spotify, YouTube, YouTube Music & any MediaSession app" : "Needs notification access", notif, null, null);
        OutputRoute o = OutputRoute.read(this);
        status(c, "Output / Bluetooth", o.kindLabel() + (o.name.isEmpty() ? "" : " · " + o.name), o.kind == OutputRoute.Kind.BLUETOOTH, null, null);

        // --- About ---
        c = card("ABOUT TANO VIBE");
        c.addView(text("TANO VIBE 1.0.0", 18, R.color.text, false));
        TextView a = text("Press once, and your music gets the volume it deserves. Analysis happens on this device from real audio; nothing is uploaded or stored.\n\nDeveloper: TANOLOPP\nFonts: Pixelify Sans & Silkscreen (SIL Open Font License).\n\nLimits: some apps block audio capture, and DRM-protected audio can't be analysed. TANO VIBE then tells you plainly and never invents a result.", 13, R.color.muted, false);
        a.setPadding(0, dp(8), 0, 0);
        c.addView(a);
        Fonts.apply(root);
    }

    // ---------- row helpers ----------
    private interface IntSetter { void set(int v); }
    private interface BoolSetter { void set(boolean b); }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackgroundResource(R.drawable.bg_card);
        c.setPadding(dp(18), dp(18), dp(18), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        root.addView(c, lp);
        TextView h = text(title, 10, R.color.lavender, true);
        h.setPadding(0, 0, 0, dp(10));
        c.addView(h);
        return c;
    }

    private void slider(LinearLayout parent, String label, int value, int min, int max, IntSetter setter) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, 0, 0, dp(14));
        LinearLayout head = new LinearLayout(this);
        TextView l = text(label, 10, R.color.muted, true);
        l.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text(value + "%", 11, R.color.lavender, true);
        head.addView(l); head.addView(val);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min); s.setProgress(value - min);
        s.setProgressDrawable(getDrawable(R.drawable.seek_progress));
        s.setThumb(getDrawable(R.drawable.seek_thumb));
        s.setPadding(dp(12), dp(10), dp(12), dp(4));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { val.setText((p + min) + "%"); if (u) setter.set(p + min); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        row.addView(head); row.addView(s);
        parent.addView(row);
    }

    private void toggle(LinearLayout parent, String title, String sub, boolean on, BoolSetter setter) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(10));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        txt.addView(text(title, 16, R.color.text, false));
        txt.addView(text(sub, 12, R.color.muted, false));
        SwitchCompat sw = new SwitchCompat(this);
        sw.setChecked(on);
        sw.setThumbTintList(getColorStateList(R.color.switch_thumb));
        sw.setTrackTintList(getColorStateList(R.color.switch_track));
        sw.setOnCheckedChangeListener((v, c) -> setter.set(c));
        row.addView(txt); row.addView(sw);
        parent.addView(row);
    }

    private void status(LinearLayout parent, String title, String value, boolean ok, String action, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(10));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        txt.addView(text(title, 16, R.color.text, false));
        txt.addView(text("● " + value, 12, ok ? R.color.ok : R.color.warn, false));
        row.addView(txt);
        if (action != null) {
            TextView b = text(action, 10, R.color.text, true);
            b.setBackgroundResource(R.drawable.bg_btn_outline);
            b.setPadding(dp(14), dp(9), dp(14), dp(9));
            b.setOnClickListener(click);
            row.addView(b);
        }
        parent.addView(row);
    }

    private TextView text(String s, int sp, int color, boolean label) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(getColor(color));
        t.setTag(label ? "label" : "pixel");
        if (label) t.setLetterSpacing(0.12f);
        return t;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
