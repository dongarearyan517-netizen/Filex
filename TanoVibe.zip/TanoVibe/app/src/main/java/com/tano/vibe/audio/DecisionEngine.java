package com.tano.vibe.audio;

import java.util.Locale;

/** Turns measured audio characteristics into a recommended volume fraction. */
public final class DecisionEngine {
    private DecisionEngine() {}

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static String f(String fmt, Object... a) { return String.format(Locale.US, fmt, a); }

    public static VolumeDecision decide(AnalysisResult r, DecisionConfig c) {
        VolumeDecision d = new VolumeDecision();
        d.analysed = true; d.analysis = r;

        // 1) Loudness normalisation: louder-than-reference tracks get less volume, quieter ones more.
        double offset = clamp(c.referenceLufs - r.integratedLufs, -c.maxOffsetDb, c.maxOffsetDb);
        double total = offset;
        d.reasons.add(f("Loudness %.1f LUFS vs %.0f reference: %+.1f dB", r.integratedLufs, c.referenceLufs, offset));

        // 2) Dynamic range: wide range means quiet passages; give a little extra level.
        if (r.loudnessRangeLu > 8) {
            double boost = clamp((r.loudnessRangeLu - 8) / 8.0, 0, 1) * c.dynamicBoostMaxDb;
            total += boost;
            d.reasons.add(f("Wide dynamic range (%.1f LU): %+.1f dB", r.loudnessRangeLu, boost));
        }
        // 3) Ear/speaker protection for bass-heavy or bright material.
        if (c.protection) {
            if (r.bassShare > 0.55) {
                double cut = clamp((r.bassShare - 0.55) / 0.25, 0, 1) * c.bassCutMaxDb;
                total -= cut;
                d.reasons.add(f("Bass-heavy (%.0f%% of spectrum): %+.1f dB", r.bassShare * 100, -cut));
            }
            if (r.trebleShare > 0.10) {
                double cut = clamp((r.trebleShare - 0.10) / 0.15, 0, 1) * c.trebleCutMaxDb;
                total -= cut;
                d.reasons.add(f("Bright / harsh (%.0f%% treble): %+.1f dB", r.trebleShare * 100, -cut));
            }
        }
        // 4) Intensity: tiny nudge only. High musical energy feels louder at equal LUFS.
        double nudge = -(r.intensity - 0.5) * 2 * c.intensityMaxDb;
        total += nudge;
        d.reasons.add(f("Musical intensity %.0f%% (separate from loudness): %+.1f dB", r.intensity * 100, nudge));

        double frac = c.referenceVolume + total / c.dbSpan;
        double capped = clamp(frac, c.minVolume, Math.max(c.minVolume, c.maxVolume));
        d.clampedByMax = frac > c.maxVolume;
        if (d.clampedByMax) d.reasons.add(f("Limited by your %.0f%% maximum", c.maxVolume * 100));
        d.fraction = capped;
        return d;
    }

    /** Used when audio could not be analysed. Never presented as an analysis. */
    public static VolumeDecision fallback(DecisionConfig c, String reason) {
        VolumeDecision d = new VolumeDecision();
        d.analysed = false;
        d.fallbackReason = reason;
        d.fraction = clamp(c.referenceVolume, c.minVolume, Math.max(c.minVolume, c.maxVolume));
        d.reasons.add("No audio analysis was performed.");
        d.reasons.add(f("Using your reference volume (%.0f%%).", c.referenceVolume * 100));
        return d;
    }
}
