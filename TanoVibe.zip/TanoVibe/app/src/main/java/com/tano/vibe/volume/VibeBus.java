package com.tano.vibe.volume;

import android.os.Handler;
import android.os.Looper;
import com.tano.vibe.audio.VolumeDecision;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tiny in-process event bus between CaptureService / VibeRunner and the UI. Always delivers on the main thread. */
public final class VibeBus {
    public interface Listener {
        default void onBusy(boolean busy) {}
        default void onProgress(float p) {}
        default void onBands(float[] bands) {}
        default void onFailure(String message) {}
        default void onDecision(VolumeDecision d, boolean applied) {}
        default void onRampDone(int finalStep, boolean interrupted) {}
    }
    private static final VibeBus I = new VibeBus();
    public static VibeBus get() { return I; }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<Listener> ls = new CopyOnWriteArrayList<>();
    private volatile boolean busy;
    private volatile VolumeDecision last;

    public void add(Listener l) { ls.addIfAbsent(l); }
    public void remove(Listener l) { ls.remove(l); }
    public boolean isBusy() { return busy; }
    public VolumeDecision last() { return last; }

    public void setBusy(final boolean b) { busy = b; main.post(() -> { for (Listener l : ls) l.onBusy(b); }); }
    public void progress(final float p) { main.post(() -> { for (Listener l : ls) l.onProgress(p); }); }
    public void bands(final float[] b) { main.post(() -> { for (Listener l : ls) l.onBands(b); }); }
    public void failure(final String m) { main.post(() -> { for (Listener l : ls) l.onFailure(m); }); }
    public void decision(final VolumeDecision d, final boolean applied) { last = d; main.post(() -> { for (Listener l : ls) l.onDecision(d, applied); }); }
    public void rampDone(final int s, final boolean i) { main.post(() -> { for (Listener l : ls) l.onRampDone(s, i); }); }
}
