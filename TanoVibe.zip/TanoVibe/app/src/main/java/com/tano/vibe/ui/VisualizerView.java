package com.tano.vibe.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import com.tano.vibe.audio.AudioAnalyzer;

/** Pixel-grid spectrum display. Shows only real analyser data; idle = empty grid. */
public class VisualizerView extends View {
    private static final int ROWS = 12, N = AudioAnalyzer.BANDS;
    private final float[] target = new float[N], shown = new float[N];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    public VisualizerView(Context c, AttributeSet a) { super(c, a); }

    public void setLevels(float[] levels) {
        for (int i = 0; i < N && i < levels.length; i++) target[i] = Math.max(0, Math.min(1, levels[i]));
        invalidate();
    }
    public void clear() { java.util.Arrays.fill(target, 0); invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), gap = w / N * 0.22f;
        float cw = (w - gap * (N - 1)) / N, ch = (h - gap * (ROWS - 1)) / ROWS;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float d = target[i] - shown[i];
            if (Math.abs(d) > 0.01f) { shown[i] += d * 0.3f; moving = true; } else shown[i] = target[i];
            int lit = Math.round(shown[i] * ROWS);
            for (int row = 0; row < ROWS; row++) {
                float x = i * (cw + gap), y = h - (row + 1) * ch - row * gap;
                r.set(x, y, x + cw, y + ch);
                if (row < lit) {
                    float t = row / (float) (ROWS - 1);
                    p.setColor(blend(0xFF7B3FE4, 0xFFD86CFF, t));
                } else p.setColor(0xFF1E1538);
                cv.drawRoundRect(r, cw * 0.2f, cw * 0.2f, p);
            }
        }
        if (moving) postInvalidateOnAnimation();
    }

    private static int blend(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }
}
