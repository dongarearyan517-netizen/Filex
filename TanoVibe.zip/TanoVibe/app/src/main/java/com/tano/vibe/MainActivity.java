package com.tano.vibe;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.tano.vibe.audio.AnalysisResult;
import com.tano.vibe.audio.CaptureService;
import com.tano.vibe.audio.VolumeDecision;
import com.tano.vibe.data.Prefs;
import com.tano.vibe.media.MediaInfo;
import com.tano.vibe.media.MediaWatcher;
import com.tano.vibe.ui.Fonts;
import com.tano.vibe.ui.SetVibeButton;
import com.tano.vibe.ui.VisualizerView;
import com.tano.vibe.volume.OutputRoute;
import com.tano.vibe.volume.VibeBus;
import com.tano.vibe.volume.VibeRunner;
import com.tano.vibe.volume.VolumeController;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements VibeBus.Listener {
    private TextView tvSource, tvTitle, tvArtist, btnGrant, tvStatus, tvPrevious, tvCurrent, tvRecommended,
            tvApplyHint, tvVolumePct, tvOutputName, tvOutputKind, tvReasons, tvResultTitle;
    private SetVibeButton vibeButton;
    private VisualizerView visualizer;
    private SeekBar seek;
    private View resultCard;
    private LinearLayout resultRows;

    private Prefs prefs;
    private VolumeController vc;
    private MediaWatcher watcher;
    private MediaInfo media = new MediaInfo();
    private boolean dragging;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final ContentObserver volObserver = new ContentObserver(main) {
        @Override public void onChange(boolean selfChange) { refreshVolume(); }
    };
    private final AudioDeviceCallback deviceCb = new AudioDeviceCallback() {
        @Override public void onAudioDevicesAdded(AudioDeviceInfo[] d) { refreshOutput(); }
        @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] d) { refreshOutput(); }
    };

    private ActivityResultLauncher<String[]> permLauncher;
    private ActivityResultLauncher<Intent> projLauncher;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);
        vc = VolumeController.get(this);

        tvSource = findViewById(R.id.tvSource); tvTitle = findViewById(R.id.tvTitle); tvArtist = findViewById(R.id.tvArtist);
        btnGrant = findViewById(R.id.btnGrant); tvStatus = findViewById(R.id.tvStatus);
        tvPrevious = findViewById(R.id.tvPrevious); tvCurrent = findViewById(R.id.tvCurrent);
        tvRecommended = findViewById(R.id.tvRecommended); tvApplyHint = findViewById(R.id.tvApplyHint);
        tvVolumePct = findViewById(R.id.tvVolumePct); tvOutputName = findViewById(R.id.tvOutputName);
        tvOutputKind = findViewById(R.id.tvOutputKind); tvReasons = findViewById(R.id.tvReasons);
        tvResultTitle = findViewById(R.id.tvResultTitle);
        vibeButton = findViewById(R.id.vibeButton); visualizer = findViewById(R.id.visualizer);
        seek = findViewById(R.id.seekVolume); resultCard = findViewById(R.id.resultCard);
        resultRows = findViewById(R.id.resultRows);
        Fonts.apply(findViewById(android.R.id.content));

        permLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), res -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) requestProjection();
            else failFallback("Audio-capture permission was denied. Android requires it for playback capture; TANO VIBE never records the microphone.");
        });
        projLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), res -> {
            if (res.getResultCode() == RESULT_OK && res.getData() != null) {
                Intent i = new Intent(this, CaptureService.class)
                        .putExtra(CaptureService.EXTRA_CODE, res.getResultCode())
                        .putExtra(CaptureService.EXTRA_DATA, res.getData())
                        .putExtra(CaptureService.EXTRA_UID, media.uid);
                try { ContextCompat.startForegroundService(this, i); }
                catch (Exception e) { failFallback("Could not start the analysis service: " + e.getClass().getSimpleName()); }
            } else failFallback("Screen/audio capture was not allowed, so the song could not be analysed.");
        });

        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        btnGrant.setOnClickListener(v -> openNotificationAccess());
        vibeButton.setOnClickListener(v -> onSetVibe());
        findViewById(R.id.cardRecommended).setOnClickListener(v -> {
            VolumeDecision d = VibeBus.get().last();
            if (d != null && !VibeBus.get().isBusy()) VibeRunner.applyNow(this, d);
        });

        seek.setMax(vc.max());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) { vc.setImmediate(p); tvVolumePct.setText(vc.pct(p) + "%"); tvCurrent.setText(vc.pct(p) + "%"); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { dragging = false; }
        });

        watcher = new MediaWatcher(this, info -> { media = info; renderMedia(); });
        renderIdle();
    }

    @Override protected void onStart() {
        super.onStart();
        VibeBus.get().add(this);
        watcher.start();
        getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, volObserver);
        ((AudioManager) getSystemService(AUDIO_SERVICE)).registerAudioDeviceCallback(deviceCb, main);
        refreshVolume(); refreshOutput();
        VolumeDecision last = VibeBus.get().last();
        if (last != null) showDecision(last, false);
        onBusy(VibeBus.get().isBusy());
    }

    @Override protected void onStop() {
        super.onStop();
        VibeBus.get().remove(this);
        watcher.stop();
        getContentResolver().unregisterContentObserver(volObserver);
        ((AudioManager) getSystemService(AUDIO_SERVICE)).unregisterAudioDeviceCallback(deviceCb);
    }

    // ---------- SET MY VIBE flow ----------
    private void onSetVibe() {
        if (VibeBus.get().isBusy()) return;
        if (Build.VERSION.SDK_INT < 29) { failFallback("Direct audio analysis needs Android 10 or newer."); return; }
        if (media.accessGranted && !media.playing) {
            Toast.makeText(this, "Start playing a song first.", Toast.LENGTH_SHORT).show();
            return;
        }
        VibeBus.get().setBusy(true);
        visualizer.clear();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                && (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            requestProjection();
        } else {
            permLauncher.launch(Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.RECORD_AUDIO});
        }
    }

    private void requestProjection() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        try { projLauncher.launch(mpm.createScreenCaptureIntent()); }
        catch (Exception e) { failFallback("This device cannot show the capture permission dialog."); }
    }

    private void failFallback(String reason) {
        VibeBus.get().setBusy(true);
        VibeRunner.fallback(this, reason, null);
    }

    private void openNotificationAccess() {
        try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Open Settings > Notifications > Notification access.", Toast.LENGTH_LONG).show(); }
    }

    // ---------- Bus callbacks ----------
    @Override public void onBusy(boolean busy) {
        vibeButton.setEnabled(!busy);
        if (busy) { vibeButton.setState("LISTENING", "0%", 0f); setStatus("ANALYSING THE PLAYING AUDIO…", false); }
    }
    @Override public void onProgress(float p) {
        vibeButton.setState("LISTENING", Math.round(p * 100) + "%", p);
        setStatus("ANALYSING · " + Math.round(p * 100) + "%", false);
    }
    @Override public void onBands(float[] b) { visualizer.setLevels(b); }
    @Override public void onFailure(String m) { setStatus("ANALYSIS UNAVAILABLE · " + m.toUpperCase(Locale.US), true); }
    @Override public void onDecision(VolumeDecision d, boolean applied) {
        showDecision(d, applied);
        if (applied) vibeButton.setState("ADJUSTING", d.recommendedPct + "%", 1f);
        else vibeButton.setState("SET MY\nVIBE", "", 0f);
    }
    @Override public void onRampDone(int step, boolean interrupted) {
        refreshVolume();
        if (interrupted) { vibeButton.setState("YOUR\nLEVEL", "KEPT", 1f); setStatus("STOPPED · YOU CHANGED THE VOLUME", false); }
        else { vibeButton.setState("VIBE\nSET", vc.pct(step) + "%", 1f); }
    }

    // ---------- Rendering ----------
    private void renderIdle() {
        vibeButton.setState("SET MY\nVIBE", "", 0f);
        int rec = prefs.lastRecommendedPct(), prev = prefs.previousVolumePct();
        tvRecommended.setText(rec >= 0 ? rec + "%" : "—");
        tvPrevious.setText(prev >= 0 ? prev + "%" : "—");
    }

    private void renderMedia() {
        if (!media.accessGranted) {
            tvSource.setText("NO ACCESS"); tvTitle.setText("Notification access needed");
            tvArtist.setText("Lets TANO VIBE see which song is playing. Analysis can still run without it.");
            btnGrant.setVisibility(View.VISIBLE);
        } else {
            btnGrant.setVisibility(View.GONE);
            if (!media.hasSession) {
                tvSource.setText("NO SOURCE"); tvTitle.setText("Nothing playing");
                tvArtist.setText("Start a song in Spotify, YouTube, YouTube Music or another player.");
            } else {
                tvSource.setText(media.sourceName.toUpperCase(Locale.US) + (media.playing ? "" : " · PAUSED"));
                tvTitle.setText(media.title.isEmpty() ? "Unknown title" : media.title);
                tvArtist.setText(media.artist);
            }
        }
    }

    private void showDecision(VolumeDecision d, boolean applied) {
        tvRecommended.setText(d.recommendedPct + "%");
        int prev = prefs.previousVolumePct();
        tvPrevious.setText(prev >= 0 ? prev + "%" : "—");
        tvApplyHint.setVisibility(!applied && !prefs.autoApply() ? View.VISIBLE : View.GONE);
        resultCard.setVisibility(View.VISIBLE);
        resultRows.removeAllViews();
        StringBuilder sb = new StringBuilder();
        if (d.analysed) {
            AnalysisResult r = d.analysis;
            tvResultTitle.setText("RESULT · ANALYSED FROM " + String.format(Locale.US, "%.0f", r.durationSec) + " S OF REAL AUDIO");
            visualizer.setLevels(r.bands);
            setStatus(applied ? "ANALYSED · SETTING " + d.recommendedPct + "%" : "ANALYSED · RECOMMENDING " + d.recommendedPct + "%", false);
            row("LOUDNESS", String.format(Locale.US, "%.1f LUFS", r.integratedLufs));
            row("RMS / PEAK", String.format(Locale.US, "%.1f / %.1f dBFS", r.rmsDb, r.peakDb));
            row("DYNAMICS", String.format(Locale.US, "%.1f LU range · %.1f dB crest", r.loudnessRangeLu, r.crestDb));
            row("BASS / MID / TREBLE", String.format(Locale.US, "%.0f / %.0f / %.0f %%", r.bassShare * 100, r.midShare * 100, r.trebleShare * 100));
            row("INTENSITY", String.format(Locale.US, "%.0f %%", r.intensity * 100));
        } else {
            tvResultTitle.setText("RESULT · NOT ANALYSED");
            setStatus("FALLBACK · NO ANALYSIS · " + (applied ? "USING " : "SUGGESTING ") + d.recommendedPct + "%", true);
            row("REASON", d.fallbackReason);
        }
        for (String s : d.reasons) sb.append("• ").append(s).append('\n');
        tvReasons.setText(sb.toString().trim());
    }

    private void row(String k, String v) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, 0, 0, dp(10));
        TextView a = new TextView(this); a.setText(k); a.setTextSize(10); a.setTextColor(getColor(R.color.muted)); a.setTypeface(Fonts.label(this));
        TextView b = new TextView(this); b.setText(v); b.setTextSize(16); b.setTextColor(getColor(R.color.text)); b.setTypeface(Fonts.pixel(this));
        l.addView(a); l.addView(b);
        resultRows.addView(l, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void setStatus(String s, boolean warn) {
        tvStatus.setText(s);
        tvStatus.setTextColor(getColor(warn ? R.color.warn : R.color.lavender));
    }

    private void refreshVolume() {
        int cur = vc.current();
        tvCurrent.setText(vc.pct(cur) + "%");
        tvVolumePct.setText(vc.pct(cur) + "%");
        if (!dragging) seek.setProgress(cur);
    }

    private void refreshOutput() {
        OutputRoute o = OutputRoute.read(this);
        tvOutputName.setText(o.name.isEmpty() ? o.kindLabel() : o.name);
        tvOutputKind.setText(o.kindLabel());
        tvOutputKind.setTextColor(getColor(o.kind == OutputRoute.Kind.BLUETOOTH ? R.color.lavender : R.color.ok));
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
