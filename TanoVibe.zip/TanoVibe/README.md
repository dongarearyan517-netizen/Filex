# TANO VIBE  ·  by TANOLOPP

Press **SET MY VIBE** → TANO VIBE analyses the audio that is actually playing and gently moves
Android media volume to a sensible level (capped by your maximum). It never changes volume on its own.

## Build
1. Android Studio Hedgehog (2023.1) or newer, JDK 17.
2. File ▸ Open ▸ the `TanoVibe` folder. If Studio asks, let it use Gradle 8.2 (or run `gradle wrapper --gradle-version 8.2`).
3. Run on a real device (Android 8.0+; Android 10+ for audio analysis). Debug APK: *Build ▸ Build APK(s)*.

## First run
1. Play a song (Spotify / YouTube / YouTube Music / any media app).
2. Open TANO VIBE → **Grant notification access** (needed only to read what's playing).
3. Press **SET MY VIBE** → allow audio capture. On Android 14+ pick *Entire screen* in the system dialog;
   TANO VIBE records **audio only**, never the screen, and never the microphone.

## How it decides
Real PCM captured via AudioPlaybackCapture → BS.1770 K-weighted gated loudness (LUFS), RMS, peak, crest,
loudness range, FFT bass/mid/treble shares, spectral centroid, intensity (spectral flux).
Volume = reference volume + (reference LUFS − track LUFS) / dB-span, ± small dynamic/bass/treble/intensity terms,
clamped to your maximum. Loud tracks get *less* volume; musical intensity only nudges ±1 dB.
All constants: `audio/DecisionConfig.java`. The engine is pure Java (`audio/`), verified with synthetic signals
(997 Hz full-scale left-only = −3.01 LUFS, matching the BS.1770 reference).

## Limits (by Android / media apps — not hidden)
- Android < 10: no playback-capture API → fallback only (clearly labelled "NOT ANALYSED").
- Apps can opt out of capture and DRM streams are excluded → captured silence is detected and reported; no numbers are invented.
- Microphone measurement is deliberately **not** offered: it is not equivalent to digital analysis.
- Android's volume curve is nonlinear; the dB→step mapping is an approximation (tune `dbSpan`).
- Assumption to verify on-device: that captured audio is independent of the current stream volume.
- Android 14+ requires the capture consent dialog every time; this cannot be bypassed.
- Intensity/Bass/Treble thresholds are heuristics, not tuned on a music corpus.

## Not yet done
This project was written without an Android SDK/network, so it has **not been compiled or run**.
Only the pure-Java audio engine was compiled and tested. Expect to fix small compile/UI issues on first build.
