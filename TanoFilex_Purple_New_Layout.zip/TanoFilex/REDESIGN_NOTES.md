# TANO FileX — Purple Layout Refresh

This revision keeps the midnight-black and cool-violet visual identity but changes the dashboard composition.

## New dashboard composition
- Compact brand/status line and editorial two-line heading.
- Horizontal storage hero with the circular analyzer beside concise used/free figures.
- One prominent Browse All Files action.
- Three compact destination shortcuts for Images, Downloads and Archives.
- Quiet recent-activity list with thin dividers.
- Reduced stacked-card feel and more intentional spacing.

## Motion
- Existing staggered fade-and-rise entrance is retained.
- Storage ring continues its animated progress transition.
- Shortcut and browse controls retain subtle press feedback.

## Functional scope
The redesign changes HomeFragment presentation only. Existing navigation destinations, storage scanning, file operations, ZIP handling, private-space logic, permissions and previews are not intentionally modified.

## Verification
Source archive created. An Android SDK build and on-device testing have not yet been performed; run the GitHub Actions build and test on the target phone before relying on the APK.
