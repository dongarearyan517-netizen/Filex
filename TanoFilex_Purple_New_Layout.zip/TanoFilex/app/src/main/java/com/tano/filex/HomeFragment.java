package com.tano.filex;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.List;

/** Reimagined purple dashboard: compact storage hero, clear browse entry points and quiet activity feed. */
public class HomeFragment extends Fragment {
    private StorageRingView ring;
    private TextView usedT, freeT, totalT, scanStatus;
    private LinearLayout recentBox;

    private final StorageScanner.Listener listener = new StorageScanner.Listener() {
        @Override public void onProgress(long files) {
            if (isAdded() && scanStatus != null) scanStatus.setText("Refreshing · " + files + " files checked");
        }
        @Override public void onDone() { refresh(); }
    };

    private LinearLayout col(Context c) {
        LinearLayout v = new LinearLayout(c); v.setOrientation(LinearLayout.VERTICAL); return v;
    }
    private LinearLayout row(Context c) {
        LinearLayout v = new LinearLayout(c); v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private TextView txt(Context c, String s, float size, int color) {
        TextView t = UI.text(c, s, size, color); t.setFontFeatureSettings("kern"); return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle state) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout page = col(c);
        int side = UI.dp(c, 20);
        page.setPadding(side, UI.dp(c, 18), side, UI.dp(c, 30));
        scroll.addView(page);

        // Editorial-style heading: spacious, restrained and clearly different from the old stacked dashboard.
        LinearLayout top = row(c);
        TextView eyebrow = txt(c, "TANO  /  FILEX", 10, UI.VIOLET);
        eyebrow.setLetterSpacing(.20f);
        eyebrow.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        top.addView(eyebrow, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView local = txt(c, "●  ON DEVICE", 9, UI.MUTED);
        local.setLetterSpacing(.12f); top.addView(local);
        page.addView(top);

        TextView heading = txt(c, "Your space,\nbeautifully sorted.", 26, UI.TEXT);
        heading.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        heading.setLineSpacing(UI.dp(c, 1), 1f);
        LinearLayout.LayoutParams headingLp = lp(-1, -2);
        headingLp.topMargin = UI.dp(c, 15); page.addView(heading, headingLp);
        TextView sub = txt(c, "Everything you keep. One place to find it.", 12, UI.MUTED);
        LinearLayout.LayoutParams subLp = lp(-1, -2); subLp.topMargin = UI.dp(c, 5); subLp.bottomMargin = UI.dp(c, 20);
        page.addView(sub, subLp);

        // New asymmetrical storage hero: ring and numbers share one surface instead of a tall centered card.
        LinearLayout hero = row(c);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(UI.dp(c, 15), UI.dp(c, 15), UI.dp(c, 13), UI.dp(c, 15));
        hero.setBackground(UI.panel(c));
        ring = new StorageRingView(c);
        LinearLayout.LayoutParams ringLp = lp(UI.dp(c, 142), UI.dp(c, 142));
        hero.addView(ring, ringLp);

        LinearLayout stats = col(c);
        stats.setPadding(UI.dp(c, 13), 0, 0, 0);
        TextView usedLabel = txt(c, "STORAGE USED", 9, UI.MUTED);
        usedLabel.setLetterSpacing(.16f); stats.addView(usedLabel);
        totalT = txt(c, "-- used", 17, UI.TEXT);
        totalT.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams totalLp = lp(-1, -2); totalLp.topMargin = UI.dp(c, 6); stats.addView(totalT, totalLp);
        View line = new View(c); line.setBackgroundColor(UI.DIVIDER);
        LinearLayout.LayoutParams lineLp = lp(-1, UI.dp(c, 1)); lineLp.topMargin = UI.dp(c, 11); lineLp.bottomMargin = UI.dp(c, 10);
        stats.addView(line, lineLp);
        LinearLayout usedRow = row(c);
        View usedDot = dot(c, UI.VIOLET); usedRow.addView(usedDot, lp(UI.dp(c, 7), UI.dp(c, 7)));
        usedT = txt(c, "-- used", 11, UI.SOFT);
        LinearLayout.LayoutParams usedTextLp = lp(-2, -2); usedTextLp.leftMargin = UI.dp(c, 7); usedRow.addView(usedT, usedTextLp);
        stats.addView(usedRow);
        LinearLayout freeRow = row(c);
        LinearLayout.LayoutParams freeRowLp = lp(-1, -2); freeRowLp.topMargin = UI.dp(c, 8); stats.addView(freeRow, freeRowLp);
        View freeDot = dot(c, 0xFF514364); freeRow.addView(freeDot, lp(UI.dp(c, 7), UI.dp(c, 7)));
        freeT = txt(c, "-- free", 11, UI.MUTED);
        LinearLayout.LayoutParams freeTextLp = lp(-2, -2); freeTextLp.leftMargin = UI.dp(c, 7); freeRow.addView(freeT, freeTextLp);
        hero.addView(stats, new LinearLayout.LayoutParams(0, -2, 1f));
        page.addView(hero);

        // One prominent route into the file system; secondary destinations stay deliberately quiet.
        LinearLayout browse = row(c);
        browse.setPadding(UI.dp(c, 16), UI.dp(c, 15), UI.dp(c, 14), UI.dp(c, 15));
        GradientDrawable browseBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF34204F, 0xFF21162F});
        browseBg.setCornerRadius(UI.dp(c, 18)); browseBg.setStroke(UI.dp(c, 1), 0xFF60417F);
        browse.setBackground(browseBg); browse.setClickable(true); browse.setFocusable(true);
        LinearLayout.LayoutParams browseLp = lp(-1, -2); browseLp.topMargin = UI.dp(c, 17); page.addView(browse, browseLp);
        LinearLayout browseText = col(c);
        TextView browseTitle = txt(c, "Browse all files", 14, UI.TEXT);
        browseTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); browseText.addView(browseTitle);
        TextView browseSub = txt(c, "Explore folders and storage", 10, UI.SOFT);
        LinearLayout.LayoutParams browseSubLp = lp(-1, -2); browseSubLp.topMargin = UI.dp(c, 3); browseText.addView(browseSub, browseSubLp);
        browse.addView(browseText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView arrow = txt(c, "↗", 23, UI.VIOLET); browse.addView(arrow);
        browse.setOnClickListener(v -> { UI.press(browse); ((MainActivity) requireActivity()).navigate(MainActivity.NAV_FILES); });

        LinearLayout section = row(c);
        LinearLayout.LayoutParams sectionLp = lp(-1, -2); sectionLp.topMargin = UI.dp(c, 24); sectionLp.bottomMargin = UI.dp(c, 11);
        page.addView(section, sectionLp);
        TextView toolsTitle = txt(c, "JUMP INTO", 10, UI.MUTED);
        toolsTitle.setLetterSpacing(.18f); toolsTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        section.addView(toolsTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView menuHint = txt(c, "MORE IN MENU  ⋯", 9, UI.MUTED); menuHint.setLetterSpacing(.08f); section.addView(menuHint);

        LinearLayout shortcuts = row(c);
        shortcuts.setGravity(Gravity.CENTER_VERTICAL);
        shortcuts.addView(shortcut(c, "▧", "Images", MainActivity.NAV_IMAGES), new LinearLayout.LayoutParams(0, -2, 1f));
        shortcuts.addView(shortcut(c, "⇩", "Downloads", MainActivity.NAV_DOWNLOADS), new LinearLayout.LayoutParams(0, -2, 1f));
        shortcuts.addView(shortcut(c, "◇", "Archives", MainActivity.NAV_ARCHIVES), new LinearLayout.LayoutParams(0, -2, 1f));
        page.addView(shortcuts);

        LinearLayout recentHead = row(c);
        LinearLayout.LayoutParams recentHeadLp = lp(-1, -2); recentHeadLp.topMargin = UI.dp(c, 25); recentHeadLp.bottomMargin = UI.dp(c, 6);
        page.addView(recentHead, recentHeadLp);
        TextView recentTitle = txt(c, "RECENTLY TOUCHED", 10, UI.MUTED);
        recentTitle.setLetterSpacing(.16f); recentTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        recentHead.addView(recentTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView seeAll = UI.button(c, "View all  →");
        seeAll.setOnClickListener(v -> ((MainActivity) requireActivity()).navigate(MainActivity.NAV_RECENT));
        recentHead.addView(seeAll);
        recentBox = col(c); page.addView(recentBox);
        scanStatus = txt(c, "Storage details stay on this device.", 9, UI.MUTED);
        LinearLayout.LayoutParams statusLp = lp(-1, -2); statusLp.topMargin = UI.dp(c, 8); page.addView(scanStatus, statusLp);

        for (int i = 0; i < page.getChildCount(); i++) UI.animateIn(page.getChildAt(i), i);
        return scroll;
    }

    private View dot(Context c, int color) {
        GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color);
        View v = new View(c); v.setBackground(d); return v;
    }

    private View shortcut(Context c, String glyph, String name, int dest) {
        LinearLayout item = col(c); item.setGravity(Gravity.CENTER); item.setPadding(UI.dp(c, 4), UI.dp(c, 10), UI.dp(c, 4), UI.dp(c, 9));
        TextView icon = txt(c, glyph, 20, UI.VIOLET); icon.setGravity(Gravity.CENTER);
        icon.setBackground(UI.round(c, 0x302C1C42, 15)); item.addView(icon, lp(UI.dp(c, 48), UI.dp(c, 45)));
        TextView label = txt(c, name, 10, UI.SOFT); label.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelLp = lp(-1, -2); labelLp.topMargin = UI.dp(c, 6); item.addView(label, labelLp);
        item.setClickable(true); item.setFocusable(true);
        item.setOnClickListener(v -> { UI.press(item); ((MainActivity) requireActivity()).navigate(dest); });
        return item;
    }

    @Override public void onStart() {
        super.onStart(); StorageScanner.get().addListener(listener);
        StorageScanner sc = StorageScanner.get(); if (sc.result() == null && !sc.isRunning()) sc.start(requireContext());
        refresh();
    }
    @Override public void onStop() { super.onStop(); StorageScanner.get().removeListener(listener); }

    private void refresh() {
        if (!isAdded() || getView() == null || ring == null) return;
        Context c = requireContext(); long[] st = StorageHelper.stat(StorageHelper.primary());
        long total = st[0], free = st[1], used = Math.max(0, total - free);
        float frac = total > 0 ? (float) used / total : 0f;
        String pct = total > 0 ? Math.round(frac * 100) + "%" : "--";
        usedT.setText(FileUtils.size(used) + " used"); freeT.setText(FileUtils.size(free) + " free");
        totalT.setText(FileUtils.size(used) + " used");
        ring.setData(frac, new float[0], new int[0], pct, "USED", "");
        recentBox.removeAllViews(); List<ActivityLog.Entry> log = ActivityLog.list(c);
        if (log.isEmpty()) {
            TextView empty = txt(c, "Your recent file activity will appear here.", 11, UI.MUTED);
            empty.setPadding(UI.dp(c, 1), UI.dp(c, 12), 0, UI.dp(c, 12)); recentBox.addView(empty);
        }
        for (int i = 0; i < log.size() && i < 3; i++) addRecent(c, log.get(i), i == Math.min(log.size(), 3) - 1);
        StorageScanner.Result result = StorageScanner.get().result();
        if (result == null) scanStatus.setText(StorageScanner.get().isRunning() ? "Refreshing storage information…" : "Storage details stay on this device.");
        else scanStatus.setText("Updated on this device · Protected app folders may be excluded.");
    }

    private void addRecent(Context c, ActivityLog.Entry entry, boolean last) {
        LinearLayout item = row(c); item.setPadding(0, UI.dp(c, 10), 0, UI.dp(c, 10));
        TextView icon = txt(c, "•", 22, UI.VIOLET); icon.setGravity(Gravity.CENTER);
        item.addView(icon, lp(UI.dp(c, 25), UI.dp(c, 34)));
        LinearLayout mid = col(c); mid.setPadding(UI.dp(c, 8), 0, UI.dp(c, 8), 0);
        TextView title = txt(c, entry.text, 12, UI.TEXT); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView when = txt(c, FileUtils.date(entry.time), 10, UI.MUTED);
        LinearLayout.LayoutParams whenLp = lp(-1, -2); whenLp.topMargin = UI.dp(c, 3); mid.addView(title); mid.addView(when, whenLp);
        item.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = txt(c, "›", 21, UI.MUTED); item.addView(more);
        item.setOnClickListener(v -> RecentFragment.openEntry((MainActivity) requireActivity(), entry));
        recentBox.addView(item);
        if (!last) { View divider = new View(c); divider.setBackgroundColor(UI.DIVIDER); recentBox.addView(divider, lp(-1, UI.dp(c, 1))); }
        UI.animateIn(item, recentBox.getChildCount());
    }
}
